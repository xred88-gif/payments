# payments

Browser-based React application for composing and viewing SWIFT and ISO 20022 message examples.

This is a standalone demonstration, not a connection to SWIFT or a bank. It does not send payments. Accounts, profiles, and messages are stored in this browser's localStorage. The included login is demonstration-only and does not protect data on a server. Use test data.

## Run locally

Install Node.js 22, then run:

```sh
npm ci
npm run dev
```

## Build

```sh
npm run build
npm run preview
```

## GitHub Pages

In repository Settings > Pages, choose **GitHub Actions** as the source. The included workflow builds and deploys on pushes to main. The site URL is `https://xred88-gif.github.io/payments/`.
