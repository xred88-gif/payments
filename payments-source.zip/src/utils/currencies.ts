/**
 * ISO 4217 Currency List — Full set used in SWIFT messaging
 */

export interface Currency {
  code: string;      // ISO 4217 code
  name: string;      // Full name
  symbol: string;    // Symbol
  decimals: number;  // Minor units
  country: string;   // Primary country/region
  flag: string;      // Emoji flag
}

export const CURRENCIES: Currency[] = [
  // Major / G10
  { code: 'USD', name: 'US Dollar',                  symbol: '$',    decimals: 2, country: 'United States',      flag: '🇺🇸' },
  { code: 'EUR', name: 'Euro',                        symbol: '€',    decimals: 2, country: 'Eurozone',           flag: '🇪🇺' },
  { code: 'GBP', name: 'Pound Sterling',              symbol: '£',    decimals: 2, country: 'United Kingdom',     flag: '🇬🇧' },
  { code: 'JPY', name: 'Japanese Yen',                symbol: '¥',    decimals: 0, country: 'Japan',              flag: '🇯🇵' },
  { code: 'CHF', name: 'Swiss Franc',                 symbol: 'Fr',   decimals: 2, country: 'Switzerland',        flag: '🇨🇭' },
  { code: 'CAD', name: 'Canadian Dollar',             symbol: 'C$',   decimals: 2, country: 'Canada',             flag: '🇨🇦' },
  { code: 'AUD', name: 'Australian Dollar',           symbol: 'A$',   decimals: 2, country: 'Australia',          flag: '🇦🇺' },
  { code: 'NZD', name: 'New Zealand Dollar',          symbol: 'NZ$',  decimals: 2, country: 'New Zealand',        flag: '🇳🇿' },
  { code: 'SEK', name: 'Swedish Krona',               symbol: 'kr',   decimals: 2, country: 'Sweden',             flag: '🇸🇪' },
  { code: 'NOK', name: 'Norwegian Krone',             symbol: 'kr',   decimals: 2, country: 'Norway',             flag: '🇳🇴' },
  { code: 'DKK', name: 'Danish Krone',                symbol: 'kr',   decimals: 2, country: 'Denmark',            flag: '🇩🇰' },
  // Asia Pacific
  { code: 'CNY', name: 'Chinese Yuan Renminbi',       symbol: '¥',    decimals: 2, country: 'China',              flag: '🇨🇳' },
  { code: 'CNH', name: 'Chinese Yuan (Offshore)',     symbol: '¥',    decimals: 2, country: 'China (Offshore)',   flag: '🇨🇳' },
  { code: 'HKD', name: 'Hong Kong Dollar',            symbol: 'HK$',  decimals: 2, country: 'Hong Kong',          flag: '🇭🇰' },
  { code: 'SGD', name: 'Singapore Dollar',            symbol: 'S$',   decimals: 2, country: 'Singapore',          flag: '🇸🇬' },
  { code: 'KRW', name: 'South Korean Won',            symbol: '₩',    decimals: 0, country: 'South Korea',        flag: '🇰🇷' },
  { code: 'TWD', name: 'New Taiwan Dollar',           symbol: 'NT$',  decimals: 2, country: 'Taiwan',             flag: '🇹🇼' },
  { code: 'INR', name: 'Indian Rupee',                symbol: '₹',    decimals: 2, country: 'India',              flag: '🇮🇳' },
  { code: 'THB', name: 'Thai Baht',                   symbol: '฿',    decimals: 2, country: 'Thailand',           flag: '🇹🇭' },
  { code: 'MYR', name: 'Malaysian Ringgit',           symbol: 'RM',   decimals: 2, country: 'Malaysia',           flag: '🇲🇾' },
  { code: 'IDR', name: 'Indonesian Rupiah',           symbol: 'Rp',   decimals: 2, country: 'Indonesia',          flag: '🇮🇩' },
  { code: 'PHP', name: 'Philippine Peso',             symbol: '₱',    decimals: 2, country: 'Philippines',        flag: '🇵🇭' },
  { code: 'VND', name: 'Vietnamese Dong',             symbol: '₫',    decimals: 0, country: 'Vietnam',            flag: '🇻🇳' },
  { code: 'PKR', name: 'Pakistani Rupee',             symbol: '₨',    decimals: 2, country: 'Pakistan',           flag: '🇵🇰' },
  { code: 'BDT', name: 'Bangladeshi Taka',            symbol: '৳',    decimals: 2, country: 'Bangladesh',         flag: '🇧🇩' },
  { code: 'LKR', name: 'Sri Lankan Rupee',            symbol: '₨',    decimals: 2, country: 'Sri Lanka',          flag: '🇱🇰' },
  // Middle East
  { code: 'AED', name: 'UAE Dirham',                  symbol: 'د.إ',  decimals: 2, country: 'UAE',                flag: '🇦🇪' },
  { code: 'SAR', name: 'Saudi Riyal',                 symbol: '﷼',    decimals: 2, country: 'Saudi Arabia',       flag: '🇸🇦' },
  { code: 'QAR', name: 'Qatari Riyal',                symbol: '﷼',    decimals: 2, country: 'Qatar',              flag: '🇶🇦' },
  { code: 'KWD', name: 'Kuwaiti Dinar',               symbol: 'د.ك',  decimals: 3, country: 'Kuwait',             flag: '🇰🇼' },
  { code: 'BHD', name: 'Bahraini Dinar',              symbol: '.د.ب', decimals: 3, country: 'Bahrain',            flag: '🇧🇭' },
  { code: 'OMR', name: 'Omani Rial',                  symbol: '﷼',    decimals: 3, country: 'Oman',               flag: '🇴🇲' },
  { code: 'JOD', name: 'Jordanian Dinar',             symbol: 'JD',   decimals: 3, country: 'Jordan',             flag: '🇯🇴' },
  { code: 'LBP', name: 'Lebanese Pound',              symbol: 'ل.ل',  decimals: 2, country: 'Lebanon',            flag: '🇱🇧' },
  { code: 'ILS', name: 'Israeli New Shekel',          symbol: '₪',    decimals: 2, country: 'Israel',             flag: '🇮🇱' },
  { code: 'EGP', name: 'Egyptian Pound',              symbol: '£',    decimals: 2, country: 'Egypt',              flag: '🇪🇬' },
  // Europe (non-EUR)
  { code: 'PLN', name: 'Polish Zloty',                symbol: 'zł',   decimals: 2, country: 'Poland',             flag: '🇵🇱' },
  { code: 'CZK', name: 'Czech Koruna',                symbol: 'Kč',   decimals: 2, country: 'Czech Republic',     flag: '🇨🇿' },
  { code: 'HUF', name: 'Hungarian Forint',            symbol: 'Ft',   decimals: 2, country: 'Hungary',            flag: '🇭🇺' },
  { code: 'RON', name: 'Romanian Leu',                symbol: 'lei',  decimals: 2, country: 'Romania',            flag: '🇷🇴' },
  { code: 'RUB', name: 'Russian Ruble',               symbol: '₽',    decimals: 2, country: 'Russia',             flag: '🇷🇺' },
  { code: 'TRY', name: 'Turkish Lira',                symbol: '₺',    decimals: 2, country: 'Turkey',             flag: '🇹🇷' },
  // Americas (non-USD)
  { code: 'BRL', name: 'Brazilian Real',              symbol: 'R$',   decimals: 2, country: 'Brazil',             flag: '🇧🇷' },
  { code: 'MXN', name: 'Mexican Peso',                symbol: '$',    decimals: 2, country: 'Mexico',             flag: '🇲🇽' },
  { code: 'ARS', name: 'Argentine Peso',              symbol: '$',    decimals: 2, country: 'Argentina',          flag: '🇦🇷' },
  { code: 'CLP', name: 'Chilean Peso',                symbol: '$',    decimals: 0, country: 'Chile',              flag: '🇨🇱' },
  { code: 'COP', name: 'Colombian Peso',              symbol: '$',    decimals: 2, country: 'Colombia',           flag: '🇨🇴' },
  { code: 'PEN', name: 'Peruvian Sol',                symbol: 'S/',   decimals: 2, country: 'Peru',               flag: '🇵🇪' },
  // Africa
  { code: 'ZAR', name: 'South African Rand',          symbol: 'R',    decimals: 2, country: 'South Africa',       flag: '🇿🇦' },
  { code: 'NGN', name: 'Nigerian Naira',              symbol: '₦',    decimals: 2, country: 'Nigeria',            flag: '🇳🇬' },
  { code: 'KES', name: 'Kenyan Shilling',             symbol: 'KSh',  decimals: 2, country: 'Kenya',              flag: '🇰🇪' },
  { code: 'GHS', name: 'Ghanaian Cedi',               symbol: '₵',    decimals: 2, country: 'Ghana',              flag: '🇬🇭' },
  { code: 'MAD', name: 'Moroccan Dirham',             symbol: 'د.م.', decimals: 2, country: 'Morocco',            flag: '🇲🇦' },
  { code: 'TZS', name: 'Tanzanian Shilling',          symbol: 'TSh',  decimals: 2, country: 'Tanzania',           flag: '🇹🇿' },
  { code: 'ETB', name: 'Ethiopian Birr',              symbol: 'Br',   decimals: 2, country: 'Ethiopia',           flag: '🇪🇹' },
  // Special / SDR
  { code: 'XDR', name: 'Special Drawing Rights',      symbol: 'SDR',  decimals: 5, country: 'IMF',                flag: '🌐' },
  { code: 'XAU', name: 'Gold (troy ounce)',            symbol: 'Au',   decimals: 5, country: 'Commodity',          flag: '🥇' },
  { code: 'XAG', name: 'Silver (troy ounce)',          symbol: 'Ag',   decimals: 5, country: 'Commodity',          flag: '🥈' },
];

/** Quick lookup by code */
export function getCurrency(code: string): Currency | undefined {
  return CURRENCIES.find(c => c.code === code.toUpperCase());
}

/** Format an amount with currency, SWIFT-style (comma decimal separator for MT messages) */
export function formatSWIFTAmount(amount: string | number, ccy: string): string {
  const cur = getCurrency(ccy);
  const decimals = cur?.decimals ?? 2;
  const num = typeof amount === 'string' ? parseFloat(amount.replace(/,/g, '.')) : amount;
  if (isNaN(num)) return `${ccy}0,00`;
  const parts = num.toFixed(decimals).split('.');
  const intPart = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, '');
  const decPart = parts[1] ?? '00';
  return `${ccy}${intPart},${decPart}`;
}

/** Format for ISO 20022 (dot decimal) */
export function formatISOAmount(amount: string | number, decimals = 2): string {
  const num = typeof amount === 'string' ? parseFloat(amount.replace(/,/g, '.')) : amount;
  if (isNaN(num)) return '0.00';
  return num.toFixed(decimals);
}

/** Group currencies for display */
export const CURRENCY_GROUPS = [
  { label: 'Major / G10',    codes: ['USD','EUR','GBP','JPY','CHF','CAD','AUD','NZD','SEK','NOK','DKK'] },
  { label: 'Asia Pacific',   codes: ['CNY','CNH','HKD','SGD','KRW','TWD','INR','THB','MYR','IDR','PHP','VND','PKR','BDT','LKR'] },
  { label: 'Middle East',    codes: ['AED','SAR','QAR','KWD','BHD','OMR','JOD','LBP','ILS','EGP'] },
  { label: 'Europe (non-€)', codes: ['PLN','CZK','HUF','RON','RUB','TRY'] },
  { label: 'Americas',       codes: ['BRL','MXN','ARS','CLP','COP','PEN'] },
  { label: 'Africa',         codes: ['ZAR','NGN','KES','GHS','MAD','TZS','ETB'] },
  { label: 'Special / SDR',  codes: ['XDR','XAU','XAG'] },
];
