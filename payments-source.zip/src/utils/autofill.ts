/**
 * Auto-fill helpers for SWIFT MT and ISO 20022 message fields
 * Generates realistic, standards-compliant default values
 */

import { generateTransactionRef, generateUETR, generateMessageId } from './identifiers';

// ─── Date helpers ─────────────────────────────────────────────────────────────
export function todayYYMMDD(): string {
  const d = new Date();
  const yy = String(d.getUTCFullYear()).slice(2);
  const mm = String(d.getUTCMonth() + 1).padStart(2, '0');
  const dd = String(d.getUTCDate()).padStart(2, '0');
  return `${yy}${mm}${dd}`;
}

export function expiryYYMMDD(monthsAhead = 12): string {
  const d = new Date();
  d.setUTCMonth(d.getUTCMonth() + monthsAhead);
  const yy = String(d.getUTCFullYear()).slice(2);
  const mm = String(d.getUTCMonth() + 1).padStart(2, '0');
  const dd = String(d.getUTCDate()).padStart(2, '0');
  return `${yy}${mm}${dd}`;
}

export function shipmentYYMMDD(monthsAhead = 6): string {
  const d = new Date();
  d.setUTCMonth(d.getUTCMonth() + monthsAhead);
  const yy = String(d.getUTCFullYear()).slice(2);
  const mm = String(d.getUTCMonth() + 1).padStart(2, '0');
  const dd = String(d.getUTCDate()).padStart(2, '0');
  return `${yy}${mm}${dd}`;
}

export function todayISO(): string {
  return new Date().toISOString().slice(0, 10);
}

export function nowISO(): string {
  return new Date().toISOString().replace(/\.\d{3}Z$/, '+00:00');
}

export function settlementDateISO(daysAhead = 2): string {
  const d = new Date();
  d.setUTCDate(d.getUTCDate() + daysAhead);
  return d.toISOString().slice(0, 10);
}

// ─── Reference generators ─────────────────────────────────────────────────────
export function lcNumber(): string {
  const yy = String(new Date().getUTCFullYear()).slice(2);
  const n = String(Math.floor(1000 + Math.random() * 9000));
  return `LC${yy}-${n}`;
}

export function guarNumber(): string {
  const yy = String(new Date().getUTCFullYear()).slice(2);
  const n = String(Math.floor(1000 + Math.random() * 9000));
  return `GUAR${yy}-${n}`;
}

export function instrId(): string {
  const ts = Date.now().toString().slice(-8);
  const r = Math.random().toString(36).toUpperCase().replace(/[^A-Z0-9]/g,'').slice(0,4);
  return `INSTR${ts}${r}`;
}

export function endToEndId(): string {
  const ts = Date.now().toString().slice(-8);
  const r = Math.random().toString(36).toUpperCase().replace(/[^A-Z0-9]/g,'').slice(0,4);
  return `E2E${ts}${r}`;
}

export function txId(): string {
  const ts = Date.now().toString().slice(-8);
  const r = Math.random().toString(36).toUpperCase().replace(/[^A-Z0-9]/g,'').slice(0,4);
  return `TX${ts}${r}`;
}

export function clrSysRef(): string {
  const ts = Date.now().toString().slice(-8);
  return `CLR${ts}`;
}

export function acctId(): string {
  return String(Math.floor(10000000 + Math.random() * 90000000));
}

// ─── MT700 defaults ───────────────────────────────────────────────────────────
export function defaultMT700Fields() {
  return {
    tag40A: 'IRREVOCABLE',
    tag20:  lcNumber(),
    tag31C: todayYYMMDD(),
    tag31D: `${expiryYYMMDD(12)} LONDON, UNITED KINGDOM`,
    tag27:  '1/1',
    tag50:  'ACME CORPORATION\n123 MAIN STREET, SUITE 400\nNEW YORK, NY 10001\nUNITED STATES OF AMERICA',
    tag59:  'GLOBAL EXPORTS LIMITED\n456 HIGH STREET\nLONDON EC1A 1BB\nUNITED KINGDOM',
    tag32B: 'USD1000000,00',
    tag39A: '05/05',
    tag41A: 'BARCGB22XXX BY NEGOTIATION',
    tag42C: '90 DAYS FROM BILL OF LADING DATE',
    tag42A: 'BARCGB22XXX',
    tag43P: 'NOT ALLOWED',
    tag43T: 'NOT ALLOWED',
    tag44E: 'PORT OF SHANGHAI, CHINA',
    tag44F: 'PORT OF FELIXSTOWE, UNITED KINGDOM',
    tag44B: 'LONDON, UNITED KINGDOM',
    tag44C: shipmentYYMMDD(6),
    tag45A: 'ELECTRICAL MACHINERY AND EQUIPMENT\nHS CODE: 8501.10\n1,000 UNITS @ USD 1,000.00 PER UNIT\nCIF FELIXSTOWE INCOTERMS 2020',
    tag46A: '+FULL SET OF CLEAN ON BOARD BILLS OF LADING\nMADE OUT TO ORDER BLANK ENDORSED MARKED\nFREIGHT PREPAID\n+COMMERCIAL INVOICE IN TRIPLICATE\n+PACKING LIST IN DUPLICATE\n+CERTIFICATE OF ORIGIN ISSUED BY CHAMBER OF COMMERCE',
    tag47A: 'DOCUMENTS MUST BE PRESENTED WITHIN 21 DAYS\nAFTER DATE OF SHIPMENT BUT WITHIN VALIDITY\nOF THIS CREDIT',
    tag49:  'CONFIRM',
    tag78:  'ALL DOCUMENTS MUST BE FORWARDED TO US IN ONE LOT\nBY COURIER SERVICE TO THE ADDRESS ABOVE\nPLEASE QUOTE OUR REFERENCE IN ALL CORRESPONDENCE',
    tag72:  '/BNF/PAYMENT SUBJECT TO UCP 600',
  };
}

// ─── MT705 defaults ───────────────────────────────────────────────────────────
export function defaultMT705Fields() {
  return {
    tag40A: 'IRREVOCABLE',
    tag20:  lcNumber(),
    tag31C: todayYYMMDD(),
    tag31D: `${expiryYYMMDD(12)} NEW YORK, UNITED STATES`,
    tag27:  '1/1',
    tag50:  'ACME CORPORATION\n123 MAIN STREET\nNEW YORK, NY 10001\nUNITED STATES',
    tag59:  'GLOBAL EXPORTS LIMITED\n456 HIGH STREET\nLONDON EC1A 1BB\nUNITED KINGDOM',
    tag32B: 'USD500000,00',
    tag39A: '05/05',
    tag41A: 'CHASUS33XXX BY SIGHT PAYMENT',
    tag44E: 'PORT OF ROTTERDAM, NETHERLANDS',
    tag44F: 'PORT OF NEW YORK, UNITED STATES',
    tag44C: shipmentYYMMDD(4),
    tag45A: 'GENERAL MERCHANDISE AS PER PROFORMA\nINVOICE NO. PI-2024-001 DATED TODAY\nCFR NEW YORK INCOTERMS 2020',
  };
}

// ─── MT760 defaults ───────────────────────────────────────────────────────────
export function defaultMT760Fields() {
  return {
    tag20:  guarNumber(),
    tag23:  'ISSUE',
    tag22D: 'DGAR',
    tag40C: 'URDG',
    tag27:  '1/1',
    tag31C: todayYYMMDD(),
    tag31D: `${expiryYYMMDD(12)} LONDON, UNITED KINGDOM`,
    tag50:  'ACME CORPORATION\n123 MAIN STREET\nNEW YORK, NY 10001\nUNITED STATES',
    tag59:  'MINISTRY OF FINANCE\n1 PARLIAMENT SQUARE\nLONDON SW1A 2BQ\nUNITED KINGDOM',
    tag32B: 'USD250000,00',
    tag57A: 'BARCGB22XXX',
    tag77C: 'WE HEREBY ISSUE THIS DEMAND GUARANTEE IN YOUR FAVOUR\nFOR AN AMOUNT NOT EXCEEDING USD 250,000.00\n(TWO HUNDRED AND FIFTY THOUSAND UNITED STATES DOLLARS)\n\nTHIS GUARANTEE IS ISSUED IN ACCORDANCE WITH THE\nUNIFORM RULES FOR DEMAND GUARANTEES (URDG) 758\nPUBLICATION NO. 758 OF THE INTERNATIONAL CHAMBER OF COMMERCE\n\nWE UNDERTAKE TO PAY YOU ANY AMOUNT OR AMOUNTS\nNOT EXCEEDING IN TOTAL USD 250,000.00 UPON RECEIPT\nOF YOUR FIRST WRITTEN DEMAND STATING THAT THE\nPRINCIPAL HAS FAILED TO PERFORM ITS CONTRACTUAL OBLIGATIONS',
    tag72:  '/GUAR/PERFORMANCE GUARANTEE\n/REF/CONTRACT NO. CTR-2024-001',
  };
}

// ─── MT199 / MT799 defaults ───────────────────────────────────────────────────
export function defaultMT199Fields() {
  return {
    tag20: generateTransactionRef(),
    tag21: generateTransactionRef(),
    tag79: 'WE REFER TO OUR MUTUAL AGREEMENT DATED TODAY.\n\nPLEASE BE ADVISED THAT WE HAVE PROCESSED THE\nABOVE REFERENCED TRANSACTION IN ACCORDANCE\nWITH YOUR INSTRUCTIONS.\n\nKINDLY CONFIRM RECEIPT OF THIS MESSAGE AND\nACKNOWLEDGE YOUR ACCEPTANCE OF THE TERMS.\n\nSHOULD YOU REQUIRE ANY FURTHER INFORMATION\nPLEASE DO NOT HESITATE TO CONTACT US.',
  };
}

export function defaultMT799Fields() {
  return {
    tag20: generateTransactionRef(),
    tag21: generateTransactionRef(),
    tag79: 'WE REFER TO LC NO. LC-2024-001 DATED TODAY\nISSUED BY JPMORGAN CHASE BANK N.A. NEW YORK.\n\nPLEASE BE ADVISED THAT WE HAVE RECEIVED AND\nEXAMINED THE DOCUMENTS PRESENTED THEREUNDER\nAND FIND THEM IN STRICT COMPLIANCE WITH THE\nTERMS AND CONDITIONS OF THE ABOVE CREDIT.\n\nWE SHALL EFFECT PAYMENT ON VALUE DATE\nIN ACCORDANCE WITH YOUR INSTRUCTIONS.\n\nPLEASE CONFIRM RECEIPT.',
  };
}

// ─── pacs.008 defaults ────────────────────────────────────────────────────────
export function defaultPacs008Fields() {
  return {
    msgId:          generateMessageId(),
    creDtTm:        nowISO(),
    nbOfTxs:        '1',
    sttlmMtd:       'INDA',
    sttlmDt:        settlementDateISO(2),
    instrId:        instrId(),
    endToEndId:     endToEndId(),
    uetr:           generateUETR(),
    chrgBr:         'SHAR',
    intrbkSttlmAmt: '1000000.00',
    intrbkSttlmCcy: 'USD',
    instdAmt:       '1000000.00',
    instdAmtCcy:    'USD',
    dbtrNm:         'ACME CORPORATION',
    dbtrAcct:       acctId(),
    dbtrAgtBIC:     'CHASUS33',
    dbtrCtry:       'US',
    cdtrNm:         'GLOBAL EXPORTS LIMITED',
    cdtrAcct:       `GB${Math.floor(10+Math.random()*89)}BARC${Math.floor(10000000+Math.random()*89999999)}${Math.floor(10000000+Math.random()*89999999)}`,
    cdtrAgtBIC:     'BARCGB22',
    cdtrAdrLine:    '1 CANADA SQUARE',
    cdtrTwnNm:      'LONDON E14 5AB',
    cdtrCtry:       'GB',
    purp:           'SUPP',
    rmtInf:         `PAYMENT FOR INVOICE INV-${new Date().getFullYear()}-001 DATED ${todayISO()}`,
  };
}

// ─── pacs.002 defaults ────────────────────────────────────────────────────────
export function defaultPacs002Fields() {
  return {
    msgId:          generateMessageId(),
    creDtTm:        nowISO(),
    orgnlMsgId:     generateMessageId(),
    orgnlMsgNmId:   'pacs.008.001.10',
    orgnlInstrId:   instrId(),
    orgnlEndToEndId:endToEndId(),
    orgnlUETR:      generateUETR(),
    txSts:          'ACSP',
    stsRsnCd:       'AC01',
    stsAddlInf:     'Payment accepted and in process of settlement',
    clrSysRef:      clrSysRef(),
  };
}

// ─── camt.053 defaults ────────────────────────────────────────────────────────
export function defaultCamt053Fields() {
  return {
    msgId:          generateMessageId(),
    creDtTm:        nowISO(),
    acctId:         acctId(),
    acctCcy:        'USD',
    acctOwnrNm:     'ACME CORPORATION',
    svcr:           'CHASUS33',
    stmtId:         `STMT-${todayISO().replace(/-/g,'')}-001`,
    seqNb:          '1',
    creDtTmStmt:    todayISO(),
    frDt:           todayISO(),
    toDt:           todayISO(),
    openingBal:     '5000000.00',
    openingBalCcy:  'USD',
    openingBalCd:   'OPBD',
    closingBal:     '4000000.00',
    closingBalCcy:  'USD',
    closingBalCd:   'CLBD',
    txAmt:          '1000000.00',
    txAmtCcy:       'USD',
    cdtDbtInd:      'DBIT',
    txId:           txId(),
    bookgDt:        todayISO(),
    valDt:          settlementDateISO(2),
    txDesc:         'PAYMENT FOR GOODS AND SERVICES',
    bankTxCd:       'PMNT',
  };
}

// ─── camt.054 defaults ────────────────────────────────────────────────────────
export function defaultCamt054Fields() {
  const now = new Date();
  const dd   = String(now.getUTCDate()).padStart(2,'0');
  const mm   = String(now.getUTCMonth()+1).padStart(2,'0');
  const yyyy = String(now.getUTCFullYear());
  const hh   = String(now.getUTCHours()).padStart(2,'0');
  const min  = String(now.getUTCMinutes()).padStart(2,'0');
  const ss   = String(now.getUTCSeconds()).padStart(2,'0');
  const yy   = yyyy.slice(2);
  const dateTag = `${yy}${mm}${dd}`;
  const ref     = Math.random().toString(36).toUpperCase().replace(/[^A-Z0-9]/g,'').slice(0,4);
  const amt     = '500000.00';
  return {
    msgId:          generateMessageId(),
    creDtTm:        nowISO(),
    ntfctnId:       `NTFCTN-${dateTag}-${ref}`,
    acctId:         `GB${Math.floor(10+Math.random()*89)}CHAS${Math.floor(10000000+Math.random()*89999999)}${Math.floor(10000000+Math.random()*89999999)}`,
    acctCcy:        'USD',
    acctOwnrNm:     'ACME CORPORATION',
    svcr:           'CHASUS33',
    ntryAmt:        amt,
    ntryCcy:        'USD',
    ntryDt:         todayISO(),
    valDt:          settlementDateISO(2),
    cdtDbtInd:      'CRDT',
    ntryRef:        `SVCRREF-${dateTag}-${ref}`,
    instrId:        instrId(),
    endToEndId:     `E2E-ACME-${dateTag}-${ref}`,
    txId:           `CHAS${dateTag}${hh}${min}${ss}NTFCTN`,
    uetr:           generateUETR(),
    dbtrNm:         'GLOBAL EXPORTS LIMITED',
    dbtrAcct:       `DE${Math.floor(10+Math.random()*89)}DEUT${Math.floor(10000000+Math.random()*89999999)}${Math.floor(10000000+Math.random()*89999999)}`,
    dbtrAgtBIC:     'DEUTDEDB',
    cdtrNm:         'ACME CORPORATION',
    cdtrAcct:       `GB${Math.floor(10+Math.random()*89)}CHAS${Math.floor(10000000+Math.random()*89999999)}${Math.floor(10000000+Math.random()*89999999)}`,
    cdtrAgtBIC:     'CHASUS33',
    purp:           'SUPP',
    bkTxCd:         'ICDT',
    rmtInf:         `CREDIT NOTIFICATION FOR PAYMENT OF USD ${amt} RECEIVED FROM GLOBAL EXPORTS LIMITED. INVOICE REF: INV-${yyyy}-${Math.floor(1000+Math.random()*9000)}. VALUE DATE ${dd}/${mm}/${yyyy}.`,
    addtlNtryInf:   `SWIFT CREDIT TRANSFER RECEIVED ${dd}/${mm}/${yyyy} ${hh}:${min}:${ss} UTC`,
  };
}

// ─── camt.056 defaults ────────────────────────────────────────────────────────
export function defaultCamt056Fields() {
  return {
    msgId:          generateMessageId(),
    creDtTm:        nowISO(),
    cxlId:          `CXL-${Date.now().toString().slice(-8)}`,
    orgnlMsgId:     generateMessageId(),
    orgnlMsgNmId:   'pacs.008.001.10',
    orgnlInstrId:   instrId(),
    orgnlEndToEndId:endToEndId(),
    orgnlUETR:      generateUETR(),
    orgnlIntrBkSttlmAmt: '1000000.00',
    orgnlIntrBkSttlmCcy: 'USD',
    orgnlIntrBkSttlmDt:  todayISO(),
    cxlRsnCd:       'DUPL',
    cxlRsnAddlInf:  'Duplicate payment instruction identified. Please cancel and return funds.',
  };
}

// ─── camt.029 defaults ────────────────────────────────────────────────────────
export function defaultCamt029Fields() {
  return {
    msgId:          generateMessageId(),
    creDtTm:        nowISO(),
    orgnlMsgId:     generateMessageId(),
    orgnlMsgNmId:   'pacs.008.001.10',
    orgnlInstrId:   instrId(),
    orgnlEndToEndId:endToEndId(),
    orgnlUETR:      generateUETR(),
    rsltnOfInvstgtnSts: 'CNCL',
    cxlStsRsnCd:    'DUPL',
    rsltnAddlInf:   'Investigation resolved. Original transaction cancelled as duplicate.',
    intrBkSttlmAmt: '1000000.00',
    intrBkSttlmCcy: 'USD',
    intrBkSttlmDt:  todayISO(),
  };
}

// ─── pacs.004 defaults ────────────────────────────────────────────────────────
export function defaultPacs004Fields() {
  return {
    msgId:               generateMessageId(),
    creDtTm:             nowISO(),
    nbOfTxs:             '1',
    sttlmDt:             settlementDateISO(2),
    orgnlMsgId:          generateMessageId(),
    orgnlMsgNmId:        'pacs.008.001.02',
    rtrId:               `RTR-${Date.now().toString().slice(-8)}`,
    orgnlEndToEndId:     endToEndId(),
    orgnlUETR:           generateUETR(),
    rtrdIntrBkSttlmAmt:  '1000000.00',
    rtrdIntrBkSttlmCcy:  'USD',
    rsnCd:               'AC04',
    addtlRsnInf:         'Account closed. Please return funds to originator.',
    instgAgt:            'CHASUS33',
    instdAgt:            'BARCGB22',
    dbtrNm:              'ACME CORPORATION',
    cdtrNm:              'GLOBAL EXPORTS LIMITED',
  };
}

// ─── pacs.009 defaults ────────────────────────────────────────────────────────
export function defaultPacs009Fields() {
  return {
    msgId:           generateMessageId(),
    creDtTm:         nowISO(),
    nbOfTxs:         '1',
    sttlmMtd:        'INDA',
    sttlmDt:         settlementDateISO(2),
    instrId:         instrId(),
    endToEndId:      endToEndId(),
    uetr:            generateUETR(),
    intrBkSttlmAmt:  '5000000.00',
    intrBkSttlmCcy:  'USD',
    chrgBr:          'SHAR',
    instgAgt:        'CHASUS33',
    instdAgt:        'DEUTDEDB',
    dbtrNm:          'JPMORGAN CHASE BANK N.A.',
    cdtrNm:          'DEUTSCHE BANK AG',
    purp:            'INTC',
    rmtInf:          'Interbank liquidity transfer per standing instruction',
  };
}

// ─── pain.001 defaults ────────────────────────────────────────────────────────
export function defaultPain001Fields() {
  return {
    msgId:           generateMessageId(),
    creDtTm:         nowISO(),
    nbOfTxs:         '1',
    ctrlSum:         '50000.00',
    initgPtyNm:      'ACME CORPORATION',
    pmtInfId:        `PMTINF-${Date.now().toString().slice(-8)}`,
    pmtMtd:          'TRF',
    reqdExctnDt:     settlementDateISO(1),
    dbtrNm:          'ACME CORPORATION',
    dbtrAcct:        `DE${Math.floor(10+Math.random()*89)}DEUT${Math.floor(10000000+Math.random()*89999999)}${Math.floor(10000000+Math.random()*89999999)}`,
    dbtrAgtBIC:      'DEUTDEDB',
    cdtrNm:          'GLOBAL EXPORTS LIMITED',
    cdtrAcct:        `GB${Math.floor(10+Math.random()*89)}BARC${Math.floor(10000000+Math.random()*89999999)}${Math.floor(10000000+Math.random()*89999999)}`,
    cdtrAgtBIC:      'BARCGB22',
    instrAmt:        '50000.00',
    instrCcy:        'EUR',
    endToEndId:      endToEndId(),
    purp:            'SUPP',
    rmtInf:          `Payment for invoice INV-${new Date().getFullYear()}-${Math.floor(1000+Math.random()*9000)} dated ${todayISO()}`,
  };
}

// ─── pain.002 defaults ────────────────────────────────────────────────────────
export function defaultPain002Fields() {
  return {
    msgId:              generateMessageId(),
    creDtTm:            nowISO(),
    orgnlMsgId:         generateMessageId(),
    orgnlMsgNmId:       'pain.001.001.09',
    orgnlNbOfTxs:       '1',
    orgnlCtrlSum:       '50000.00',
    grpSts:             'ACCP',
    orgnlEndToEndId:    endToEndId(),
    txSts:              'ACSP',
    rsnCd:              '',
    addtlStsRsnInf:     'Payment accepted and queued for processing.',
    initgPtyNm:         'ACME CORPORATION',
  };
}

// ─── pin.001 defaults ─────────────────────────────────────────────────────────
export function defaultPin001Fields() {
  return {
    msgId:          generateMessageId(),
    creDtTm:        nowISO(),
    ntfctnId:       `NTFCTN-${Date.now().toString().slice(-8)}`,
    ntfctnPurp:     'NEWT',
    orgnlMsgId:     generateMessageId(),
    orgnlMsgNmId:   'pacs.008.001.10',
    orgnlUETR:      generateUETR(),
    ntfctnSts:      'RCVD',
    ntfctnAddlInf:  'Payment instruction received and being processed by the intermediary bank.',
    intrBkSttlmAmt: '1000000.00',
    intrBkSttlmCcy: 'USD',
    intrBkSttlmDt:  settlementDateISO(2),
    dbtrAgtBIC:     'CHASUS33',
    cdtrAgtBIC:     'BARCGB22',
  };
}

// ─── pin.002 defaults ─────────────────────────────────────────────────────────
export function defaultPin002Fields() {
  return {
    msgId:          generateMessageId(),
    creDtTm:        nowISO(),
    ntfctnId:       `NTFCTN-${Date.now().toString().slice(-8)}`,
    orgnlNtfctnId:  `NTFCTN-${(Date.now()-1000).toString().slice(-8)}`,
    ntfctnPurp:     'NEWT',
    ntfctnSts:      'ACCP',
    ntfctnAddlInf:  'Payment instruction notification acknowledged and accepted for processing.',
    intrBkSttlmAmt: '1000000.00',
    intrBkSttlmCcy: 'USD',
    intrBkSttlmDt:  settlementDateISO(2),
    dbtrAgtBIC:     'CHASUS33',
    cdtrAgtBIC:     'BARCGB22',
  };
}

// ─── Master auto-fill dispatcher ─────────────────────────────────────────────
export function getDefaultFields(msgType: string): Record<string, string> {
  switch (msgType) {
    case 'MT700': return defaultMT700Fields() as unknown as Record<string, string>;
    case 'MT705': return defaultMT705Fields() as unknown as Record<string, string>;
    case 'MT760': return defaultMT760Fields() as unknown as Record<string, string>;
    case 'MT199': return defaultMT199Fields() as unknown as Record<string, string>;
    case 'MT799': return defaultMT799Fields() as unknown as Record<string, string>;
    case 'pacs.008': return defaultPacs008Fields();
    case 'pacs.009': return defaultPacs009Fields();
    case 'pacs.004': return defaultPacs004Fields();
    case 'pacs.002': return defaultPacs002Fields();
    case 'camt.056': return defaultCamt056Fields();
    case 'camt.029': return defaultCamt029Fields();
    case 'camt.053': return defaultCamt053Fields();
    case 'camt.054': return defaultCamt054Fields();
    case 'pain.001': return defaultPain001Fields();
    case 'pain.002': return defaultPain002Fields();
    case 'pin.001':  return defaultPin001Fields();
    case 'pin.002':  return defaultPin002Fields();
    default: return {};
  }
}

// ─── Common bank BIC quick-picks ─────────────────────────────────────────────
export const BANK_BICS = [
  { bic: 'CHASUS33', name: 'JPMorgan Chase',      country: 'US' },
  { bic: 'CITIUS33', name: 'Citibank N.A.',        country: 'US' },
  { bic: 'BOFAUS3N', name: 'Bank of America',      country: 'US' },
  { bic: 'WFBIUS6S', name: 'Wells Fargo',          country: 'US' },
  { bic: 'BARCGB22', name: 'Barclays Bank',        country: 'GB' },
  { bic: 'HBUKGB4B', name: 'HSBC Bank UK',         country: 'GB' },
  { bic: 'NWBKGB2L', name: 'NatWest Bank',         country: 'GB' },
  { bic: 'LLOYgb2L', name: 'Lloyds Bank',          country: 'GB' },
  { bic: 'DEUTDEDB', name: 'Deutsche Bank',        country: 'DE' },
  { bic: 'COBADEFF', name: 'Commerzbank',          country: 'DE' },
  { bic: 'BNPAFRPP', name: 'BNP Paribas',          country: 'FR' },
  { bic: 'SOGEFRPP', name: 'Société Générale',     country: 'FR' },
  { bic: 'UBSWCHZH', name: 'UBS AG',               country: 'CH' },
  { bic: 'CRESCHZZ', name: 'Credit Suisse',        country: 'CH' },
  { bic: 'INGBNL2A', name: 'ING Bank',             country: 'NL' },
  { bic: 'ABNANL2A', name: 'ABN AMRO',             country: 'NL' },
  { bic: 'ICBKCNBJ', name: 'ICBC',                 country: 'CN' },
  { bic: 'BKCHCNBJ', name: 'Bank of China',        country: 'CN' },
  { bic: 'MHCBJPJT', name: 'Mizuho Bank',          country: 'JP' },
  { bic: 'BOTKJPJT', name: 'MUFG Bank',            country: 'JP' },
  { bic: 'ARABAEAA', name: 'Arab Bank UAE',         country: 'AE' },
  { bic: 'EBILAEAD', name: 'Emirates Bank',        country: 'AE' },
  { bic: 'SBININBB', name: 'State Bank of India',  country: 'IN' },
  { bic: 'HDFCINBB', name: 'HDFC Bank',            country: 'IN' },
  { bic: 'SWBKZAJJ', name: 'Standard Bank SA',     country: 'ZA' },
];
