import { SWIFTMessage, SearchFilters } from '../types';

const STORAGE_KEY = 'swiftdesk_messages';

export function loadMessages(): SWIFTMessage[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    return JSON.parse(raw) as SWIFTMessage[];
  } catch {
    return [];
  }
}

export function saveMessages(messages: SWIFTMessage[]): void {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(messages));
}

export function saveMessage(message: SWIFTMessage): SWIFTMessage[] {
  const messages = loadMessages();
  const idx = messages.findIndex(m => m.id === message.id);
  if (idx >= 0) {
    messages[idx] = { ...message, updatedAt: new Date().toISOString() };
  } else {
    messages.unshift(message);
  }
  saveMessages(messages);
  return messages;
}

export function deleteMessage(id: string): SWIFTMessage[] {
  const messages = loadMessages().filter(m => m.id !== id);
  saveMessages(messages);
  return messages;
}

export function searchMessages(messages: SWIFTMessage[], filters: SearchFilters): SWIFTMessage[] {
  return messages.filter(m => {
    const q = filters.query.toLowerCase();
    if (q) {
      const searchable = [
        m.identifiers.transactionRef,
        m.identifiers.messageId,
        m.identifiers.uetr,
        m.senderBIC,
        m.receiverBIC,
        m.description ?? '',
      ].join(' ').toLowerCase();
      if (!searchable.includes(q)) return false;
    }
    if (filters.messageType && m.messageType !== filters.messageType) return false;
    if (filters.bank) {
      const bankQ = filters.bank.toLowerCase();
      if (!m.senderBIC.toLowerCase().includes(bankQ) && !m.receiverBIC.toLowerCase().includes(bankQ)) return false;
    }
    if (filters.status && m.status !== filters.status) return false;
    if (filters.dateFrom) {
      if (new Date(m.createdAt) < new Date(filters.dateFrom)) return false;
    }
    if (filters.dateTo) {
      const to = new Date(filters.dateTo);
      to.setHours(23, 59, 59, 999);
      if (new Date(m.createdAt) > to) return false;
    }
    return true;
  });
}
