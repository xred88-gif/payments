/**
 * BIC / SWIFT Code Validator — ISO 9362:2022
 *
 * Format:  AAAA BB CC DDD
 *  AAAA  — Institution code  (4 alpha)
 *  BB    — Country code      (2 alpha, ISO 3166-1)
 *  CC    — Location code     (2 alphanumeric)
 *  DDD   — Branch code       (3 alphanumeric, optional — "XXX" = primary)
 *
 * Valid lengths: 8 (no branch) or 11 (with branch)
 */

/** All valid ISO 3166-1 alpha-2 country codes */
const VALID_COUNTRIES = new Set([
  'AD','AE','AF','AG','AI','AL','AM','AO','AQ','AR','AS','AT','AU','AW','AX',
  'AZ','BA','BB','BD','BE','BF','BG','BH','BI','BJ','BL','BM','BN','BO','BQ',
  'BR','BS','BT','BV','BW','BY','BZ','CA','CC','CD','CF','CG','CH','CI','CK',
  'CL','CM','CN','CO','CR','CU','CV','CW','CX','CY','CZ','DE','DJ','DK','DM',
  'DO','DZ','EC','EE','EG','EH','ER','ES','ET','FI','FJ','FK','FM','FO','FR',
  'GA','GB','GD','GE','GF','GG','GH','GI','GL','GM','GN','GP','GQ','GR','GS',
  'GT','GU','GW','GY','HK','HM','HN','HR','HT','HU','ID','IE','IL','IM','IN',
  'IO','IQ','IR','IS','IT','JE','JM','JO','JP','KE','KG','KH','KI','KM','KN',
  'KP','KR','KW','KY','KZ','LA','LB','LC','LI','LK','LR','LS','LT','LU','LV',
  'LY','MA','MC','MD','ME','MF','MG','MH','MK','ML','MM','MN','MO','MP','MQ',
  'MR','MS','MT','MU','MV','MW','MX','MY','MZ','NA','NC','NE','NF','NG','NI',
  'NL','NO','NP','NR','NU','NZ','OM','PA','PE','PF','PG','PH','PK','PL','PM',
  'PN','PR','PS','PT','PW','PY','QA','RE','RO','RS','RU','RW','SA','SB','SC',
  'SD','SE','SG','SH','SI','SJ','SK','SL','SM','SN','SO','SR','SS','ST','SV',
  'SX','SY','SZ','TC','TD','TF','TG','TH','TJ','TK','TL','TM','TN','TO','TR',
  'TT','TV','TW','TZ','UA','UG','UM','US','UY','UZ','VA','VC','VE','VG','VI',
  'VN','VU','WF','WS','XK','YE','YT','ZA','ZM','ZW',
]);

export type BICValidationResult = {
  valid: boolean;
  normalised: string;
  error?: string;
  institutionCode?: string;
  countryCode?: string;
  locationCode?: string;
  branchCode?: string;
  isPrimary?: boolean;   // branch === 'XXX' or no branch
  isTest?: boolean;      // location code ends in '0' (SWIFT test BIC rule)
  length?: 8 | 11;
};

/** Strip all whitespace and uppercase */
export function normaliseBIC(raw: string): string {
  return raw.replace(/\s+/g, '').toUpperCase();
}

export function validateBIC(raw: string): BICValidationResult {
  const bic = normaliseBIC(raw);

  if (!bic) return { valid: false, normalised: '', error: '' };

  // Length check
  if (bic.length !== 8 && bic.length !== 11) {
    return {
      valid: false,
      normalised: bic,
      error: `BIC must be 8 or 11 characters (got ${bic.length})`,
    };
  }

  // Institution code — 4 alpha
  const instCode = bic.slice(0, 4);
  if (!/^[A-Z]{4}$/.test(instCode)) {
    return {
      valid: false,
      normalised: bic,
      error: 'Institution code (chars 1–4) must be 4 letters',
    };
  }

  // Country code — 2 alpha, ISO 3166-1
  const country = bic.slice(4, 6);
  if (!/^[A-Z]{2}$/.test(country)) {
    return {
      valid: false,
      normalised: bic,
      error: 'Country code (chars 5–6) must be 2 letters',
    };
  }
  if (!VALID_COUNTRIES.has(country)) {
    return {
      valid: false,
      normalised: bic,
      error: `"${country}" is not a valid ISO 3166-1 country code`,
    };
  }

  // Location code — 2 alphanumeric
  const location = bic.slice(6, 8);
  if (!/^[A-Z0-9]{2}$/.test(location)) {
    return {
      valid: false,
      normalised: bic,
      error: 'Location code (chars 7–8) must be 2 alphanumeric characters',
    };
  }

  // Branch code — 3 alphanumeric (if present)
  const branch = bic.length === 11 ? bic.slice(8, 11) : undefined;
  if (branch !== undefined && !/^[A-Z0-9]{3}$/.test(branch)) {
    return {
      valid: false,
      normalised: bic,
      error: 'Branch code (chars 9–11) must be 3 alphanumeric characters',
    };
  }

  const isTest = location[1] === '0';
  const isPrimary = !branch || branch === 'XXX';

  return {
    valid: true,
    normalised: bic,
    institutionCode: instCode,
    countryCode: country,
    locationCode: location,
    branchCode: branch ?? 'XXX',
    isPrimary,
    isTest,
    length: bic.length === 8 ? 8 : 11,
    error: undefined,
  };
}

/**
 * Auto-append XXX branch code to 8-char BIC.
 * CHASUS33 → CHASUS33XXX
 * CHASUS33XXX → CHASUS33XXX (unchanged)
 * Anything else → unchanged
 */
export function ensureXXX(raw: string): string {
  const b = normaliseBIC(raw);
  if (b.length === 8) return b + 'XXX';
  return b;
}

/** Format BIC for display: CHAS US 33 XXX */
export function formatBICDisplay(bic: string): string {
  const b = normaliseBIC(bic);
  if (b.length === 8)  return `${b.slice(0,4)} ${b.slice(4,6)} ${b.slice(6,8)}`;
  if (b.length === 11) return `${b.slice(0,4)} ${b.slice(4,6)} ${b.slice(6,8)} ${b.slice(8,11)}`;
  return b;
}
