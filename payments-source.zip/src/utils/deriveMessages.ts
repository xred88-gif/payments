/**
 * Derive related messages from a source message.
 * pacs.008 → camt.054 Debit/Credit Notification
 */

import { v4 as uuidv4 } from 'uuid';
import { SWIFTMessage, Pacs008Fields, Camt054Fields } from '../types';
import { buildISO20022Message } from './iso20022Builder';
import { generateMessageId, generateTransactionRef, generateSessionId, generateRoutingId } from './identifiers';

function pad2(n: number) { return String(n).padStart(2, '0'); }

function fmtDate(iso: string): string {
  try {
    const d = new Date(iso);
    return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
  } catch { return iso; }
}

/**
 * Derive a camt.054 Debit/Credit Notification from a saved pacs.008 message.
 * The creditor bank sends a camt.054 to notify the creditor's account.
 */
export function deriveCamt054FromPacs008(src: SWIFTMessage): SWIFTMessage {
  const pacs = src.isoFields as Pacs008Fields;
  const now  = new Date().toISOString();
  const msgId = generateMessageId();
  const uetr  = uuidv4();

  const camt054: Camt054Fields = {
    msgId,
    creDtTm:      now,
    acctId:       pacs.cdtrAcct        || '',
    acctCcy:      pacs.intrBkSttlmCcy  || 'USD',
    acctOwnrNm:   pacs.cdtrNm          || '',
    svcr:         pacs.cdtrAgtBIC      || '',
    ntfctnId:     `NTF-${msgId.slice(-10)}`,
    ntryAmt:      pacs.intrBkSttlmAmt  || '0.00',
    ntryCcy:      pacs.intrBkSttlmCcy  || 'USD',
    ntryDt:       fmtDate(pacs.sttlmDt || now),
    valDt:        fmtDate(pacs.sttlmDt || now),
    cdtDbtInd:    'CRDT',
    ntryRef:      pacs.instrId         || '',
    instrId:      pacs.instrId         || '',
    endToEndId:   pacs.endToEndId      || '',
    txId:         pacs.instrId         || '',
    uetr:         pacs.uetr            || uetr,
    dbtrNm:       pacs.dbtrNm          || '',
    dbtrAcct:     pacs.dbtrAcct        || '',
    dbtrAgtBIC:   pacs.dbtrAgtBIC      || '',
    cdtrNm:       pacs.cdtrNm          || '',
    cdtrAcct:     pacs.cdtrAcct        || '',
    cdtrAgtBIC:   pacs.cdtrAgtBIC      || '',
    rmtInf:       pacs.rmtInf          || '',
    purp:         pacs.purp            || 'SUPP',
    bkTxCd:       'PMNT',
    addtlNtryInf: `Notification of credit. Original Instr: ${pacs.instrId || ''}`,
  };

  const identifiers = {
    uetr:           pacs.uetr || uetr,
    transactionRef: generateTransactionRef(),
    messageId:      msgId,
    sessionId:      generateSessionId(),
    routingId:      generateRoutingId(),
  };

  const sender   = pacs.cdtrAgtBIC || src.receiverBIC || '';
  const receiver = pacs.dbtrAgtBIC || src.senderBIC   || '';

  // Build a full SWIFTMessage so we can pass it to buildISO20022Message
  const derived: SWIFTMessage = {
    id:          `${src.id}-camt054-${Date.now()}`,
    messageType: 'camt.054',
    standard:    'ISO20022',
    status:      'final',
    senderBIC:   sender,
    receiverBIC: receiver,
    rawMessage:  '',           // filled below
    identifiers,
    isoFields:   camt054,
    description: `camt.054 — derived from pacs.008 ref ${src.identifiers.transactionRef}`,
    createdAt:   now,
    updatedAt:   now,
    linkedTo:    src.id,
  };

  derived.rawMessage = buildISO20022Message(derived);
  return derived;
}
