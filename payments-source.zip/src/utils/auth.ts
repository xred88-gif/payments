export interface User {
  id: string;
  username: string;
  fullName: string;
  email: string;
  role: 'admin' | 'operator' | 'viewer';
  institution: string;
  createdAt: string;
  lastLogin?: string;
  avatar?: string; // initials color seed
}

interface StoredUser extends User {
  passwordHash: string;
}

const USERS_KEY   = 'swiftdesk_users';
const SESSION_KEY = 'swiftdesk_session';

// Very simple deterministic "hash" (NOT for real security — demo only)
function simpleHash(password: string): string {
  let h = 0x811c9dc5;
  for (let i = 0; i < password.length; i++) {
    h ^= password.charCodeAt(i);
    h = (h * 0x01000193) >>> 0;
  }
  return h.toString(16).padStart(8, '0');
}

function loadStoredUsers(): StoredUser[] {
  try {
    const raw = localStorage.getItem(USERS_KEY);
    if (!raw) return [];
    return JSON.parse(raw) as StoredUser[];
  } catch {
    return [];
  }
}

function saveStoredUsers(users: StoredUser[]): void {
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
}


export interface AuthResult {
  ok: boolean;
  error?: string;
  user?: User;
}

export function login(username: string, password: string): AuthResult {
  const users = loadStoredUsers();
  const found = users.find(u => u.username.toLowerCase() === username.toLowerCase().trim());
  if (!found) return { ok: false, error: 'Username not found.' };
  if (found.passwordHash !== simpleHash(password)) return { ok: false, error: 'Incorrect password.' };

  // Update last login
  found.lastLogin = new Date().toISOString();
  saveStoredUsers(users);

  const { passwordHash: _ph, ...user } = found;
  localStorage.setItem(SESSION_KEY, JSON.stringify(user));
  return { ok: true, user };
}

export function register(
  username: string,
  password: string,
  fullName: string,
  email: string,
  institution: string,
  role: User['role'] = 'operator',
): AuthResult {
  const users = loadStoredUsers();
  if (users.find(u => u.username.toLowerCase() === username.toLowerCase().trim())) {
    return { ok: false, error: 'Username already exists.' };
  }
  if (users.find(u => u.email.toLowerCase() === email.toLowerCase().trim())) {
    return { ok: false, error: 'Email already registered.' };
  }
  if (username.trim().length < 3) return { ok: false, error: 'Username must be at least 3 characters.' };
  if (password.length < 6)        return { ok: false, error: 'Password must be at least 6 characters.' };
  if (!fullName.trim())           return { ok: false, error: 'Full name is required.' };
  if (!email.includes('@'))       return { ok: false, error: 'Please enter a valid email.' };

  const colors = ['blue', 'emerald', 'violet', 'amber', 'rose', 'cyan'];
  const newUser: StoredUser = {
    id: `usr-${Date.now()}`,
    username: username.trim(),
    fullName: fullName.trim(),
    email: email.trim().toLowerCase(),
    role,
    institution: institution.trim() || 'N/A',
    createdAt: new Date().toISOString(),
    avatar: colors[users.length % colors.length],
    passwordHash: simpleHash(password),
  };
  users.push(newUser);
  saveStoredUsers(users);

  const { passwordHash: _ph, ...user } = newUser;
  localStorage.setItem(SESSION_KEY, JSON.stringify(user));
  return { ok: true, user };
}

export function logout(): void {
  localStorage.removeItem(SESSION_KEY);
}

export function getSession(): User | null {
  try {
    const raw = localStorage.getItem(SESSION_KEY);
    if (!raw) return null;
    return JSON.parse(raw) as User;
  } catch {
    return null;
  }
}

export function updatePassword(userId: string, currentPw: string, newPw: string): AuthResult {
  const users = loadStoredUsers();
  const idx = users.findIndex(u => u.id === userId);
  if (idx < 0) return { ok: false, error: 'User not found.' };
  if (users[idx].passwordHash !== simpleHash(currentPw)) return { ok: false, error: 'Current password is incorrect.' };
  if (newPw.length < 6) return { ok: false, error: 'New password must be at least 6 characters.' };
  users[idx].passwordHash = simpleHash(newPw);
  saveStoredUsers(users);
  return { ok: true };
}

export function avatarColor(seed?: string): { bg: string; text: string } {
  const map: Record<string, { bg: string; text: string }> = {
    blue:    { bg: 'bg-blue-600',    text: 'text-white' },
    emerald: { bg: 'bg-emerald-600', text: 'text-white' },
    violet:  { bg: 'bg-violet-600',  text: 'text-white' },
    amber:   { bg: 'bg-amber-500',   text: 'text-white' },
    rose:    { bg: 'bg-rose-600',    text: 'text-white' },
    cyan:    { bg: 'bg-cyan-600',    text: 'text-white' },
  };
  return map[seed ?? 'blue'] ?? map['blue'];
}

export function initials(fullName: string): string {
  return fullName
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map(n => n[0].toUpperCase())
    .join('');
}

