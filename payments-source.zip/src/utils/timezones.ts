/**
 * BIC Country Code → Timezone + City resolver
 * Maps the 5th–6th chars of a BIC (ISO 3166-1 country code) to timezone data
 */

export interface TimezoneInfo {
  timezone: string;       // IANA timezone
  city: string;           // Financial centre city
  country: string;        // Full country name
  utcOffset: string;      // e.g. "+05:30"
  currentTime: string;    // HH:MM local
  localDateTime: string;  // Full ISO local
  flag: string;           // emoji flag
}

const BIC_COUNTRY_MAP: Record<string, { tz: string; city: string; country: string; flag: string }> = {
  // Americas
  US: { tz: 'America/New_York',       city: 'New York',         country: 'United States of America',  flag: '🇺🇸' },
  CA: { tz: 'America/Toronto',        city: 'Toronto',          country: 'Canada',                    flag: '🇨🇦' },
  MX: { tz: 'America/Mexico_City',    city: 'Mexico City',      country: 'Mexico',                    flag: '🇲🇽' },
  BR: { tz: 'America/Sao_Paulo',      city: 'São Paulo',        country: 'Brazil',                    flag: '🇧🇷' },
  AR: { tz: 'America/Argentina/Buenos_Aires', city: 'Buenos Aires', country: 'Argentina',             flag: '🇦🇷' },
  CL: { tz: 'America/Santiago',       city: 'Santiago',         country: 'Chile',                     flag: '🇨🇱' },
  CO: { tz: 'America/Bogota',         city: 'Bogotá',           country: 'Colombia',                  flag: '🇨🇴' },
  PE: { tz: 'America/Lima',           city: 'Lima',             country: 'Peru',                      flag: '🇵🇪' },
  // Europe
  GB: { tz: 'Europe/London',          city: 'London',           country: 'United Kingdom',            flag: '🇬🇧' },
  DE: { tz: 'Europe/Berlin',          city: 'Frankfurt',        country: 'Germany',                   flag: '🇩🇪' },
  FR: { tz: 'Europe/Paris',           city: 'Paris',            country: 'France',                    flag: '🇫🇷' },
  CH: { tz: 'Europe/Zurich',          city: 'Zurich',           country: 'Switzerland',               flag: '🇨🇭' },
  NL: { tz: 'Europe/Amsterdam',       city: 'Amsterdam',        country: 'Netherlands',               flag: '🇳🇱' },
  BE: { tz: 'Europe/Brussels',        city: 'Brussels',         country: 'Belgium',                   flag: '🇧🇪' },
  IT: { tz: 'Europe/Rome',            city: 'Milan',            country: 'Italy',                     flag: '🇮🇹' },
  ES: { tz: 'Europe/Madrid',          city: 'Madrid',           country: 'Spain',                     flag: '🇪🇸' },
  PT: { tz: 'Europe/Lisbon',          city: 'Lisbon',           country: 'Portugal',                  flag: '🇵🇹' },
  SE: { tz: 'Europe/Stockholm',       city: 'Stockholm',        country: 'Sweden',                    flag: '🇸🇪' },
  NO: { tz: 'Europe/Oslo',            city: 'Oslo',             country: 'Norway',                    flag: '🇳🇴' },
  DK: { tz: 'Europe/Copenhagen',      city: 'Copenhagen',       country: 'Denmark',                   flag: '🇩🇰' },
  FI: { tz: 'Europe/Helsinki',        city: 'Helsinki',         country: 'Finland',                   flag: '🇫🇮' },
  PL: { tz: 'Europe/Warsaw',          city: 'Warsaw',           country: 'Poland',                    flag: '🇵🇱' },
  AT: { tz: 'Europe/Vienna',          city: 'Vienna',           country: 'Austria',                   flag: '🇦🇹' },
  LU: { tz: 'Europe/Luxembourg',      city: 'Luxembourg City',  country: 'Luxembourg',                flag: '🇱🇺' },
  IE: { tz: 'Europe/Dublin',          city: 'Dublin',           country: 'Ireland',                   flag: '🇮🇪' },
  GR: { tz: 'Europe/Athens',          city: 'Athens',           country: 'Greece',                    flag: '🇬🇷' },
  TR: { tz: 'Europe/Istanbul',        city: 'Istanbul',         country: 'Turkey',                    flag: '🇹🇷' },
  RU: { tz: 'Europe/Moscow',          city: 'Moscow',           country: 'Russia',                    flag: '🇷🇺' },
  CZ: { tz: 'Europe/Prague',          city: 'Prague',           country: 'Czech Republic',            flag: '🇨🇿' },
  HU: { tz: 'Europe/Budapest',        city: 'Budapest',         country: 'Hungary',                   flag: '🇭🇺' },
  RO: { tz: 'Europe/Bucharest',       city: 'Bucharest',        country: 'Romania',                   flag: '🇷🇴' },
  // Middle East
  AE: { tz: 'Asia/Dubai',             city: 'Dubai',            country: 'United Arab Emirates',      flag: '🇦🇪' },
  SA: { tz: 'Asia/Riyadh',            city: 'Riyadh',           country: 'Saudi Arabia',              flag: '🇸🇦' },
  KW: { tz: 'Asia/Kuwait',            city: 'Kuwait City',      country: 'Kuwait',                    flag: '🇰🇼' },
  QA: { tz: 'Asia/Qatar',             city: 'Doha',             country: 'Qatar',                     flag: '🇶🇦' },
  BH: { tz: 'Asia/Bahrain',           city: 'Manama',           country: 'Bahrain',                   flag: '🇧🇭' },
  OM: { tz: 'Asia/Muscat',            city: 'Muscat',           country: 'Oman',                      flag: '🇴🇲' },
  IL: { tz: 'Asia/Jerusalem',         city: 'Tel Aviv',         country: 'Israel',                    flag: '🇮🇱' },
  JO: { tz: 'Asia/Amman',             city: 'Amman',            country: 'Jordan',                    flag: '🇯🇴' },
  LB: { tz: 'Asia/Beirut',            city: 'Beirut',           country: 'Lebanon',                   flag: '🇱🇧' },
  EG: { tz: 'Africa/Cairo',           city: 'Cairo',            country: 'Egypt',                     flag: '🇪🇬' },
  // Asia Pacific
  JP: { tz: 'Asia/Tokyo',             city: 'Tokyo',            country: 'Japan',                     flag: '🇯🇵' },
  CN: { tz: 'Asia/Shanghai',          city: 'Shanghai',         country: 'China',                     flag: '🇨🇳' },
  HK: { tz: 'Asia/Hong_Kong',         city: 'Hong Kong',        country: 'Hong Kong SAR',             flag: '🇭🇰' },
  SG: { tz: 'Asia/Singapore',         city: 'Singapore',        country: 'Singapore',                 flag: '🇸🇬' },
  AU: { tz: 'Australia/Sydney',       city: 'Sydney',           country: 'Australia',                 flag: '🇦🇺' },
  NZ: { tz: 'Pacific/Auckland',       city: 'Auckland',         country: 'New Zealand',               flag: '🇳🇿' },
  IN: { tz: 'Asia/Kolkata',           city: 'Mumbai',           country: 'India',                     flag: '🇮🇳' },
  KR: { tz: 'Asia/Seoul',             city: 'Seoul',            country: 'South Korea',               flag: '🇰🇷' },
  TW: { tz: 'Asia/Taipei',            city: 'Taipei',           country: 'Taiwan',                    flag: '🇹🇼' },
  TH: { tz: 'Asia/Bangkok',           city: 'Bangkok',          country: 'Thailand',                  flag: '🇹🇭' },
  MY: { tz: 'Asia/Kuala_Lumpur',      city: 'Kuala Lumpur',     country: 'Malaysia',                  flag: '🇲🇾' },
  ID: { tz: 'Asia/Jakarta',           city: 'Jakarta',          country: 'Indonesia',                 flag: '🇮🇩' },
  PH: { tz: 'Asia/Manila',            city: 'Manila',           country: 'Philippines',               flag: '🇵🇭' },
  PK: { tz: 'Asia/Karachi',           city: 'Karachi',          country: 'Pakistan',                  flag: '🇵🇰' },
  BD: { tz: 'Asia/Dhaka',             city: 'Dhaka',            country: 'Bangladesh',                flag: '🇧🇩' },
  LK: { tz: 'Asia/Colombo',           city: 'Colombo',          country: 'Sri Lanka',                 flag: '🇱🇰' },
  VN: { tz: 'Asia/Ho_Chi_Minh',       city: 'Ho Chi Minh City', country: 'Vietnam',                   flag: '🇻🇳' },
  // Africa
  ZA: { tz: 'Africa/Johannesburg',    city: 'Johannesburg',     country: 'South Africa',              flag: '🇿🇦' },
  NG: { tz: 'Africa/Lagos',           city: 'Lagos',            country: 'Nigeria',                   flag: '🇳🇬' },
  KE: { tz: 'Africa/Nairobi',         city: 'Nairobi',          country: 'Kenya',                     flag: '🇰🇪' },
  GH: { tz: 'Africa/Accra',           city: 'Accra',            country: 'Ghana',                     flag: '🇬🇭' },
  MA: { tz: 'Africa/Casablanca',      city: 'Casablanca',       country: 'Morocco',                   flag: '🇲🇦' },
  TZ: { tz: 'Africa/Dar_es_Salaam',   city: 'Dar es Salaam',    country: 'Tanzania',                  flag: '🇹🇿' },
  ET: { tz: 'Africa/Addis_Ababa',     city: 'Addis Ababa',      country: 'Ethiopia',                  flag: '🇪🇹' },
};

/** Extract country code from BIC (positions 4–5, 0-indexed) */
export function bicToCountryCode(bic: string): string {
  if (!bic || bic.length < 6) return 'GB';
  return bic.slice(4, 6).toUpperCase();
}

/** Get timezone info from a BIC */
export function getTimezoneFromBIC(bic: string): TimezoneInfo {
  const cc = bicToCountryCode(bic);
  const entry = BIC_COUNTRY_MAP[cc] ?? BIC_COUNTRY_MAP['GB'];

  try {
    const now = new Date();

    // Get UTC offset string
    const offsetFormatter = new Intl.DateTimeFormat('en-US', {
      timeZone: entry.tz,
      timeZoneName: 'shortOffset',
    });
    const parts = offsetFormatter.formatToParts(now);
    const offsetPart = parts.find(p => p.type === 'timeZoneName')?.value ?? 'UTC';
    const utcOffset = offsetPart === 'GMT' ? '+00:00' : offsetPart.replace('GMT', '');

    // Current local time HH:MM
    const timeFormatter = new Intl.DateTimeFormat('en-GB', {
      timeZone: entry.tz,
      hour: '2-digit',
      minute: '2-digit',
      hour12: false,
    });
    const currentTime = timeFormatter.format(now);

    // Full local ISO-like string
    const fullFormatter = new Intl.DateTimeFormat('en-GB', {
      timeZone: entry.tz,
      year: 'numeric', month: '2-digit', day: '2-digit',
      hour: '2-digit', minute: '2-digit', second: '2-digit',
      hour12: false,
    });
    const localDateTime = fullFormatter.format(now).replace(',', '');

    return {
      timezone: entry.tz,
      city: entry.city,
      country: entry.country,
      utcOffset,
      currentTime,
      localDateTime,
      flag: entry.flag,
    };
  } catch {
    return {
      timezone: 'UTC',
      city: 'London',
      country: 'United Kingdom',
      utcOffset: '+00:00',
      currentTime: new Date().toUTCString().slice(17, 22),
      localDateTime: new Date().toISOString(),
      flag: '🇬🇧',
    };
  }
}

/** All country codes we support */
export const SUPPORTED_COUNTRIES = Object.keys(BIC_COUNTRY_MAP);
