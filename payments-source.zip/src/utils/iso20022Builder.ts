/**
 * ISO 20022 XML Message Builder
 * Alliance Access 7.7.70 format — zero indentation, tags at column 0
 */

import {
  Pacs008Fields, Pacs002Fields, Pacs004Fields, Pacs009Fields,
  Camt053Fields, Camt054Fields, Camt056Fields, Camt029Fields,
  Camt052Fields, Camt060Fields,
  Pain001Fields, Pain002Fields,
  Pin001Fields, Pin002Fields,
  ISO20022MessageType,
  SWIFTMessage,
} from '../types';

// ─── Namespace / MsgDefIdr Registry ──────────────────────────────────────────
const MSG_DEF: Record<ISO20022MessageType, string> = {
  'pacs.008': 'pacs.008.001.02',
  'pacs.002': 'pacs.002.001.03',
  'pacs.004': 'pacs.004.001.09',
  'pacs.009': 'pacs.009.001.08',
  'pacs.010': 'pacs.010.001.04',
  'camt.053': 'camt.053.001.08',
  'camt.054': 'camt.054.001.08',
  'camt.056': 'camt.056.001.08',
  'camt.029': 'camt.029.001.09',
  'camt.052': 'camt.052.001.08',
  'camt.060': 'camt.060.001.06',
  'pain.001': 'pain.001.001.09',
  'pain.002': 'pain.002.001.10',
  'pin.001':  'admi.011.001.01',
  'pin.002':  'admi.012.001.01',
};

const NS_URI: Record<ISO20022MessageType, string> = {
  'pacs.008': 'urn:iso:std:iso:20022:tech:xsd:pacs.008.001.02',
  'pacs.002': 'urn:iso:std:iso:20022:tech:xsd:pacs.002.001.03',
  'pacs.004': 'urn:iso:std:iso:20022:tech:xsd:pacs.004.001.09',
  'pacs.009': 'urn:iso:std:iso:20022:tech:xsd:pacs.009.001.08',
  'pacs.010': 'urn:iso:std:iso:20022:tech:xsd:pacs.010.001.04',
  'camt.053': 'urn:iso:std:iso:20022:tech:xsd:camt.053.001.08',
  'camt.054': 'urn:iso:std:iso:20022:tech:xsd:camt.054.001.08',
  'camt.056': 'urn:iso:std:iso:20022:tech:xsd:camt.056.001.08',
  'camt.029': 'urn:iso:std:iso:20022:tech:xsd:camt.029.001.09',
  'camt.052': 'urn:iso:std:iso:20022:tech:xsd:camt.052.001.08',
  'camt.060': 'urn:iso:std:iso:20022:tech:xsd:camt.060.001.06',
  'pain.001': 'urn:iso:std:iso:20022:tech:xsd:pain.001.001.09',
  'pain.002': 'urn:iso:std:iso:20022:tech:xsd:pain.002.001.10',
  'pin.001':  'urn:iso:std:iso:20022:tech:xsd:admi.011.001.01',
  'pin.002':  'urn:iso:std:iso:20022:tech:xsd:admi.012.001.01',
};

const ROOT_ELEM: Record<ISO20022MessageType, string> = {
  'pacs.008': 'FIToFICstmrCdtTrf',
  'pacs.002': 'FIToFIPmtStsRpt',
  'pacs.004': 'PmtRtr',
  'pacs.009': 'FinInstnCdtTrf',
  'pacs.010': 'FinInstnDrctDbt',
  'camt.053': 'BkToCstmrStmt',
  'camt.054': 'BkToCstmrDbtCdtNtfctn',
  'camt.056': 'FIToFIPmtCxlReq',
  'camt.029': 'RsltnOfInvstgtn',
  'camt.052': 'BkToCstmrAcctRpt',
  'camt.060': 'AcctRptgReq',
  'pain.001': 'CstmrCdtTrfInitn',
  'pain.002': 'CstmrPmtStsRpt',
  'pin.001':  'SysEvtNtfctn',
  'pin.002':  'SysEvtAck',
};

// ─── XML Escape ───────────────────────────────────────────────────────────────
function esc(s: string): string {
  return (s ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

// ─── Zero-indent tag helpers ──────────────────────────────────────────────────
/** <Name>value</Name> */
function t(name: string, value: string): string {
  return `<${name}>${esc(value)}</${name}>`;
}
/** <Name attrs>value</Name> — inline attribute + value on one line */
function ta(name: string, attrs: string, value: string): string {
  return `<${name} ${attrs}>${esc(value)}</${name}>`;
}
/** <Name> */
function o(name: string, attrs = ''): string {
  return `<${name}${attrs ? ' ' + attrs : ''}>`;
}
/** </Name> */
function c(name: string): string {
  return `</${name}>`;
}
/** <head:Name>value</head:Name> */
function ht(name: string, value: string): string {
  return `<head:${name}>${esc(value)}</head:${name}>`;
}
/** <head:Name> */
function ho(name: string, attrs = ''): string {
  return `<head:${name}${attrs ? ' ' + attrs : ''}>`;
}
/** </head:Name> */
function hc(name: string): string {
  return `</head:${name}>`;
}

// ─── Date formatters ──────────────────────────────────────────────────────────
function pad2(n: number) { return String(n).padStart(2, '0'); }

/** → DD/MM/YYYYThh:mm:ss+01:00  (AppHdr CreDt) */
function dtWithOffset(iso: string): string {
  try {
    const d = new Date(iso);
    return `${pad2(d.getDate())}/${pad2(d.getMonth()+1)}/${d.getFullYear()}`
         + `T${pad2(d.getHours())}:${pad2(d.getMinutes())}:${pad2(d.getSeconds())}+01:00`;
  } catch { return iso; }
}

/** → DD/MM/YYYYThh:mm:ss  (body CreDtTm) */
function dtNoOffset(iso: string): string {
  try {
    const d = new Date(iso);
    return `${pad2(d.getDate())}/${pad2(d.getMonth()+1)}/${d.getFullYear()}`
         + `T${pad2(d.getHours())}:${pad2(d.getMinutes())}:${pad2(d.getSeconds())}`;
  } catch { return iso; }
}

/** → DD/MM/YYYY  (date-only fields) */
function dtDate(iso: string): string {
  try {
    const d = new Date(iso);
    return `${pad2(d.getDate())}/${pad2(d.getMonth()+1)}/${d.getFullYear()}`;
  } catch { return iso; }
}

// ─── AppHdr (head: namespace, zero indentation) ───────────────────────────────
function appHdr(
  sender   : string,
  receiver : string,
  msgType  : ISO20022MessageType,
  msgId    : string,
  creDtTm  : string,
): string {
  const sndBIC  = (sender   || '').padEnd(11, 'X').slice(0, 11);
  const rcvBIC  = (receiver || '').padEnd(11, 'X').slice(0, 11);
  const defId   = MSG_DEF[msgType];
  const dtFmt   = dtWithOffset(creDtTm);

  return [
    ho('AppHdr'),
    ho('Fr'),
    ho('FIId'),
    ho('FinInstnId'),
    ht('BICFI', sndBIC),
    hc('FinInstnId'),
    hc('FIId'),
    hc('Fr'),
    ho('To'),
    ho('FIId'),
    ho('FinInstnId'),
    ht('BICFI', rcvBIC),
    hc('FinInstnId'),
    hc('FIId'),
    hc('To'),
    ht('BizMsgIdr', msgId.slice(0, 35)),
    ht('MsgDefIdr', defId),
    ht('BizSvc', 'swift.cbprplus.01'),
    ht('CreDt', dtFmt),
    hc('AppHdr'),
  ].join('\n');
}

// ─── Outer envelope wrapper ───────────────────────────────────────────────────
function wrap(
  msgType  : ISO20022MessageType,
  sender   : string,
  receiver : string,
  msgId    : string,
  creDtTm  : string,
  body     : string[],
): string {
  const ns     = NS_URI[msgType];
  const rootEl = ROOT_ELEM[msgType];

  return [
    '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
    '<Saa:DataPDU xmlns:Saa="urn:swift:saa:xsd:saa.2.0"',
    'xmlns:head="urn:iso:std:iso:20022:tech:xsd:head.001.001.02">',
    appHdr(sender, receiver, msgType, msgId, creDtTm),
    `<Document xmlns="${ns}">`,
    o(rootEl),
    ...body,
    c(rootEl),
    '</Document>',
    '</Saa:DataPDU>',
  ].join('\n');
}

// ─── pacs.008 ─────────────────────────────────────────────────────────────────
function buildPacs008(f: Pacs008Fields, sender: string, receiver: string): string {
  const rcvBIC = (receiver || '').padEnd(11, 'X').slice(0, 11);
  const sndBIC = (sender   || '').padEnd(11, 'X').slice(0, 11);

  const body = [
    o('GrpHdr'),
    t('MsgId',           f.msgId),
    t('CreDtTm',         dtNoOffset(f.creDtTm)),
    t('NbOfTxs',         f.nbOfTxs),
    ta('TtlIntrBkSttlmAmt', `Ccy="${f.intrBkSttlmCcy}"`, f.intrBkSttlmAmt),
    t('IntrBkSttlmDt',   dtDate(f.sttlmDt)),
    o('SttlmInf'),
    t('SttlmMtd',        f.sttlmMtd),
    c('SttlmInf'),
    c('GrpHdr'),

    o('CdtTrfTxInf'),
    o('PmtId'),
    t('InstrId',         f.instrId),
    t('EndToEndId',      f.endToEndId),
    t('TxId',            f.instrId),
    t('UETR',            f.uetr),
    c('PmtId'),

    o('PmtTpInf'),
    o('SvcLvl'),
    t('Cd', 'URGP'),
    c('SvcLvl'),
    o('LclInstrm'),
    t('Cd', 'TRF'),
    c('LclInstrm'),
    o('CtgyPurp'),
    t('Cd', f.purp ?? 'INTC'),
    c('CtgyPurp'),
    c('PmtTpInf'),

    ta('IntrBkSttlmAmt', `Ccy="${f.intrBkSttlmCcy}"`, f.intrBkSttlmAmt),
    t('ChrgBr',          f.chrgBr),

    o('Dbtr'),
    t('Nm',              f.dbtrNm),
    o('PstlAdr'),
    t('Ctry',            f.dbtrCtry ?? ''),
    c('PstlAdr'),
    c('Dbtr'),

    o('DbtrAcct'),
    o('Id'),
    o('Othr'),
    t('Id',              f.dbtrAcct),
    c('Othr'),
    c('Id'),
    c('DbtrAcct'),

    o('DbtrAgt'),
    o('FinInstnId'),
    t('BICFI',           f.dbtrAgtBIC || sndBIC),
    t('Nm',              f.dbtrNm),
    c('FinInstnId'),
    c('DbtrAgt'),

    o('CdtrAgt'),
    o('FinInstnId'),
    t('BICFI',           f.cdtrAgtBIC || rcvBIC),
    t('Nm',              f.cdtrNm),
    o('PstlAdr'),
    t('TwnNm',           f.cdtrTwnNm ?? ''),
    t('Ctry',            f.cdtrCtry  ?? ''),
    c('PstlAdr'),
    c('FinInstnId'),
    c('CdtrAgt'),

    o('Cdtr'),
    t('Nm',              f.cdtrNm),
    o('PstlAdr'),
    ...(f.cdtrAdrLine ? [t('AdrLine', f.cdtrAdrLine)] : []),
    t('TwnNm',           f.cdtrTwnNm ?? ''),
    t('Ctry',            f.cdtrCtry  ?? ''),
    c('PstlAdr'),
    c('Cdtr'),

    o('CdtrAcct'),
    o('Id'),
    t('IBAN',            f.cdtrAcct),
    c('Id'),
    c('CdtrAcct'),

    ...(f.rmtInf ? [o('RmtInf'), t('Ustrd', f.rmtInf), c('RmtInf')] : []),

    c('CdtTrfTxInf'),
  ];

  return wrap('pacs.008', sender, receiver, f.msgId, f.creDtTm, body);
}

// ─── pacs.002 ─────────────────────────────────────────────────────────────────
function buildPacs002(f: Pacs002Fields, sender: string, receiver: string): string {
  const body = [
    o('GrpHdr'),
    t('MsgId',           f.msgId),
    t('CreDtTm',         dtNoOffset(f.creDtTm)),
    o('InstgAgt'),
    o('FinInstnId'),
    t('BICFI',           f.instgAgt),
    c('FinInstnId'),
    c('InstgAgt'),
    o('InstdAgt'),
    o('FinInstnId'),
    t('BICFI',           f.instdAgt),
    c('FinInstnId'),
    c('InstdAgt'),
    c('GrpHdr'),

    o('OrgnlGrpInfAndSts'),
    t('OrgnlMsgId',      f.orgnlMsgId),
    t('OrgnlMsgNmId',    f.orgnlMsgNmId),
    c('OrgnlGrpInfAndSts'),

    o('TxInfAndSts'),
    t('OrgnlEndToEndId', f.orgnlEndToEndId),
    t('OrgnlUETR',       f.orgnlUETR),
    t('TxSts',           f.txSts),
    ...(f.rsnCd ? [
      o('StsRsnInf'), o('Rsn'), t('Cd', f.rsnCd), c('Rsn'), c('StsRsnInf'),
    ] : []),
    ...(f.addtlInf ? [t('AddtlInf', f.addtlInf)] : []),
    c('TxInfAndSts'),
  ];
  return wrap('pacs.002', sender, receiver, f.msgId, f.creDtTm, body);
}

// ─── pacs.004 ─────────────────────────────────────────────────────────────────
function buildPacs004(f: Pacs004Fields, sender: string, receiver: string): string {
  const body = [
    o('GrpHdr'),
    t('MsgId',           f.msgId),
    t('CreDtTm',         dtNoOffset(f.creDtTm)),
    t('NbOfTxs',         f.nbOfTxs),
    o('InstgAgt'),
    o('FinInstnId'),
    t('BICFI',           f.instgAgt),
    c('FinInstnId'),
    c('InstgAgt'),
    o('InstdAgt'),
    o('FinInstnId'),
    t('BICFI',           f.instdAgt),
    c('FinInstnId'),
    c('InstdAgt'),
    c('GrpHdr'),

    o('OrgnlGrpInf'),
    t('OrgnlMsgId',      f.orgnlMsgId),
    t('OrgnlMsgNmId',    f.orgnlMsgNmId),
    c('OrgnlGrpInf'),

    o('TxInf'),
    o('RtrId'),
    t('InstrId',         f.rtrId),
    t('EndToEndId',      f.orgnlEndToEndId),
    t('UETR',            f.orgnlUETR),
    c('RtrId'),
    ta('RtrdIntrBkSttlmAmt', `Ccy="${f.rtrdIntrBkSttlmCcy}"`, f.rtrdIntrBkSttlmAmt),
    t('IntrBkSttlmDt',   dtDate(f.sttlmDt ?? f.creDtTm)),
    o('RtrRsnInf'),
    o('Rsn'),
    t('Cd',              f.rsnCd),
    c('Rsn'),
    ...(f.addtlRsnInf ? [t('AddtlInf', f.addtlRsnInf)] : []),
    c('RtrRsnInf'),
    o('OrgnlTxRef'),
    o('Dbtr'),
    t('Nm',              f.dbtrNm),
    c('Dbtr'),
    o('Cdtr'),
    t('Nm',              f.cdtrNm),
    c('Cdtr'),
    c('OrgnlTxRef'),
    c('TxInf'),
  ];
  return wrap('pacs.004', sender, receiver, f.msgId, f.creDtTm, body);
}

// ─── pacs.009 ─────────────────────────────────────────────────────────────────
function buildPacs009(f: Pacs009Fields, sender: string, receiver: string): string {
  const body = [
    o('GrpHdr'),
    t('MsgId',           f.msgId),
    t('CreDtTm',         dtNoOffset(f.creDtTm)),
    t('NbOfTxs',         f.nbOfTxs),
    o('SttlmInf'),
    t('SttlmMtd',        f.sttlmMtd),
    c('SttlmInf'),
    o('InstgAgt'),
    o('FinInstnId'),
    t('BICFI',           f.instgAgt),
    c('FinInstnId'),
    c('InstgAgt'),
    o('InstdAgt'),
    o('FinInstnId'),
    t('BICFI',           f.instdAgt),
    c('FinInstnId'),
    c('InstdAgt'),
    c('GrpHdr'),

    o('CdtTrfTxInf'),
    o('PmtId'),
    t('InstrId',         f.instrId),
    t('EndToEndId',      f.endToEndId),
    t('UETR',            f.uetr),
    c('PmtId'),
    ta('IntrBkSttlmAmt', `Ccy="${f.intrBkSttlmCcy}"`, f.intrBkSttlmAmt),
    t('IntrBkSttlmDt',   dtDate(f.sttlmDt)),
    t('ChrgBr',          f.chrgBr),
    o('Dbtr'),
    o('FinInstnId'),
    t('Nm',              f.dbtrNm),
    c('FinInstnId'),
    c('Dbtr'),
    o('Cdtr'),
    o('FinInstnId'),
    t('Nm',              f.cdtrNm),
    c('FinInstnId'),
    c('Cdtr'),
    ...(f.purp    ? [o('Purp'),   t('Cd', f.purp),   c('Purp')]   : []),
    ...(f.rmtInf  ? [o('RmtInf'), t('Ustrd', f.rmtInf), c('RmtInf')] : []),
    c('CdtTrfTxInf'),
  ];
  return wrap('pacs.009', sender, receiver, f.msgId, f.creDtTm, body);
}

// ─── camt.053 ─────────────────────────────────────────────────────────────────
function buildCamt053(f: Camt053Fields, sender: string, receiver: string): string {
  const body = [
    o('GrpHdr'),
    t('MsgId',           f.msgId),
    t('CreDtTm',         dtNoOffset(f.creDtTm)),
    o('MsgRcpt'),
    o('FinInstnId'),
    t('BICFI',           receiver),
    c('FinInstnId'),
    c('MsgRcpt'),
    c('GrpHdr'),

    o('Stmt'),
    t('Id',              f.stmtId),
    t('ElctrncSeqNb',   f.elctrncSeqNb),
    t('CreDtTm',         dtNoOffset(f.creDtTm)),
    o('FrToDt'),
    t('FrDtTm',          f.frDt),
    t('ToDtTm',          f.toDt),
    c('FrToDt'),
    o('Acct'),
    o('Id'),
    t('IBAN',            f.acctId),
    c('Id'),
    t('Ccy',             f.acctCcy),
    o('Ownr'),
    t('Nm',              f.acctOwnrNm),
    c('Ownr'),
    o('Svcr'),
    o('FinInstnId'),
    t('BICFI',           f.svcr),
    c('FinInstnId'),
    c('Svcr'),
    c('Acct'),

    o('Bal'),
    o('Tp'),
    o('CdOrPrtry'),
    t('Cd', 'OPBD'),
    c('CdOrPrtry'),
    c('Tp'),
    ta('Amt', `Ccy="${f.openingBalCcy}"`, f.openingBal),
    t('CdtDbtInd', 'CRDT'),
    t('Dt', f.frDt.slice(0, 10)),
    c('Bal'),

    o('Bal'),
    o('Tp'),
    o('CdOrPrtry'),
    t('Cd', 'CLBD'),
    c('CdOrPrtry'),
    c('Tp'),
    ta('Amt', `Ccy="${f.closingBalCcy}"`, f.closingBal),
    t('CdtDbtInd', 'CRDT'),
    t('Dt', f.toDt.slice(0, 10)),
    c('Bal'),

    o('Ntry'),
    ta('Amt', `Ccy="${f.ntryCcy}"`, f.ntryAmt),
    t('CdtDbtInd',       f.cdtDbtInd),
    t('Sts', 'BOOK'),
    o('BookgDt'),
    t('Dt',              f.ntryDt),
    c('BookgDt'),
    o('ValDt'),
    t('Dt',              f.ntryDt),
    c('ValDt'),
    t('AcctSvcrRef',     f.ntryRef),
    o('NtryDtls'),
    o('TxDtls'),
    o('Refs'),
    t('EndToEndId',      f.endToEndId),
    c('Refs'),
    ...(f.rmtInf ? [o('RmtInf'), t('Ustrd', f.rmtInf), c('RmtInf')] : []),
    c('TxDtls'),
    c('NtryDtls'),
    c('Ntry'),
    c('Stmt'),
  ];
  return wrap('camt.053', sender, receiver, f.msgId, f.creDtTm, body);
}

// ─── camt.054 ─────────────────────────────────────────────────────────────────
function buildCamt054(f: Camt054Fields, sender: string, receiver: string): string {
  const sndBIC  = (sender   || '').padEnd(11, 'X').slice(0, 11);
  const rcvBIC  = (receiver || '').padEnd(11, 'X').slice(0, 11);
  const valDate = f.valDt || f.ntryDt;

  const body = [
    // ── Group Header ──────────────────────────────────────────────────────────
    o('GrpHdr'),
    t('MsgId',        f.msgId),
    t('CreDtTm',      dtNoOffset(f.creDtTm)),
    o('MsgPgntn'),
    t('PgNb',         '1'),
    t('LastPgInd',    'true'),
    c('MsgPgntn'),
    o('MsgRcpt'),
    o('FinInstnId'),
    t('BICFI',        rcvBIC),
    c('FinInstnId'),
    c('MsgRcpt'),
    o('AddtlInf'),
    t('MsgAuthntctn', f.msgId),
    c('AddtlInf'),
    c('GrpHdr'),

    // ── Notification ──────────────────────────────────────────────────────────
    o('Ntfctn'),
    t('Id',           f.ntfctnId),
    t('CreDtTm',      dtNoOffset(f.creDtTm)),

    // ── Account ───────────────────────────────────────────────────────────────
    o('Acct'),
    o('Id'),
    t('IBAN',         f.acctId),
    c('Id'),
    t('Ccy',          f.acctCcy),
    o('Ownr'),
    t('Nm', f.acctOwnrNm || ''),
    c('Ownr'),
    o('Svcr'),
    o('FinInstnId'),
    t('BICFI',        f.svcr || sndBIC),
    c('FinInstnId'),
    c('Svcr'),
    c('Acct'),

    // ── Entry ─────────────────────────────────────────────────────────────────
    o('Ntry'),
    ta('Amt', `Ccy="${f.ntryCcy}"`, f.ntryAmt),
    t('CdtDbtInd',   f.cdtDbtInd),
    t('Sts',         'BOOK'),
    o('BookgDt'),
    t('Dt',          dtDate(f.ntryDt)),
    c('BookgDt'),
    o('ValDt'),
    t('Dt',          dtDate(valDate)),
    c('ValDt'),
    t('AcctSvcrRef', f.ntryRef),

    // Bank Transaction Code
    o('BkTxCd'),
    o('Domn'),
    t('Cd',          'PMNT'),
    o('Fmly'),
    t('Cd',          f.bkTxCd || 'ICDT'),
    t('SubFmlyCd',   'DMCT'),
    c('Fmly'),
    c('Domn'),
    c('BkTxCd'),

    // Entry Details
    o('NtryDtls'),
    t('Btch',        ''),
    o('TxDtls'),

    // References
    o('Refs'),
    t('InstrId',     f.instrId),
    t('EndToEndId',  f.endToEndId),
    t('TxId',        f.txId),
    t('UETR',        f.uetr),
    c('Refs'),

    // Amounts
    o('AmtDtls'),
    o('IntrBkSttlmAmt'),
    ta('Amt', `Ccy="${f.ntryCcy}"`, f.ntryAmt),
    c('IntrBkSttlmAmt'),
    c('AmtDtls'),

    // Agents
    ...(f.dbtrAgtBIC ? [
      o('RltdAgts'),
      o('DbtrAgt'),
      o('FinInstnId'),
      t('BICFI', f.dbtrAgtBIC),
      c('FinInstnId'),
      c('DbtrAgt'),
      ...(f.cdtrAgtBIC ? [
        o('CdtrAgt'),
        o('FinInstnId'),
        t('BICFI', f.cdtrAgtBIC),
        c('FinInstnId'),
        c('CdtrAgt'),
      ] : []),
      c('RltdAgts'),
    ] : []),

    // Purpose
    ...(f.purp ? [o('Purp'), t('Cd', f.purp), c('Purp')] : []),

    // Related Parties
    o('RltdPties'),
    ...(f.dbtrNm ? [
      o('Dbtr'),
      o('Pty'),
      t('Nm', f.dbtrNm),
      ...(f.dbtrAcct ? [
        o('Id'),
        o('OrgId'),
        t('AnyBIC', f.dbtrAgtBIC || sndBIC),
        c('OrgId'),
        c('Id'),
      ] : []),
      c('Pty'),
      c('Dbtr'),
    ] : []),
    ...(f.cdtrNm ? [
      o('Cdtr'),
      o('Pty'),
      t('Nm', f.cdtrNm),
      c('Pty'),
      c('Cdtr'),
    ] : []),
    ...(f.dbtrAcct ? [
      o('DbtrAcct'),
      o('Id'),
      t('IBAN', f.dbtrAcct),
      c('Id'),
      c('DbtrAcct'),
    ] : []),
    ...(f.cdtrAcct ? [
      o('CdtrAcct'),
      o('Id'),
      t('IBAN', f.cdtrAcct),
      c('Id'),
      c('CdtrAcct'),
    ] : []),
    c('RltdPties'),

    // Remittance
    ...(f.rmtInf ? [o('RmtInf'), t('Ustrd', f.rmtInf), c('RmtInf')] : []),

    // Additional entry info
    ...(f.addtlNtryInf ? [t('AddtlNtryInf', f.addtlNtryInf)] : []),

    c('TxDtls'),
    c('NtryDtls'),

    c('Ntry'),
    c('Ntfctn'),
  ];
  return wrap('camt.054', sender, receiver, f.msgId, f.creDtTm, body);
}

// ─── camt.056 ─────────────────────────────────────────────────────────────────
function buildCamt056(f: Camt056Fields, sender: string, receiver: string): string {
  const body = [
    o('Assgnmt'),
    t('Id',              f.msgId),
    o('Assgnr'),
    o('Agt'),
    o('FinInstnId'),
    t('BICFI',           f.instgAgt),
    c('FinInstnId'),
    c('Agt'),
    c('Assgnr'),
    o('Assgne'),
    o('Agt'),
    o('FinInstnId'),
    t('BICFI',           f.instdAgt),
    c('FinInstnId'),
    c('Agt'),
    c('Assgne'),
    t('CreDtTm',         dtNoOffset(f.creDtTm)),
    c('Assgnmt'),

    o('CtrlData'),
    t('NbOfTxs', '1'),
    c('CtrlData'),

    o('Undrlyg'),
    o('TxInf'),
    o('OrgnlGrpInf'),
    t('OrgnlMsgId',      f.orgnlMsgId),
    t('OrgnlMsgNmId',    f.orgnlMsgNmId),
    c('OrgnlGrpInf'),
    t('OrgnlEndToEndId', f.orgnlEndToEndId),
    t('OrgnlUETR',       f.orgnlUETR),
    ta('OrgnlIntrBkSttlmAmt', `Ccy="${f.orgnlIntrBkSttlmCcy}"`, f.orgnlIntrBkSttlmAmt),
    o('CxlRsnInf'),
    o('Rsn'),
    t('Cd',              f.cxlRsnCd),
    c('Rsn'),
    ...(f.addtlCxlRsnInf ? [t('AddtlInf', f.addtlCxlRsnInf)] : []),
    c('CxlRsnInf'),
    c('TxInf'),
    c('Undrlyg'),
  ];
  return wrap('camt.056', sender, receiver, f.msgId, f.creDtTm, body);
}

// ─── camt.029 ─────────────────────────────────────────────────────────────────
function buildCamt029(f: Camt029Fields, sender: string, receiver: string): string {
  const body = [
    o('Assgnmt'),
    t('Id',              f.msgId),
    o('Assgnr'),
    o('Agt'),
    o('FinInstnId'),
    t('BICFI',           f.instgAgt),
    c('FinInstnId'),
    c('Agt'),
    c('Assgnr'),
    o('Assgne'),
    o('Agt'),
    o('FinInstnId'),
    t('BICFI',           f.instdAgt),
    c('FinInstnId'),
    c('Agt'),
    c('Assgne'),
    t('CreDtTm',         dtNoOffset(f.creDtTm)),
    c('Assgnmt'),

    o('Sts'),
    o('DtldSts'),
    t('OrgnlEndToEndId', f.orgnlEndToEndId),
    t('OrgnlUETR',       f.orgnlUETR),
    t('Sts',             f.sts),
    ...(f.rsnCd ? [
      o('StsRsnInf'), o('Rsn'), t('Cd', f.rsnCd), c('Rsn'), c('StsRsnInf'),
    ] : []),
    ...(f.addtlInf ? [t('AddtlInf', f.addtlInf)] : []),
    o('OrgnlGrpInf'),
    t('OrgnlMsgId',      f.orgnlMsgId),
    t('OrgnlMsgNmId',    f.orgnlMsgNmId),
    c('OrgnlGrpInf'),
    c('DtldSts'),
    c('Sts'),
  ];
  return wrap('camt.029', sender, receiver, f.msgId, f.creDtTm, body);
}

// ─── camt.052 ─────────────────────────────────────────────────────────────────
function buildCamt052(f: Camt052Fields, sender: string, receiver: string): string {
  const body = [
    o('GrpHdr'),
    t('MsgId',           f.msgId),
    t('CreDtTm',         dtNoOffset(f.creDtTm)),
    c('GrpHdr'),

    o('Rpt'),
    t('Id',              f.rptId),
    t('CreDtTm',         dtNoOffset(f.creDtTm)),
    o('FrToDt'),
    t('FrDtTm',          f.frDt),
    t('ToDtTm',          f.toDt),
    c('FrToDt'),
    o('Acct'),
    o('Id'),
    t('IBAN',            f.acctId),
    c('Id'),
    o('Ownr'),
    t('Nm',              f.acctOwnrNm),
    c('Ownr'),
    o('Svcr'),
    o('FinInstnId'),
    t('BICFI',           f.svcr),
    c('FinInstnId'),
    c('Svcr'),
    c('Acct'),

    o('Ntry'),
    ta('Amt', `Ccy="${f.ntryCcy}"`, f.ntryAmt),
    t('CdtDbtInd',       f.cdtDbtInd),
    t('Sts', 'PDNG'),
    o('ValDt'),
    t('Dt',              f.ntryDt),
    c('ValDt'),
    t('AcctSvcrRef',     f.ntryRef),
    o('NtryDtls'),
    o('TxDtls'),
    o('Refs'),
    t('EndToEndId',      f.endToEndId),
    c('Refs'),
    c('TxDtls'),
    c('NtryDtls'),
    c('Ntry'),
    c('Rpt'),
  ];
  return wrap('camt.052', sender, receiver, f.msgId, f.creDtTm, body);
}

// ─── camt.060 ─────────────────────────────────────────────────────────────────
function buildCamt060(f: Camt060Fields, sender: string, receiver: string): string {
  const body = [
    o('GrpHdr'),
    t('MsgId',           f.msgId),
    t('CreDtTm',         dtNoOffset(f.creDtTm)),
    c('GrpHdr'),

    o('RptgReq'),
    t('Id',              f.rptgReqId),
    o('ReqdMsgNmId'),
    t('Id',              f.rptTp),
    c('ReqdMsgNmId'),
    o('Acct'),
    o('Id'),
    t('IBAN',            f.acctId),
    c('Id'),
    o('Ownr'),
    o('Id'),
    o('OrgId'),
    t('AnyBIC',          f.acctOwnrBIC),
    c('OrgId'),
    c('Id'),
    c('Ownr'),
    o('Svcr'),
    o('FinInstnId'),
    t('BICFI',           f.acctSvcrBIC),
    c('FinInstnId'),
    c('Svcr'),
    c('Acct'),
    o('ReqdPeriod'),
    t('FrDtTm',          f.frDtTm),
    t('ToDtTm',          f.toDtTm),
    c('ReqdPeriod'),
    c('RptgReq'),
  ];
  return wrap('camt.060', sender, receiver, f.msgId, f.creDtTm, body);
}

// ─── pain.001 ─────────────────────────────────────────────────────────────────
function buildPain001(f: Pain001Fields, sender: string, receiver: string): string {
  const body = [
    o('GrpHdr'),
    t('MsgId',           f.msgId),
    t('CreDtTm',         dtNoOffset(f.creDtTm)),
    t('NbOfTxs',         f.nbOfTxs),
    t('CtrlSum',         f.ctrlSum),
    o('InitgPty'),
    t('Nm',              f.initgPtyNm),
    c('InitgPty'),
    c('GrpHdr'),

    o('PmtInf'),
    t('PmtInfId',        f.pmtInfId),
    t('PmtMtd',          f.pmtMtd),
    t('NbOfTxs',         f.nbOfTxs),
    t('CtrlSum',         f.ctrlSum),
    o('PmtTpInf'),
    o('SvcLvl'),
    t('Cd', 'SEPA'),
    c('SvcLvl'),
    c('PmtTpInf'),
    o('ReqdExctnDt'),
    t('Dt',              f.reqdExctnDt),
    c('ReqdExctnDt'),
    o('Dbtr'),
    t('Nm',              f.dbtrNm),
    c('Dbtr'),
    o('DbtrAcct'),
    o('Id'),
    t('IBAN',            f.dbtrAcct),
    c('Id'),
    c('DbtrAcct'),
    o('DbtrAgt'),
    o('FinInstnId'),
    t('BICFI',           f.dbtrAgtBIC),
    c('FinInstnId'),
    c('DbtrAgt'),
    o('CdtTrfTxInf'),
    o('PmtId'),
    t('EndToEndId',      f.endToEndId),
    c('PmtId'),
    o('Amt'),
    ta('InstdAmt', `Ccy="${f.instrCcy}"`, f.instrAmt),
    c('Amt'),
    o('CdtrAgt'),
    o('FinInstnId'),
    t('BICFI',           f.cdtrAgtBIC),
    c('FinInstnId'),
    c('CdtrAgt'),
    o('Cdtr'),
    t('Nm',              f.cdtrNm),
    c('Cdtr'),
    o('CdtrAcct'),
    o('Id'),
    t('IBAN',            f.cdtrAcct),
    c('Id'),
    c('CdtrAcct'),
    ...(f.purp   ? [o('Purp'),   t('Cd', f.purp),   c('Purp')]   : []),
    ...(f.rmtInf ? [o('RmtInf'), t('Ustrd', f.rmtInf), c('RmtInf')] : []),
    c('CdtTrfTxInf'),
    c('PmtInf'),
  ];
  return wrap('pain.001', sender, receiver, f.msgId, f.creDtTm, body);
}

// ─── pain.002 ─────────────────────────────────────────────────────────────────
function buildPain002(f: Pain002Fields, sender: string, receiver: string): string {
  const body = [
    o('GrpHdr'),
    t('MsgId',           f.msgId),
    t('CreDtTm',         dtNoOffset(f.creDtTm)),
    o('InitgPty'),
    t('Nm',              f.initgPtyNm),
    c('InitgPty'),
    c('GrpHdr'),

    o('OrgnlGrpInfAndSts'),
    t('OrgnlMsgId',      f.orgnlMsgId),
    t('OrgnlMsgNmId',    f.orgnlMsgNmId),
    t('OrgnlNbOfTxs',    f.orgnlNbOfTxs),
    t('OrgnlCtrlSum',    f.orgnlCtrlSum),
    t('GrpSts',          f.grpSts),
    c('OrgnlGrpInfAndSts'),

    o('OrgnlPmtInfAndSts'),
    o('TxInfAndSts'),
    t('OrgnlEndToEndId', f.orgnlEndToEndId),
    t('TxSts',           f.txSts),
    ...(f.rsnCd ? [
      o('StsRsnInf'), o('Rsn'), t('Cd', f.rsnCd), c('Rsn'), c('StsRsnInf'),
    ] : []),
    ...(f.addtlStsRsnInf ? [t('AddtlStsRsnInf', f.addtlStsRsnInf)] : []),
    c('TxInfAndSts'),
    c('OrgnlPmtInfAndSts'),
  ];
  return wrap('pain.002', sender, receiver, f.msgId, f.creDtTm, body);
}

// ─── pin.001 ──────────────────────────────────────────────────────────────────
function buildPin001(f: Pin001Fields, sender: string, receiver: string): string {
  const body = [
    o('EvtInf'),
    t('EvtCd', 'PMTNTFCTN'),
    t('EvtParam',        f.ntfctnPurp),
    t('EvtDtAndTm',      dtNoOffset(f.creDtTm)),
    t('EvtDesc',         f.addtlInf ?? 'Payment Initiation Notification'),
    o('EvtTp'),
    t('Prtry',           f.ntfctnPurp),
    c('EvtTp'),
    c('EvtInf'),

    o('SysEvtInf'),
    t('EvtId',           f.msgId),
    t('ActvtnDtAndTm',   dtNoOffset(f.creDtTm)),
    o('GrpHdr'),
    t('MsgId',           f.msgId),
    t('CreDtTm',         dtNoOffset(f.creDtTm)),
    o('InstgAgt'),
    o('FinInstnId'),
    t('BICFI',           f.instgAgt),
    c('FinInstnId'),
    c('InstgAgt'),
    o('InstdAgt'),
    o('FinInstnId'),
    t('BICFI',           f.instdAgt),
    c('FinInstnId'),
    c('InstdAgt'),
    c('GrpHdr'),
    o('TxInf'),
    o('PmtId'),
    t('InstrId',         f.instrId),
    t('EndToEndId',      f.endToEndId),
    t('UETR',            f.uetr),
    c('PmtId'),
    ta('IntrBkSttlmAmt', `Ccy="${f.intrBkSttlmCcy}"`, f.intrBkSttlmAmt),
    t('SttlmDt',         f.sttlmDt),
    o('Dbtr'),
    t('Nm',              f.dbtrNm),
    c('Dbtr'),
    o('DbtrAcct'),
    o('Id'),
    t('IBAN',            f.dbtrAcct),
    c('Id'),
    c('DbtrAcct'),
    o('Cdtr'),
    t('Nm',              f.cdtrNm),
    c('Cdtr'),
    o('CdtrAcct'),
    o('Id'),
    t('IBAN',            f.cdtrAcct),
    c('Id'),
    c('CdtrAcct'),
    c('TxInf'),
    c('SysEvtInf'),
  ];
  return wrap('pin.001', sender, receiver, f.msgId, f.creDtTm, body);
}

// ─── pin.002 ──────────────────────────────────────────────────────────────────
function buildPin002(f: Pin002Fields, sender: string, receiver: string): string {
  const body = [
    o('EvtInf'),
    t('EvtCd', 'PMTNTFCTNACK'),
    t('EvtDtAndTm',      dtNoOffset(f.creDtTm)),
    t('EvtDesc',         f.addtlInf ?? 'Payment Initiation Notification Acknowledgement'),
    c('EvtInf'),

    o('SysEvtAck'),
    t('MsgId',           f.msgId),
    t('CreDtTm',         dtNoOffset(f.creDtTm)),
    t('OrgnlMsgId',      f.orgnlMsgId),
    t('OrgnlInstrId',    f.orgnlInstrId),
    t('OrgnlEndToEndId', f.orgnlEndToEndId),
    t('OrgnlUETR',       f.orgnlUETR),
    t('NtfctnSts',       f.ntfctnSts),
    ...(f.rsnCd ? [
      o('StsRsnInf'), o('Rsn'), t('Cd', f.rsnCd), c('Rsn'), c('StsRsnInf'),
    ] : []),
    ...(f.addtlInf ? [t('AddtlInf', f.addtlInf)] : []),
    o('InstgAgt'),
    o('FinInstnId'),
    t('BICFI',           f.instgAgt),
    c('FinInstnId'),
    c('InstgAgt'),
    o('InstdAgt'),
    o('FinInstnId'),
    t('BICFI',           f.instdAgt),
    c('FinInstnId'),
    c('InstdAgt'),
    c('SysEvtAck'),
  ];
  return wrap('pin.002', sender, receiver, f.msgId, f.creDtTm, body);
}

// ─── Main dispatcher ──────────────────────────────────────────────────────────
export function buildISO20022Message(msg: SWIFTMessage): string {
  const f = msg.isoFields!;
  const s = msg.senderBIC;
  const r = msg.receiverBIC;
  switch (msg.messageType as ISO20022MessageType) {
    case 'pacs.008': return buildPacs008(f as Pacs008Fields, s, r);
    case 'pacs.002': return buildPacs002(f as Pacs002Fields, s, r);
    case 'pacs.004': return buildPacs004(f as Pacs004Fields, s, r);
    case 'pacs.009': return buildPacs009(f as Pacs009Fields, s, r);
    case 'camt.053': return buildCamt053(f as Camt053Fields, s, r);
    case 'camt.054': return buildCamt054(f as Camt054Fields, s, r);
    case 'camt.056': return buildCamt056(f as Camt056Fields, s, r);
    case 'camt.029': return buildCamt029(f as Camt029Fields, s, r);
    case 'camt.052': return buildCamt052(f as Camt052Fields, s, r);
    case 'camt.060': return buildCamt060(f as Camt060Fields, s, r);
    case 'pain.001': return buildPain001(f as Pain001Fields, s, r);
    case 'pain.002': return buildPain002(f as Pain002Fields, s, r);
    case 'pin.001':  return buildPin001(f as Pin001Fields, s, r);
    case 'pin.002':  return buildPin002(f as Pin002Fields, s, r);
    default:         return '<!-- Unknown ISO 20022 message type -->';
  }
}
