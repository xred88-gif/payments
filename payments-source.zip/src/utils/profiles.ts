// ─── Message Profile / Template System ───────────────────────────────────────
// Profiles allow users to save and reload frequently-used field data
// so they don't need to re-enter the same BICs, account numbers, names, etc.

export interface MessageProfile {
  id: string;
  name: string;                  // Display name e.g. "JPM → HSBC USD Transfers"
  description?: string;
  messageType: string;           // 'pacs.008' | 'MT700' etc.
  createdAt: string;
  updatedAt: string;
  color: string;                 // Tailwind colour token for the card
  icon: string;                  // emoji icon
  // ── Common routing ──────────────────────────────────────────────────────────
  senderBIC?: string;
  receiverBIC?: string;
  // ── ISO 20022 fields ────────────────────────────────────────────────────────
  isoFields?: Record<string, string>;
  // ── MT fields ───────────────────────────────────────────────────────────────
  mtFields?: Record<string, string>;
}

const KEY = 'swiftdesk_profiles';

export function loadProfiles(): MessageProfile[] {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return [];
    return JSON.parse(raw) as MessageProfile[];
  } catch {
    return [];
  }
}

export function saveProfile(profile: MessageProfile): MessageProfile[] {
  const all = loadProfiles();
  const idx = all.findIndex(p => p.id === profile.id);
  const now = new Date().toISOString();
  if (idx >= 0) {
    all[idx] = { ...profile, updatedAt: now };
  } else {
    all.unshift({ ...profile, createdAt: now, updatedAt: now });
  }
  localStorage.setItem(KEY, JSON.stringify(all));
  return all;
}

export function deleteProfile(id: string): MessageProfile[] {
  const all = loadProfiles().filter(p => p.id !== id);
  localStorage.setItem(KEY, JSON.stringify(all));
  return all;
}

export function exportProfilesToJSON(profiles: MessageProfile[]): void {
  const blob = new Blob(
    [JSON.stringify({ version: '1.0', exportedAt: new Date().toISOString(), profiles }, null, 2)],
    { type: 'application/json' }
  );
  const url = URL.createObjectURL(blob);
  const a   = document.createElement('a');
  a.href     = url;
  a.download = `swift_profiles_${new Date().toISOString().slice(0, 10)}.json`;
  a.click();
  URL.revokeObjectURL(url);
}

export function importProfilesFromJSON(json: string): MessageProfile[] {
  const parsed = JSON.parse(json);
  const incoming: MessageProfile[] = parsed.profiles ?? parsed;
  const existing = loadProfiles();
  const merged   = [...incoming, ...existing.filter(e => !incoming.find(i => i.id === e.id))];
  localStorage.setItem(KEY, JSON.stringify(merged));
  return merged;
}

export function generateProfileId(): string {
  return 'PRF-' + Math.random().toString(36).slice(2, 10).toUpperCase();
}

// Colour palette for profile cards
export const PROFILE_COLORS = [
  { token: 'blue',    bg: 'from-blue-900/60 to-blue-950',     border: 'border-blue-700/40',    dot: '#3B82F6' },
  { token: 'violet',  bg: 'from-violet-900/60 to-violet-950', border: 'border-violet-700/40',  dot: '#8B5CF6' },
  { token: 'emerald', bg: 'from-emerald-900/60 to-emerald-950', border: 'border-emerald-700/40', dot: '#10B981' },
  { token: 'amber',   bg: 'from-amber-900/60 to-amber-950',   border: 'border-amber-700/40',   dot: '#F59E0B' },
  { token: 'orange',  bg: 'from-orange-900/60 to-orange-950', border: 'border-orange-700/40',  dot: '#F97316' },
  { token: 'cyan',    bg: 'from-cyan-900/60 to-cyan-950',     border: 'border-cyan-700/40',    dot: '#06B6D4' },
  { token: 'rose',    bg: 'from-rose-900/60 to-rose-950',     border: 'border-rose-700/40',    dot: '#F43F5E' },
  { token: 'indigo',  bg: 'from-indigo-900/60 to-indigo-950', border: 'border-indigo-700/40',  dot: '#6366F1' },
];

export const PROFILE_ICONS = ['🏦', '💳', '🔒', '📄', '🌍', '⚡', '💰', '🔄', '📨', '🏛️'];

export const MSG_TYPE_OPTIONS = [
  'pacs.008', 'pacs.009', 'pacs.004', 'pacs.002',
  'camt.053', 'camt.054', 'camt.056', 'camt.029',
  'pain.001', 'pain.002',
  'MT700', 'MT705', 'MT760', 'MT199', 'MT799',
];
