/**
 * Financial Messaging Identifier Generators
 * Follows SWIFT FIN / ISO 20022 / gpi conventions
 */

import { v4 as uuidv4 } from 'uuid';
import { GeneratedIdentifiers } from '../types';

// ─── UETR ─────────────────────────────────────────────────────────────────────
/** UETR – Unique End-to-End Transaction Reference per SWIFT gpi (RFC 4122 UUID v4) */
export function generateUETR(): string {
  return uuidv4();
}

// ─── Transaction Reference (Field :20:) ───────────────────────────────────────
/**
 * SWIFT Field :20: Transaction Reference Number
 * Max 16 chars, no special chars, no leading slash, no double slash
 * Format: <6-char alphanumeric prefix><10-digit timestamp suffix>
 */
export function generateTransactionRef(): string {
  const now = new Date();
  const yy = String(now.getUTCFullYear()).slice(2);
  const mm = String(now.getUTCMonth() + 1).padStart(2, '0');
  const dd = String(now.getUTCDate()).padStart(2, '0');
  const rand = Math.random().toString(36).toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 6).padEnd(6, '0');
  return `${yy}${mm}${dd}${rand}`;  // 14 chars — safe for :20:
}

// ─── Session / Sequence ────────────────────────────────────────────────────────
/** Block 1 Session Number — exactly 4 digits */
export function generateSessionNumber(): string {
  return String(Math.floor(1000 + Math.random() * 9000));
}

/** Block 1 Sequence Number — exactly 6 digits */
export function generateSequenceNumber(): string {
  return String(Math.floor(100000 + Math.random() * 900000));
}

// ─── Message ID & Routing ──────────────────────────────────────────────────────
/** Internal Message ID */
export function generateMessageId(): string {
  const ts = Date.now().toString(16).toUpperCase();
  const rand = Math.random().toString(16).slice(2, 6).toUpperCase();
  return `MSG${ts}${rand}`;
}

/** Internal Routing Identifier */
export function generateRoutingId(): string {
  const date = new Date().toISOString().slice(0, 10).replace(/-/g, '');
  const rand = Math.random().toString(36).toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 6).padEnd(6, '0');
  return `RID-${date}-${rand}`;
}

/** Composite Session Identifier */
export function generateSessionId(): string {
  const session = generateSessionNumber();
  const seq = generateSequenceNumber();
  return `SES-${session}-${seq}`;
}

/** Generate all identifiers at once */
export function generateAllIdentifiers(): GeneratedIdentifiers {
  return {
    uetr: generateUETR(),
    transactionRef: generateTransactionRef(),
    sessionId: generateSessionId(),
    messageId: generateMessageId(),
    routingId: generateRoutingId(),
  };
}

// ─── BIC helpers ──────────────────────────────────────────────────────────────

/**
 * Pad / normalise a BIC to exactly 12 characters for Block 1 LTA field:
 *   BANKUS33      →  BANKUS33AXXX   (append LT 'A' + branch 'XXX')
 *   BANKUS33XXX   →  BANKUS33AXXX   (insert LT 'A')
 *   BANKUS33AXXX  →  BANKUS33AXXX   (already correct)
 */
export function padBICtoLTA(bic: string): string {
  const b = bic.toUpperCase().trim();
  if (b.length === 8)  return `${b}AXXX`;   // BIC8  → BIC8 + LT + branch
  if (b.length === 11) return `${b.slice(0, 8)}A${b.slice(8)}`;  // BIC11 → insert LT
  if (b.length === 12) return b;             // already BIC12
  // Fallback: pad to 12
  return b.padEnd(12, 'X').slice(0, 12);
}

/**
 * Pad a BIC to exactly 12 chars for Block 2 receiver address:
 *   BANKUS33     → BANKUS33XXXX   (append 4 Xs for X-branch + 1 LT)
 *   BANKUS33XXX  → BANKUS33XXXX
 *   BANKUS33AXXX → BANKUS33AXXX   (already 12)
 */
export function padBICtoReceiver(bic: string): string {
  const b = bic.toUpperCase().trim();
  if (b.length === 8)  return `${b}XXXX`;
  if (b.length === 11) return `${b}X`;
  if (b.length === 12) return b;
  return b.padEnd(12, 'X').slice(0, 12);
}

/** Validate BIC (8 or 11 chars, ISO 9362) */
export function validateBIC(bic: string): boolean {
  return /^[A-Z]{4}[A-Z]{2}[A-Z0-9]{2}([A-Z0-9]{3})?$/.test(bic.toUpperCase().trim());
}
