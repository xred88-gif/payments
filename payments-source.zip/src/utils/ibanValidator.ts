/**
 * IBAN Validator — ISO 13616
 * • Strips spaces automatically
 * • Full mod-97 checksum validation
 * • Country-specific length rules
 */

const IBAN_LENGTHS: Record<string, number> = {
  AD: 24, AE: 23, AL: 28, AT: 20, AZ: 28, BA: 20, BE: 16, BG: 22,
  BH: 22, BR: 29, BY: 28, CH: 21, CR: 22, CY: 28, CZ: 24, DE: 22,
  DK: 18, DO: 28, EE: 20, EG: 29, ES: 24, FI: 18, FK: 18, FR: 27,
  GB: 22, GE: 22, GI: 23, GL: 18, GR: 27, GT: 28, HR: 21, HU: 28,
  IE: 22, IL: 23, IQ: 23, IR: 26, IS: 26, IT: 27, JO: 30, KW: 30,
  KZ: 20, LB: 28, LC: 32, LI: 21, LT: 20, LU: 20, LV: 21, LY: 25,
  MC: 27, MD: 24, ME: 22, MK: 19, MR: 27, MT: 31, MU: 30, MZ: 25,
  NL: 18, NO: 15, PK: 24, PL: 28, PS: 29, PT: 25, QA: 29, RO: 24,
  RS: 22, SA: 24, SC: 31, SD: 18, SE: 24, SI: 19, SK: 24, SM: 27,
  SO: 23, ST: 25, SV: 28, TL: 23, TN: 24, TR: 26, UA: 29, VA: 22,
  VG: 24, XK: 20,
};

/** Strip all whitespace from a string */
export function stripSpaces(s: string): string {
  return s.replace(/\s+/g, '');
}

/** Strip and uppercase */
export function normaliseIBAN(raw: string): string {
  return stripSpaces(raw).toUpperCase();
}

/** Mod-97 on a numeric string */
function mod97(numStr: string): number {
  let remainder = 0;
  for (let i = 0; i < numStr.length; i++) {
    remainder = (remainder * 10 + parseInt(numStr[i], 10)) % 97;
  }
  return remainder;
}

/** Convert IBAN letters to digits for mod-97 */
function ibanToNumeric(iban: string): string {
  const rearranged = iban.slice(4) + iban.slice(0, 4);
  return rearranged
    .split('')
    .map(c => {
      const code = c.charCodeAt(0);
      return code >= 65 && code <= 90 ? String(code - 55) : c;
    })
    .join('');
}

export type IBANValidationResult = {
  valid: boolean;
  normalised: string;
  error?: string;
  country?: string;
  expectedLength?: number;
};

export function validateIBAN(raw: string): IBANValidationResult {
  const iban = normaliseIBAN(raw);

  if (!iban) return { valid: false, normalised: '', error: '' };

  // Minimum length
  if (iban.length < 5) {
    return { valid: false, normalised: iban, error: 'Too short' };
  }

  // Country code
  const country = iban.slice(0, 2);
  if (!/^[A-Z]{2}$/.test(country)) {
    return { valid: false, normalised: iban, error: 'Invalid country code' };
  }

  // Check digits must be numeric
  const checkDigits = iban.slice(2, 4);
  if (!/^\d{2}$/.test(checkDigits)) {
    return { valid: false, normalised: iban, error: 'Invalid check digits' };
  }

  // Length check
  const expectedLength = IBAN_LENGTHS[country];
  if (expectedLength && iban.length !== expectedLength) {
    return {
      valid: false,
      normalised: iban,
      country,
      expectedLength,
      error: `${country} IBAN should be ${expectedLength} chars (got ${iban.length})`,
    };
  }

  // Alphanumeric only
  if (!/^[A-Z0-9]+$/.test(iban)) {
    return { valid: false, normalised: iban, error: 'Contains invalid characters' };
  }

  // Mod-97 checksum
  const numeric = ibanToNumeric(iban);
  const remainder = mod97(numeric);
  if (remainder !== 1) {
    return { valid: false, normalised: iban, country, error: 'Invalid checksum (mod-97 failed)' };
  }

  return { valid: true, normalised: iban, country, expectedLength };
}

/** Format IBAN in groups of 4 for display: GB14 HBUK 4011 9720 6750 24 */
export function formatIBANDisplay(iban: string): string {
  const clean = normaliseIBAN(iban);
  return clean.match(/.{1,4}/g)?.join(' ') ?? clean;
}
