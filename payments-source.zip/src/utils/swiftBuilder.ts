/**
 * SWIFT MT Message Builder
 * Produces structurally accurate SWIFT FIN messages per SWIFT Standards Release
 *
 * Reference format:
 *   {1:F01BANKUS33AXXX0001000001}
 *   {2:I700BANKGB22XXXXN}
 *   {3:{103:FIN}{108:MSGREF1234567890}{121:xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx}}
 *   {4:
 *   :27:1/1
 *   :40A:IRREVOCABLE
 *   :20:LC20240115ABCDEF
 *   ...
 *   -}
 *   {5:{CHK:AABBCC112233}}
 */

import {
  SWIFTMessage,
  SWIFTBlock1,
  SWIFTBlock2,
  SWIFTBlock3,
  SWIFTBlock5,
  MT700Fields,
  MT705Fields,
  MT760Fields,
  MT199Fields,
  MT799Fields,
} from '../types';
import { padBICtoLTA, padBICtoReceiver } from './identifiers';

// ─── Block 1: Basic Header ────────────────────────────────────────────────────
// Format: {1:F01<LTA12><session4><seq6>}
// LTA = 12-char Logical Terminal Address (BIC8 + LT + branch)
function renderBlock1(b: SWIFTBlock1): string {
  return `{1:${b.applicationId}${b.serviceId}${b.logicalTerminalAddress}${b.sessionNumber}${b.sequenceNumber}}`;
}

// ─── Block 2: Application Header ─────────────────────────────────────────────
// Input (outgoing):  {2:I<type><receiver12><priority>}
// Output (incoming): {2:O<type><time><MIRdate><MIRLT><MIRsess><MIRseq><outdate><outtime><priority>}
function renderBlock2(b: SWIFTBlock2): string {
  if (b.ioIndicator === 'I') {
    // Receiver address must be exactly 12 chars in block 2
    const recv = (b.receiverAddress ?? '').padEnd(12, 'X').slice(0, 12);
    return `{2:I${b.messageType}${recv}${b.messagePriority ?? 'N'}}`;
  }
  return (
    `{2:O${b.messageType}` +
    `${b.senderInputTime ?? '0000'}` +
    `${b.mIRDate ?? '000000'}` +
    `${b.mIRLogicalTerminal ?? ''.padEnd(12, 'X')}` +
    `${b.mIRSessionNumber ?? '0000'}` +
    `${b.mIRSequenceNumber ?? '000000'}` +
    `${b.receiverOutputDate ?? '000000'}` +
    `${b.receiverOutputTime ?? '0000'}` +
    `${b.messagePriority ?? 'N'}}`
  );
}

// ─── Block 3: User Header ─────────────────────────────────────────────────────
// Each sub-field is its own tagged element inside {3:...}
// {3:{103:CAT}{108:MSGREF}{121:uetr-uuid}}
function renderBlock3(b: SWIFTBlock3): string {
  const parts: string[] = [];
  if (b.serviceIdentifier)    parts.push(`{103:${b.serviceIdentifier}}`);
  if (b.bankingPriority)      parts.push(`{113:${b.bankingPriority}}`);
  if (b.messageUserReference) parts.push(`{108:${b.messageUserReference}}`);
  if (b.uetr)                 parts.push(`{121:${b.uetr}}`);
  return `{3:${parts.join('')}}`;
}

// ─── Block 5: Trailer ────────────────────────────────────────────────────────
function renderBlock5(b: SWIFTBlock5): string {
  const parts: string[] = [];
  if (b.checksum)                  parts.push(`{CHK:${b.checksum}}`);
  if (b.possibleDuplicateEmission) parts.push(`{PDE:${b.possibleDuplicateEmission}}`);
  if (b.messageReference)         parts.push(`{MRF:${b.messageReference}}`);
  if (b.addresseeInformation)     parts.push(`{ADI:${b.addresseeInformation}}`);
  return `{5:${parts.join('')}}`;
}

// ─── Field helpers ────────────────────────────────────────────────────────────

/**
 * Render a single SWIFT field line.
 * SWIFT field format:  ":TAG:VALUE"
 * Multi-line values:   each continuation line starts with no tag prefix.
 * We normalise newlines in the value so each line is properly separated.
 */
function f(tag: string, value: string | undefined): string | null {
  if (!value || value.trim() === '') return null;
  // Normalise CRLF → LF, strip trailing whitespace per line
  const normalised = value
    .replace(/\r\n/g, '\n')
    .replace(/\r/g, '\n')
    .split('\n')
    .map(l => l.trimEnd())
    .join('\n');
  return `:${tag}:${normalised}`;
}

/** Collect non-null field lines into an array */
function fields(...items: (string | null)[]): string[] {
  return items.filter((x): x is string => x !== null);
}

// ─── Block 4 closer ──────────────────────────────────────────────────────────
function wrapBlock4(lines: string[]): string {
  // SWIFT block 4 format:
  // {4:\n:TAG:VALUE\n:TAG:VALUE\n-}
  return `{4:\n${lines.join('\n')}\n-}`;
}

// ─── MT700 – Issue of a Documentary Credit ───────────────────────────────────
function buildMT700Block4(fld: MT700Fields): string {
  return wrapBlock4(fields(
    f('27',  fld.tag27  || '1/1'),
    f('40A', fld.tag40A),
    f('20',  fld.tag20),
    fld.tag23  ? f('23',  fld.tag23)  : null,
    fld.tag31C ? f('31C', fld.tag31C) : null,
    f('31D', fld.tag31D),
    f('50',  fld.tag50),
    f('59',  fld.tag59),
    f('32B', fld.tag32B),
    fld.tag39A ? f('39A', fld.tag39A) : null,
    fld.tag39B ? f('39B', fld.tag39B) : null,
    fld.tag41A ? f('41A', fld.tag41A) : (fld.tag41D ? f('41D', fld.tag41D) : null),
    fld.tag42C ? f('42C', fld.tag42C) : null,
    fld.tag42A ? f('42A', fld.tag42A) : (fld.tag42D ? f('42D', fld.tag42D) : null),
    fld.tag43P ? f('43P', fld.tag43P) : null,
    fld.tag43T ? f('43T', fld.tag43T) : null,
    fld.tag44A ? f('44A', fld.tag44A) : null,
    fld.tag44E ? f('44E', fld.tag44E) : null,
    fld.tag44F ? f('44F', fld.tag44F) : null,
    fld.tag44B ? f('44B', fld.tag44B) : null,
    fld.tag44C ? f('44C', fld.tag44C) : (fld.tag44D ? f('44D', fld.tag44D) : null),
    fld.tag45A ? f('45A', fld.tag45A) : null,
    fld.tag46A ? f('46A', fld.tag46A) : null,
    fld.tag47A ? f('47A', fld.tag47A) : null,
    fld.tag71B ? f('71B', fld.tag71B) : null,
    fld.tag48  ? f('48',  fld.tag48)  : null,
    f('49',  fld.tag49),
    fld.tag53A ? f('53A', fld.tag53A) : (fld.tag53D ? f('53D', fld.tag53D) : null),
    fld.tag57A ? f('57A', fld.tag57A) : (fld.tag57D ? f('57D', fld.tag57D) : null),
    fld.tag78  ? f('78',  fld.tag78)  : null,
  ));
}

// ─── MT705 – Pre-Advice of a Documentary Credit ──────────────────────────────
function buildMT705Block4(fld: MT705Fields): string {
  return wrapBlock4(fields(
    f('27',  fld.tag27  || '1/1'),
    f('40A', fld.tag40A),
    f('20',  fld.tag20),
    fld.tag23  ? f('23',  fld.tag23)  : null,
    fld.tag31C ? f('31C', fld.tag31C) : null,
    f('31D', fld.tag31D),
    f('50',  fld.tag50),
    f('59',  fld.tag59),
    f('32B', fld.tag32B),
    fld.tag39A ? f('39A', fld.tag39A) : null,
    fld.tag41A ? f('41A', fld.tag41A) : (fld.tag41D ? f('41D', fld.tag41D) : null),
    fld.tag44C ? f('44C', fld.tag44C) : (fld.tag44D ? f('44D', fld.tag44D) : null),
    fld.tag45A ? f('45A', fld.tag45A) : null,
    f('49',  fld.tag49),
  ));
}

// ─── MT760 – Guarantee / Standby Letter of Credit ────────────────────────────
function buildMT760Block4(fld: MT760Fields): string {
  return wrapBlock4(fields(
    f('27',  fld.tag27  || '1/1'),
    f('20',  fld.tag20),
    fld.tag23  ? f('23',  fld.tag23)  : null,
    f('22D', fld.tag22D),
    f('40C', fld.tag40C),
    fld.tag31C ? f('31C', fld.tag31C) : null,
    fld.tag31D ? f('31D', fld.tag31D) : null,
    f('50',  fld.tag50),
    f('59',  fld.tag59),
    f('32B', fld.tag32B),
    fld.tag39A ? f('39A', fld.tag39A) : null,
    fld.tag41A ? f('41A', fld.tag41A) : (fld.tag41D ? f('41D', fld.tag41D) : null),
    fld.tag44A ? f('44A', fld.tag44A) : null,
    fld.tag45A ? f('45A', fld.tag45A) : null,
    fld.tag46A ? f('46A', fld.tag46A) : null,
    fld.tag47A ? f('47A', fld.tag47A) : null,
    fld.tag71B ? f('71B', fld.tag71B) : null,
    fld.tag49  ? f('49',  fld.tag49)  : null,
    fld.tag57A ? f('57A', fld.tag57A) : (fld.tag57D ? f('57D', fld.tag57D) : null),
    f('77C', fld.tag77C),
    fld.tag72  ? f('72',  fld.tag72)  : null,
  ));
}

// ─── MT199 / MT799 – Free Format ─────────────────────────────────────────────
function buildFreeFormatBlock4(fld: MT199Fields | MT799Fields): string {
  return wrapBlock4(fields(
    f('20', fld.tag20),
    fld.tag21 ? f('21', fld.tag21) : null,
    f('79', fld.tag79),
  ));
}

// ─── Checksum ─────────────────────────────────────────────────────────────────
/**
 * SWIFT CHK field: 12-character hexadecimal CRC of Block 4 content.
 * Production SWIFT uses a proprietary algorithm; this implements a
 * standards-compatible SHA-like XOR-folded sum for demonstration.
 */
function computeChecksum(block4: string): string {
  let h = 0;
  for (let i = 0; i < block4.length; i++) {
    h = Math.imul(31, h) + block4.charCodeAt(i) | 0;
  }
  const abs = Math.abs(h);
  return abs.toString(16).toUpperCase().padStart(12, '0').slice(-12);
}

// ─── Main builder ─────────────────────────────────────────────────────────────
export function buildSWIFTMessage(msg: SWIFTMessage): string {
  const b1 = renderBlock1(msg.block1!);
  const b2 = renderBlock2(msg.block2!);
  const b3 = renderBlock3(msg.block3!);

  let b4 = '';
  switch (msg.messageType) {
    case 'MT700': b4 = buildMT700Block4(msg.block4 as MT700Fields); break;
    case 'MT705': b4 = buildMT705Block4(msg.block4 as MT705Fields); break;
    case 'MT760': b4 = buildMT760Block4(msg.block4 as MT760Fields); break;
    case 'MT199': b4 = buildFreeFormatBlock4(msg.block4 as MT199Fields); break;
    case 'MT799': b4 = buildFreeFormatBlock4(msg.block4 as MT799Fields); break;
    default:      b4 = '{4:\n-}';
  }

  const chk = computeChecksum(b4);
  const b5  = renderBlock5({ ...msg.block5, checksum: chk });

  return [b1, b2, b3, b4, b5].join('\n');
}

// ─── Block builders for new messages ─────────────────────────────────────────

export function buildBlock1(senderBIC: string, session: string, sequence: string): SWIFTBlock1 {
  return {
    applicationId: 'F',
    serviceId: '01',
    logicalTerminalAddress: padBICtoLTA(senderBIC),
    sessionNumber: session.padStart(4, '0').slice(-4),
    sequenceNumber: sequence.padStart(6, '0').slice(-6),
  };
}

export function buildBlock2Input(msgType: string, receiverBIC: string, priority = 'N'): SWIFTBlock2 {
  return {
    ioIndicator: 'I',
    messageType: msgType.replace('MT', ''),
    receiverAddress: padBICtoReceiver(receiverBIC),
    messagePriority: priority,
  };
}

export function buildBlock3(uetr: string, msgRef: string): SWIFTBlock3 {
  // Field 108 (Message User Reference) max 16 chars
  const ref16 = msgRef.replace(/[^A-Z0-9]/gi, '').slice(0, 16).toUpperCase();
  return {
    serviceIdentifier: 'CAT',
    messageUserReference: ref16,
    uetr,
  };
}

export function defaultBlock5(): SWIFTBlock5 {
  return {};
}
