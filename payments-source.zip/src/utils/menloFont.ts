/**
 * Menlo font for jsPDF
 * jsPDF ships three built-in typefaces: courier, helvetica, times.
 * "courier" is the standard PDF monospace font — identical metrics to
 * Courier New / Menlo for fixed-width output.
 * We use it directly (no network fetch, no CORS, instant load).
 */

import jsPDF from 'jspdf';

export const MENLO_FONT = 'courier';

/**
 * "Loads" the Menlo-equivalent font into a jsPDF instance.
 * Returns the font name to pass to doc.setFont().
 * Synchronous — no network required.
 */
export function loadMenloFont(_doc: jsPDF): string {
  return MENLO_FONT;
}
