/**
 * PDF Export — Alliance Access 7.7.70 Message Details Report
 * ─────────────────────────────────────────────────────────────
 * • White background  · Pure black text
 * • Font: Menlo / Courier  (built-in PDF monospace, no network fetch)
 * • Size: 10.77 pt
 * • No header · No footer · No message identifiers section
 * • Time derived from Debtor Agent BIC timezone
 */

import jsPDF from 'jspdf';
import { SWIFTMessage } from '../types';
import { getTimezoneFromBIC, bicToCountryCode } from './timezones';
import { loadMenloFont } from './menloFont';

// ─── Page geometry ─────────────────────────────────────────────────────────────
const PW = 210;          // A4 width  mm
const PH = 297;          // A4 height mm
const ML = 14;           // left margin mm
const MT = 14;           // top content Y  (no header)
const MB = 14;           // bottom guard   (no footer)
const CW = PW - ML - 14; // usable content width

// ─── Typography ────────────────────────────────────────────────────────────────
const FONT = loadMenloFont(null as unknown as jsPDF); // sync — returns 'courier'
const SZ   = 10.77;      // Menlo/Courier 10.77 pt
const LH   = 5.2;        // mm line-height

// ─── Column layout ─────────────────────────────────────────────────────────────
const TAB_V = 80;   // mm — absolute from page left, for report meta values
const TAB_R = 52;   // mm — relative from ML, for Interventions values

// ─── Timezone-aware date helpers ───────────────────────────────────────────────
interface LocalParts {
  dd: string; mm: string; yyyy: string;
  hh: string; min: string; ss: string;
  yy: string;
  offset: string;
}

function getLocalParts(date: Date, tz: string): LocalParts {
  const fmt = (opts: Intl.DateTimeFormatOptions) =>
    new Intl.DateTimeFormat('en-GB', { timeZone: tz, ...opts });

  const parts = fmt({
    year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', second: '2-digit',
    hour12: false,
  }).formatToParts(date);

  const get = (type: string) => parts.find(p => p.type === type)?.value ?? '00';

  const dd   = get('day');
  const mm   = get('month');
  const yyyy = get('year');
  const hh   = get('hour') === '24' ? '00' : get('hour');
  const min  = get('minute');
  const ss   = get('second');
  const yy   = yyyy.slice(-2);

  const offParts = new Intl.DateTimeFormat('en-US', {
    timeZone: tz, timeZoneName: 'shortOffset',
  }).formatToParts(date);
  const rawOff = offParts.find(p => p.type === 'timeZoneName')?.value ?? 'GMT';
  let offset = rawOff === 'GMT' ? '+00:00' : rawOff.replace('GMT', '');
  if (/^[+-]\d$/.test(offset))    offset = offset[0] + '0' + offset[1] + ':00';
  if (/^[+-]\d\d$/.test(offset))  offset = offset + ':00';
  if (!/^[+-]\d\d:\d\d$/.test(offset)) offset = '+00:00';

  return { dd, mm, yyyy, hh, min, ss, yy, offset };
}

/** "02.11.26-11:17:42 UTC" */
function fmtShort(lp: LocalParts): string {
  return `${lp.dd}.${lp.mm}.${lp.yy}-${lp.hh}:${lp.min}:${lp.ss} UTC`;
}

// ─── Extract Debtor Agent BIC ──────────────────────────────────────────────────
function getDbtrAgtBIC(msg: SWIFTMessage): string {
  if (msg.standard === 'ISO20022' && msg.isoFields) {
    const f = msg.isoFields as unknown as Record<string, string>;
    if (f.dbtrAgtBIC && f.dbtrAgtBIC.length >= 6) return f.dbtrAgtBIC;
    if (f.instgAgt   && f.instgAgt.length   >= 6) return f.instgAgt;
    if (f.svcr       && f.svcr.length       >= 6) return f.svcr;
  }
  return msg.senderBIC || 'CHASUS33';
}

// ─── White page ────────────────────────────────────────────────────────────────
function paintWhite(doc: jsPDF): void {
  doc.setFillColor(255, 255, 255);
  doc.rect(0, 0, PW, PH, 'F');
}

// ─── Page overflow guard ───────────────────────────────────────────────────────
function checkY(doc: jsPDF, y: number, need = LH): number {
  if (y + need <= PH - MB) return y;
  doc.addPage();
  paintWhite(doc);
  return MT;
}

// ─── Core text primitives ──────────────────────────────────────────────────────
function ln(
  doc  : jsPDF,
  y    : number,
  text : string,
  bold = false,
  sz   = SZ,
  x    = ML,
): number {
  y = checkY(doc, y, LH);
  doc.setFont(FONT, bold ? 'bold' : 'normal');
  doc.setFontSize(sz);
  doc.setTextColor(0, 0, 0);
  doc.text(text, x, y);
  return y + LH;
}

/**
 * Two-column key-value row.
 * label at ML, value at TAB_V (absolute from left).
 */
function kv(doc: jsPDF, y: number, label: string, value: string): number {
  y = checkY(doc, y, LH);
  doc.setFont(FONT, 'normal');
  doc.setFontSize(SZ);
  doc.setTextColor(0, 0, 0);
  doc.text(label, ML,    y);
  doc.text(value, TAB_V, y);
  return y + LH;
}

/**
 * Two-column row — label at ML, value at ML+TAB_R.
 * Used inside Interventions block.
 */
function kvRel(doc: jsPDF, y: number, label: string, value: string): number {
  y = checkY(doc, y, LH);
  doc.setFont(FONT, 'normal');
  doc.setFontSize(SZ);
  doc.setTextColor(0, 0, 0);
  doc.text(label,       ML,         y);
  doc.text(value,       ML + TAB_R, y);
  return y + LH;
}

/** Small vertical gap */
function gap(y: number, h = LH * 0.5): number { return y + h; }

// ─── Raw body printer ──────────────────────────────────────────────────────────
function printRaw(doc: jsPDF, y: number, raw: string): number {
  const lines = raw.split('\n');
  for (const rawLine of lines) {
    const parts: string[] =
      rawLine.length === 0
        ? ['']
        : (doc.splitTextToSize(rawLine, CW) as string[]);

    for (const part of parts) {
      y = checkY(doc, y, LH);
      doc.setFont(FONT, 'normal');
      doc.setFontSize(SZ);
      doc.setTextColor(0, 0, 0);
      doc.text(part, ML, y);
      y += LH;
    }
  }
  return y;
}

// ─── Checksum helper ───────────────────────────────────────────────────────────
function fakeChk(): string {
  const hex = '0123456789ABCDEF';
  let s = '';
  for (let i = 0; i < 12; i++) s += hex[Math.floor(Math.random() * 16)];
  return s;
}

// ─── Separator line ────────────────────────────────────────────────────────────
function separator(doc: jsPDF, y: number): number {
  y = checkY(doc, y, LH);
  doc.setFont(FONT, 'normal');
  doc.setFontSize(SZ);
  doc.setTextColor(0, 0, 0);
  doc.text('─'.repeat(72), ML, y);
  return y + LH;
}

// ─── Render one message block (all sections) ──────────────────────────────────
function renderMessageBlock(
  doc        : jsPDF,
  y          : number,
  msg        : SWIFTMessage,
  lp         : LocalParts,
  senderBIC  : string,
  isFirst    : boolean,
): number {
  // ── SECTION 1 — Report metadata ────────────────────────────────────────────
  if (!isFirst) {
    y = separator(doc, y);
    y = gap(y, LH * 0.5);
  }

  y = kv(doc, y, 'Application:',              'Alliance Access 7.7.70');
  y = kv(doc, y, 'Report type:',              'Message File - Message Details Report');
  y = kv(doc, y, 'Operator:',                 `${senderBIC} RMA`);
  y = kv(doc, y, 'Alliance Server Instance:', 'ADMIN UNIT');

  // Date-Time: date at TAB_V · time at TAB_V + 34 mm
  y = checkY(doc, y, LH);
  doc.setFont(FONT, 'normal');
  doc.setFontSize(SZ);
  doc.setTextColor(0, 0, 0);
  doc.text('Date-Time:',                    ML,          y);
  doc.text(`${lp.dd}/${lp.mm}/${lp.yyyy}`,  TAB_V,       y);
  doc.text(`${lp.hh}:${lp.min}:${lp.ss}`,   TAB_V + 34,  y);
  y += LH;

  // ── SECTION 2 — "Messages" heading ─────────────────────────────────────────
  y = gap(y, LH);
  y = ln(doc, y, 'Messages');
  y = gap(y, LH * 0.3);

  // ── SECTION 3 — Message Header + raw body ──────────────────────────────────
  y = ln(doc, y, 'Message Header');
  y = gap(y, LH * 0.3);
  y = printRaw(doc, y, msg.rawMessage);

  // ── SECTION 4 — Message Trailer ────────────────────────────────────────────
  y = gap(y, LH);
  y = ln(doc, y, 'Message Trailer');
  y = gap(y, LH * 0.3);
  const chk = msg.block5?.checksum ?? fakeChk();
  y = ln(doc, y, `{CHK: ${chk}}{DLM:}{TNG:}}{S:{SAC:}{COP:P}}`);

  // ── SECTION 5 — PKI Signature ──────────────────────────────────────────────
  y = gap(y, LH);
  y = ln(doc, y, 'PKI Signature MAC -Equivalent');

  // ── SECTION 6 — Interventions ──────────────────────────────────────────────
  y = gap(y, LH);
  y = ln(doc, y, 'Interventions');
  y = gap(y, LH * 0.4);
  y = kvRel(doc, y, 'CATEGORY:',      'NETWORK REPORT');
  y = kvRel(doc, y, 'CREATION TIME:', fmtShort(lp));
  y = kvRel(doc, y, 'APPLICATION:',   'SWIFT INTERFACE');
  y = kvRel(doc, y, 'OPERATOR:',      'SYSTEM');

  return y;
}

// ─── Main single-message export ────────────────────────────────────────────────
export function exportMessageToPDF(msg: SWIFTMessage): void {
  const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
  const now = new Date();

  const dbtrBIC  = getDbtrAgtBIC(msg);
  void bicToCountryCode(dbtrBIC);
  const tzInfo   = getTimezoneFromBIC(dbtrBIC);
  const lp       = getLocalParts(now, tzInfo.timezone);
  const senderBIC = (msg.senderBIC || '').replace(/\s+/g, '').toUpperCase() || 'RMA';

  paintWhite(doc);
  let y = MT;

  y = renderMessageBlock(doc, y, msg, lp, senderBIC, true);

  const safeRef  = (msg.identifiers?.transactionRef ?? 'MSG').replace(/[^A-Za-z0-9_-]/g, '_');
  const dateStr  = `${lp.dd}${lp.mm}${lp.yyyy}`;
  doc.save(`${msg.messageType}_${safeRef}_${dateStr}.pdf`);
}

// ─── Bundle export: pacs.008 + derived camt.054 in one PDF ────────────────────
export function exportBundleToPDF(
  pacs008: SWIFTMessage,
  camt054: SWIFTMessage,
): void {
  const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
  const now = new Date();

  const dbtrBIC   = getDbtrAgtBIC(pacs008);
  void bicToCountryCode(dbtrBIC);
  const tzInfo    = getTimezoneFromBIC(dbtrBIC);
  const lp        = getLocalParts(now, tzInfo.timezone);
  const senderBIC = (pacs008.senderBIC || '').replace(/\s+/g, '').toUpperCase() || 'RMA';

  paintWhite(doc);
  let y = MT;

  // Render pacs.008
  y = renderMessageBlock(doc, y, pacs008, lp, senderBIC, true);

  // Page break before camt.054
  doc.addPage();
  paintWhite(doc);
  y = MT;

  // Derive camt.054 timezone from creditor agent BIC
  const cdtrBIC   = getDbtrAgtBIC(camt054);
  const tzInfo054 = getTimezoneFromBIC(cdtrBIC);
  const lp054     = getLocalParts(now, tzInfo054.timezone);
  const sender054 = (camt054.senderBIC || '').replace(/\s+/g, '').toUpperCase() || 'RMA';

  y = renderMessageBlock(doc, y, camt054, lp054, sender054, false);

  const safeRef = (pacs008.identifiers?.transactionRef ?? 'MSG').replace(/[^A-Za-z0-9_-]/g, '_');
  const dateStr = `${lp.dd}${lp.mm}${lp.yyyy}`;
  doc.save(`BUNDLE_pacs008_camt054_${safeRef}_${dateStr}.pdf`);
}
