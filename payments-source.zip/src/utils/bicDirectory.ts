/**
 * BIC Directory — Real-world bank lookup database
 * Maps BIC (8-char institution+country+location) to bank details
 * Covers major correspondent banks worldwide
 */

export interface BankInfo {
  bic8: string;           // 8-char BIC (no branch)
  name: string;           // Full official bank name
  shortName: string;      // Common name
  city: string;
  country: string;
  countryCode: string;    // ISO 3166-1 alpha-2
  category: string;       // 'Central Bank' | 'Commercial' | 'Investment' | 'Islamic' | 'Development' | 'Custodian'
  currency?: string;      // Primary currency
}

const DIRECTORY: BankInfo[] = [
  // ── United States ──────────────────────────────────────────────────────────
  { bic8:'CHASUS33', name:'JPMorgan Chase Bank, N.A.',             shortName:'JPMorgan Chase',    city:'New York',       country:'United States',    countryCode:'US', category:'Commercial',  currency:'USD' },
  { bic8:'CITIUS33', name:'Citibank N.A.',                         shortName:'Citibank',          city:'New York',       country:'United States',    countryCode:'US', category:'Commercial',  currency:'USD' },
  { bic8:'BOFAUS3N', name:'Bank of America, N.A.',                 shortName:'Bank of America',   city:'Charlotte',      country:'United States',    countryCode:'US', category:'Commercial',  currency:'USD' },
  { bic8:'WFBIUS6S', name:'Wells Fargo Bank, N.A.',                shortName:'Wells Fargo',       city:'San Francisco',  country:'United States',    countryCode:'US', category:'Commercial',  currency:'USD' },
  { bic8:'MRMDUS33', name:'Merrill Lynch Bank USA',                shortName:'Merrill Lynch',     city:'New York',       country:'United States',    countryCode:'US', category:'Investment',  currency:'USD' },
  { bic8:'IRVTUS3N', name:'BNY Mellon',                            shortName:'BNY Mellon',        city:'New York',       country:'United States',    countryCode:'US', category:'Custodian',   currency:'USD' },
  { bic8:'STSAUS33', name:'State Street Bank and Trust Company',   shortName:'State Street',      city:'Boston',         country:'United States',    countryCode:'US', category:'Custodian',   currency:'USD' },
  { bic8:'SVBKUS6S', name:'Silicon Valley Bank',                   shortName:'SVB',               city:'Santa Clara',    country:'United States',    countryCode:'US', category:'Commercial',  currency:'USD' },
  { bic8:'USBKUS44', name:'U.S. Bank National Association',        shortName:'US Bank',           city:'Minneapolis',    country:'United States',    countryCode:'US', category:'Commercial',  currency:'USD' },
  { bic8:'PNCCUS33', name:'PNC Bank, National Association',        shortName:'PNC Bank',          city:'Pittsburgh',     country:'United States',    countryCode:'US', category:'Commercial',  currency:'USD' },
  { bic8:'FRNYUS33', name:'Federal Reserve Bank of New York',      shortName:'Fed Reserve NY',    city:'New York',       country:'United States',    countryCode:'US', category:'Central Bank',currency:'USD' },
  { bic8:'GOLDUS33', name:'Goldman Sachs Bank USA',                shortName:'Goldman Sachs',     city:'New York',       country:'United States',    countryCode:'US', category:'Investment',  currency:'USD' },
  { bic8:'MSBKUS33', name:'Morgan Stanley Bank, N.A.',             shortName:'Morgan Stanley',    city:'New York',       country:'United States',    countryCode:'US', category:'Investment',  currency:'USD' },

  // ── United Kingdom ─────────────────────────────────────────────────────────
  { bic8:'BARCGB22', name:'Barclays Bank PLC',                     shortName:'Barclays',          city:'London',         country:'United Kingdom',   countryCode:'GB', category:'Commercial',  currency:'GBP' },
  { bic8:'HBUKGB4B', name:'HSBC Bank PLC',                         shortName:'HSBC UK',           city:'London',         country:'United Kingdom',   countryCode:'GB', category:'Commercial',  currency:'GBP' },
  { bic8:'NWBKGB2L', name:'NatWest Bank PLC',                      shortName:'NatWest',           city:'London',         country:'United Kingdom',   countryCode:'GB', category:'Commercial',  currency:'GBP' },
  { bic8:'LOYDGB2L', name:'Lloyds Bank PLC',                       shortName:'Lloyds Bank',       city:'London',         country:'United Kingdom',   countryCode:'GB', category:'Commercial',  currency:'GBP' },
  { bic8:'SCBLGB2L', name:'Standard Chartered Bank',               shortName:'Standard Chartered',city:'London',         country:'United Kingdom',   countryCode:'GB', category:'Commercial',  currency:'GBP' },
  { bic8:'CHASGB2L', name:'JPMorgan Chase Bank N.A. London',       shortName:'JPMorgan London',   city:'London',         country:'United Kingdom',   countryCode:'GB', category:'Commercial',  currency:'GBP' },
  { bic8:'CITIGB2L', name:'Citibank N.A. London Branch',           shortName:'Citibank London',   city:'London',         country:'United Kingdom',   countryCode:'GB', category:'Commercial',  currency:'GBP' },
  { bic8:'BKENGB2L', name:'Bank of England',                       shortName:'Bank of England',   city:'London',         country:'United Kingdom',   countryCode:'GB', category:'Central Bank',currency:'GBP' },
  { bic8:'RBOSGB2L', name:'Royal Bank of Scotland PLC',            shortName:'RBS',               city:'Edinburgh',      country:'United Kingdom',   countryCode:'GB', category:'Commercial',  currency:'GBP' },
  { bic8:'HBUKGB41', name:'HSBC UK Bank PLC',                      shortName:'HSBC UK Bank',      city:'Birmingham',     country:'United Kingdom',   countryCode:'GB', category:'Commercial',  currency:'GBP' },

  // ── European Union ─────────────────────────────────────────────────────────
  { bic8:'DEUTDEDB', name:'Deutsche Bank AG',                      shortName:'Deutsche Bank',     city:'Frankfurt',      country:'Germany',          countryCode:'DE', category:'Commercial',  currency:'EUR' },
  { bic8:'COBADEFF', name:'Commerzbank AG',                        shortName:'Commerzbank',       city:'Frankfurt',      country:'Germany',          countryCode:'DE', category:'Commercial',  currency:'EUR' },
  { bic8:'DRESDEFF', name:'Commerzbank AG (formerly Dresdner)',     shortName:'Dresdner/Comm.',    city:'Frankfurt',      country:'Germany',          countryCode:'DE', category:'Commercial',  currency:'EUR' },
  { bic8:'MARKDEFF', name:'Bundesbank',                            shortName:'Bundesbank',        city:'Frankfurt',      country:'Germany',          countryCode:'DE', category:'Central Bank',currency:'EUR' },
  { bic8:'BNPAFRPP', name:'BNP Paribas S.A.',                      shortName:'BNP Paribas',       city:'Paris',          country:'France',           countryCode:'FR', category:'Commercial',  currency:'EUR' },
  { bic8:'SOGEFRPP', name:'Société Générale S.A.',                 shortName:'Société Générale',  city:'Paris',          country:'France',           countryCode:'FR', category:'Commercial',  currency:'EUR' },
  { bic8:'CRLYFRPP', name:'Crédit Lyonnais (LCL)',                  shortName:'LCL',               city:'Paris',          country:'France',           countryCode:'FR', category:'Commercial',  currency:'EUR' },
  { bic8:'BNKIFRPP', name:'Banque de France',                      shortName:'Banque de France',  city:'Paris',          country:'France',           countryCode:'FR', category:'Central Bank',currency:'EUR' },
  { bic8:'INGBNL2A', name:'ING Bank N.V.',                         shortName:'ING Bank',          city:'Amsterdam',      country:'Netherlands',      countryCode:'NL', category:'Commercial',  currency:'EUR' },
  { bic8:'ABNANL2A', name:'ABN AMRO Bank N.V.',                    shortName:'ABN AMRO',          city:'Amsterdam',      country:'Netherlands',      countryCode:'NL', category:'Commercial',  currency:'EUR' },
  { bic8:'RABONL2U', name:'Coöperatieve Rabobank U.A.',            shortName:'Rabobank',          city:'Utrecht',        country:'Netherlands',      countryCode:'NL', category:'Commercial',  currency:'EUR' },
  { bic8:'UBSWCHZH', name:'UBS AG',                                shortName:'UBS',               city:'Zurich',         country:'Switzerland',      countryCode:'CH', category:'Investment',  currency:'CHF' },
  { bic8:'CRESCHZZ', name:'Credit Suisse AG',                      shortName:'Credit Suisse',     city:'Zurich',         country:'Switzerland',      countryCode:'CH', category:'Investment',  currency:'CHF' },
  { bic8:'SNBZCHZZ', name:'Swiss National Bank',                   shortName:'Swiss Natl Bank',   city:'Bern',           country:'Switzerland',      countryCode:'CH', category:'Central Bank',currency:'CHF' },
  { bic8:'BCPLCHGG', name:'Banque Cantonale de Genève',            shortName:'BCGE',              city:'Geneva',         country:'Switzerland',      countryCode:'CH', category:'Commercial',  currency:'CHF' },
  { bic8:'BSCHESMM', name:'Banco Santander S.A.',                  shortName:'Santander',         city:'Madrid',         country:'Spain',            countryCode:'ES', category:'Commercial',  currency:'EUR' },
  { bic8:'BBVAESMM', name:'Banco Bilbao Vizcaya Argentaria S.A.',  shortName:'BBVA',              city:'Madrid',         country:'Spain',            countryCode:'ES', category:'Commercial',  currency:'EUR' },
  { bic8:'CAIXESBB', name:'CaixaBank S.A.',                        shortName:'CaixaBank',         city:'Barcelona',      country:'Spain',            countryCode:'ES', category:'Commercial',  currency:'EUR' },
  { bic8:'UNCRITMM', name:'UniCredit S.p.A.',                      shortName:'UniCredit',         city:'Milan',          country:'Italy',            countryCode:'IT', category:'Commercial',  currency:'EUR' },
  { bic8:'BNLIITRR', name:'BNL – BNP Paribas Group Italy',         shortName:'BNL',               city:'Rome',           country:'Italy',            countryCode:'IT', category:'Commercial',  currency:'EUR' },
  { bic8:'INTBITIT', name:'Banca d\'Italia',                       shortName:'Banca d\'Italia',   city:'Rome',           country:'Italy',            countryCode:'IT', category:'Central Bank',currency:'EUR' },
  { bic8:'GEBABEBB', name:'BNP Paribas Fortis SA/NV',             shortName:'BNP Fortis',        city:'Brussels',       country:'Belgium',          countryCode:'BE', category:'Commercial',  currency:'EUR' },
  { bic8:'KREDBEBB', name:'KBC Bank NV',                           shortName:'KBC Bank',          city:'Brussels',       country:'Belgium',          countryCode:'BE', category:'Commercial',  currency:'EUR' },
  { bic8:'NBBEBEBB', name:'Nationale Bank van België',             shortName:'Natl Bank Belgium', city:'Brussels',       country:'Belgium',          countryCode:'BE', category:'Central Bank',currency:'EUR' },
  { bic8:'HANDDEFF', name:'Landesbank Baden-Württemberg',          shortName:'LBBW',              city:'Stuttgart',      country:'Germany',          countryCode:'DE', category:'Commercial',  currency:'EUR' },
  { bic8:'DABAIE2D', name:'Danske Bank A/S Ireland',               shortName:'Danske Bank IE',    city:'Dublin',         country:'Ireland',          countryCode:'IE', category:'Commercial',  currency:'EUR' },
  { bic8:'AIBKIE2D', name:'AIB – Allied Irish Banks',              shortName:'AIB',               city:'Dublin',         country:'Ireland',          countryCode:'IE', category:'Commercial',  currency:'EUR' },
  { bic8:'BOFIIE2D', name:'Bank of Ireland',                       shortName:'Bank of Ireland',   city:'Dublin',         country:'Ireland',          countryCode:'IE', category:'Commercial',  currency:'EUR' },

  // ── Switzerland / Liechtenstein ────────────────────────────────────────────
  { bic8:'ZKBKCHZZ', name:'Zürcher Kantonalbank',                  shortName:'ZKB',               city:'Zurich',         country:'Switzerland',      countryCode:'CH', category:'Commercial',  currency:'CHF' },
  { bic8:'POFICHBEXXX',name:'PostFinance AG',                      shortName:'PostFinance',       city:'Bern',           country:'Switzerland',      countryCode:'CH', category:'Commercial',  currency:'CHF' },

  // ── Middle East ────────────────────────────────────────────────────────────
  { bic8:'NBADAEAA', name:'First Abu Dhabi Bank PJSC',             shortName:'FAB',               city:'Abu Dhabi',      country:'United Arab Emirates',countryCode:'AE',category:'Commercial', currency:'AED' },
  { bic8:'ADCBAEAA', name:'Abu Dhabi Commercial Bank PJSC',        shortName:'ADCB',              city:'Abu Dhabi',      country:'United Arab Emirates',countryCode:'AE',category:'Commercial', currency:'AED' },
  { bic8:'ABDIAEAA', name:'Abu Dhabi Islamic Bank PJSC',           shortName:'ADIB',              city:'Abu Dhabi',      country:'United Arab Emirates',countryCode:'AE',category:'Islamic',    currency:'AED' },
  { bic8:'ABDIAEADXXX',name:'Abu Dhabi Islamic Bank PJSC (Dubai)', shortName:'ADIB Dubai',        city:'Dubai',          country:'United Arab Emirates',countryCode:'AE',category:'Islamic',    currency:'AED' },
  { bic8:'EBILAEAD', name:'Emirates NBD Bank PJSC',                shortName:'Emirates NBD',      city:'Dubai',          country:'United Arab Emirates',countryCode:'AE',category:'Commercial', currency:'AED' },
  { bic8:'DUSBAEAD', name:'Dubai Islamic Bank PJSC',               shortName:'DIB',               city:'Dubai',          country:'United Arab Emirates',countryCode:'AE',category:'Islamic',    currency:'AED' },
  { bic8:'MASQOMRX', name:'Bank Muscat SAOG',                      shortName:'Bank Muscat',       city:'Muscat',         country:'Oman',             countryCode:'OM', category:'Commercial',  currency:'OMR' },
  { bic8:'NBOOOMRX', name:'National Bank of Oman SAOG',            shortName:'NBO',               city:'Muscat',         country:'Oman',             countryCode:'OM', category:'Commercial',  currency:'OMR' },
  { bic8:'ARABJOAX', name:'Arab Bank PLC',                         shortName:'Arab Bank',         city:'Amman',          country:'Jordan',           countryCode:'JO', category:'Commercial',  currency:'JOD' },
  { bic8:'CBJOJOAX', name:'Central Bank of Jordan',                shortName:'CBJ',               city:'Amman',          country:'Jordan',           countryCode:'JO', category:'Central Bank',currency:'JOD' },
  { bic8:'RIBLQAQA', name:'Qatar Islamic Bank SAQ',                shortName:'QIB',               city:'Doha',           country:'Qatar',            countryCode:'QA', category:'Islamic',    currency:'QAR' },
  { bic8:'QNBAQAQA', name:'Qatar National Bank (Q.P.S.C.)',        shortName:'QNB',               city:'Doha',           country:'Qatar',            countryCode:'QA', category:'Commercial',  currency:'QAR' },
  { bic8:'NCBKSAJE', name:'Saudi National Bank',                   shortName:'SNB',               city:'Riyadh',         country:'Saudi Arabia',     countryCode:'SA', category:'Commercial',  currency:'SAR' },
  { bic8:'RIBLSARI', name:'Riyad Bank',                            shortName:'Riyad Bank',        city:'Riyadh',         country:'Saudi Arabia',     countryCode:'SA', category:'Commercial',  currency:'SAR' },
  { bic8:'RJHISARI', name:'Al Rajhi Bank',                         shortName:'Al Rajhi',          city:'Riyadh',         country:'Saudi Arabia',     countryCode:'SA', category:'Islamic',    currency:'SAR' },
  { bic8:'SABBSARI', name:'Saudi British Bank (SABB)',              shortName:'SABB/HSBC',         city:'Riyadh',         country:'Saudi Arabia',     countryCode:'SA', category:'Commercial',  currency:'SAR' },
  { bic8:'SAMBSARI', name:'Saudi American Bank (Samba)',            shortName:'Samba Financial',   city:'Riyadh',         country:'Saudi Arabia',     countryCode:'SA', category:'Commercial',  currency:'SAR' },
  { bic8:'NBKUKWKW', name:'National Bank of Kuwait S.A.K.P.',      shortName:'NBK',               city:'Kuwait City',    country:'Kuwait',           countryCode:'KW', category:'Commercial',  currency:'KWD' },
  { bic8:'CBKUKWKW', name:'Commercial Bank of Kuwait S.A.K.P.',    shortName:'CBK',               city:'Kuwait City',    country:'Kuwait',           countryCode:'KW', category:'Commercial',  currency:'KWD' },
  { bic8:'NBOBBHBM', name:'National Bank of Bahrain B.S.C.',       shortName:'NBB',               city:'Manama',         country:'Bahrain',          countryCode:'BH', category:'Commercial',  currency:'BHD' },
  { bic8:'ALBHBHBM', name:'Ahli United Bank B.S.C.',               shortName:'AUB Bahrain',       city:'Manama',         country:'Bahrain',          countryCode:'BH', category:'Commercial',  currency:'BHD' },
  { bic8:'BMISEGCA', name:'Banque Misr',                           shortName:'Banque Misr',       city:'Cairo',          country:'Egypt',            countryCode:'EG', category:'Commercial',  currency:'EGP' },
  { bic8:'NBEGEGCA', name:'National Bank of Egypt',                shortName:'NBE',               city:'Cairo',          country:'Egypt',            countryCode:'EG', category:'Commercial',  currency:'EGP' },
  { bic8:'CBEGEGCA', name:'Central Bank of Egypt',                 shortName:'CBE',               city:'Cairo',          country:'Egypt',            countryCode:'EG', category:'Central Bank',currency:'EGP' },

  // ── Asia Pacific ───────────────────────────────────────────────────────────
  { bic8:'ICBKCNBJ', name:'Industrial and Commercial Bank of China',shortName:'ICBC',             city:'Beijing',        country:'China',            countryCode:'CN', category:'Commercial',  currency:'CNY' },
  { bic8:'BKCHCNBJ', name:'Bank of China',                         shortName:'Bank of China',     city:'Beijing',        country:'China',            countryCode:'CN', category:'Commercial',  currency:'CNY' },
  { bic8:'PCBCCNBJ', name:'China Construction Bank',               shortName:'CCB',               city:'Beijing',        country:'China',            countryCode:'CN', category:'Commercial',  currency:'CNY' },
  { bic8:'ABOCCNBJ', name:'Agricultural Bank of China',            shortName:'ABC',               city:'Beijing',        country:'China',            countryCode:'CN', category:'Commercial',  currency:'CNY' },
  { bic8:'PBOCCNBX', name:'People\'s Bank of China',               shortName:'PBOC',              city:'Beijing',        country:'China',            countryCode:'CN', category:'Central Bank',currency:'CNY' },
  { bic8:'HSBCHKHH', name:'HSBC – Hong Kong & Shanghai Banking',   shortName:'HSBC HK',           city:'Hong Kong',      country:'Hong Kong',        countryCode:'HK', category:'Commercial',  currency:'HKD' },
  { bic8:'SCBLHKHH', name:'Standard Chartered Bank (HK) Ltd',      shortName:'SCB HK',            city:'Hong Kong',      country:'Hong Kong',        countryCode:'HK', category:'Commercial',  currency:'HKD' },
  { bic8:'BOSHKHHX', name:'Bank of East Asia',                     shortName:'BEA',               city:'Hong Kong',      country:'Hong Kong',        countryCode:'HK', category:'Commercial',  currency:'HKD' },
  { bic8:'DBSSSGSG', name:'DBS Bank Ltd',                          shortName:'DBS',               city:'Singapore',      country:'Singapore',        countryCode:'SG', category:'Commercial',  currency:'SGD' },
  { bic8:'OCBCSGSG', name:'Oversea-Chinese Banking Corporation',   shortName:'OCBC',              city:'Singapore',      country:'Singapore',        countryCode:'SG', category:'Commercial',  currency:'SGD' },
  { bic8:'UOVBSGSG', name:'United Overseas Bank Ltd',              shortName:'UOB',               city:'Singapore',      country:'Singapore',        countryCode:'SG', category:'Commercial',  currency:'SGD' },
  { bic8:'MASSGSG2', name:'Monetary Authority of Singapore',       shortName:'MAS',               city:'Singapore',      country:'Singapore',        countryCode:'SG', category:'Central Bank',currency:'SGD' },
  { bic8:'MHCBJPJT', name:'Mizuho Bank, Ltd.',                     shortName:'Mizuho Bank',       city:'Tokyo',          country:'Japan',            countryCode:'JP', category:'Commercial',  currency:'JPY' },
  { bic8:'BOTKJPJT', name:'MUFG Bank, Ltd.',                       shortName:'MUFG',              city:'Tokyo',          country:'Japan',            countryCode:'JP', category:'Commercial',  currency:'JPY' },
  { bic8:'SMBCJPJT', name:'Sumitomo Mitsui Banking Corporation',   shortName:'SMBC',              city:'Tokyo',          country:'Japan',            countryCode:'JP', category:'Commercial',  currency:'JPY' },
  { bic8:'BOJPJPJT', name:'Bank of Japan',                         shortName:'Bank of Japan',     city:'Tokyo',          country:'Japan',            countryCode:'JP', category:'Central Bank',currency:'JPY' },
  { bic8:'HNBNKRSE', name:'Hana Bank',                             shortName:'Hana Bank',         city:'Seoul',          country:'South Korea',      countryCode:'KR', category:'Commercial',  currency:'KRW' },
  { bic8:'KOEXKRSE', name:'Korea Exchange Bank',                   shortName:'KEB',               city:'Seoul',          country:'South Korea',      countryCode:'KR', category:'Commercial',  currency:'KRW' },
  { bic8:'ICICINBB', name:'ICICI Bank Limited',                    shortName:'ICICI Bank',        city:'Mumbai',         country:'India',            countryCode:'IN', category:'Commercial',  currency:'INR' },
  { bic8:'HDFCINBB', name:'HDFC Bank Limited',                     shortName:'HDFC Bank',         city:'Mumbai',         country:'India',            countryCode:'IN', category:'Commercial',  currency:'INR' },
  { bic8:'SBININBB', name:'State Bank of India',                   shortName:'SBI',               city:'Mumbai',         country:'India',            countryCode:'IN', category:'Commercial',  currency:'INR' },
  { bic8:'RBIIINBB', name:'Reserve Bank of India',                 shortName:'RBI',               city:'Mumbai',         country:'India',            countryCode:'IN', category:'Central Bank',currency:'INR' },
  { bic8:'ANZBAEAD', name:'Australia and New Zealand Banking Group',shortName:'ANZ Bank',         city:'Melbourne',      country:'Australia',        countryCode:'AU', category:'Commercial',  currency:'AUD' },
  { bic8:'NATAAU33', name:'National Australia Bank',               shortName:'NAB',               city:'Melbourne',      country:'Australia',        countryCode:'AU', category:'Commercial',  currency:'AUD' },
  { bic8:'CTBAAU2S', name:'Commonwealth Bank of Australia',        shortName:'CBA',               city:'Sydney',         country:'Australia',        countryCode:'AU', category:'Commercial',  currency:'AUD' },
  { bic8:'WPACAU2S', name:'Westpac Banking Corporation',           shortName:'Westpac',           city:'Sydney',         country:'Australia',        countryCode:'AU', category:'Commercial',  currency:'AUD' },
  { bic8:'RBABAABB', name:'Reserve Bank of Australia',             shortName:'RBA',               city:'Sydney',         country:'Australia',        countryCode:'AU', category:'Central Bank',currency:'AUD' },
  { bic8:'BKKBTHBK', name:'Bangkok Bank Public Co. Ltd',           shortName:'Bangkok Bank',      city:'Bangkok',        country:'Thailand',         countryCode:'TH', category:'Commercial',  currency:'THB' },
  { bic8:'KASIKATH', name:'KASIKORNBANK PCL',                      shortName:'KBank',             city:'Bangkok',        country:'Thailand',         countryCode:'TH', category:'Commercial',  currency:'THB' },
  { bic8:'BNINIDJX', name:'Bank Negara Indonesia (Persero)',        shortName:'BNI',               city:'Jakarta',        country:'Indonesia',        countryCode:'ID', category:'Commercial',  currency:'IDR' },
  { bic8:'CENAIDJA', name:'Bank Central Asia Tbk',                 shortName:'BCA',               city:'Jakarta',        country:'Indonesia',        countryCode:'ID', category:'Commercial',  currency:'IDR' },

  // ── Africa ─────────────────────────────────────────────────────────────────
  { bic8:'SBZAZAJJ', name:'Standard Bank of South Africa Ltd',     shortName:'Standard Bank',     city:'Johannesburg',   country:'South Africa',     countryCode:'ZA', category:'Commercial',  currency:'ZAR' },
  { bic8:'FIRNZAJJ', name:'FirstRand Bank Limited',                shortName:'FNB / FirstRand',   city:'Johannesburg',   country:'South Africa',     countryCode:'ZA', category:'Commercial',  currency:'ZAR' },
  { bic8:'ABSAZAJJ', name:'ABSA Bank Limited',                     shortName:'ABSA',              city:'Johannesburg',   country:'South Africa',     countryCode:'ZA', category:'Commercial',  currency:'ZAR' },
  { bic8:'NEDSZAJJ', name:'Nedbank Limited',                       shortName:'Nedbank',           city:'Johannesburg',   country:'South Africa',     countryCode:'ZA', category:'Commercial',  currency:'ZAR' },
  { bic8:'RESAZAJJ', name:'South African Reserve Bank',            shortName:'SARB',              city:'Pretoria',       country:'South Africa',     countryCode:'ZA', category:'Central Bank',currency:'ZAR' },
  { bic8:'CBAFNGLA', name:'Central Bank of Nigeria',               shortName:'CBN',               city:'Abuja',          country:'Nigeria',          countryCode:'NG', category:'Central Bank',currency:'NGN' },
  { bic8:'ZENITHNG', name:'Zenith Bank PLC',                       shortName:'Zenith Bank',       city:'Lagos',          country:'Nigeria',          countryCode:'NG', category:'Commercial',  currency:'NGN' },
  { bic8:'GTBINGLA', name:'Guaranty Trust Bank PLC',               shortName:'GTBank',            city:'Lagos',          country:'Nigeria',          countryCode:'NG', category:'Commercial',  currency:'NGN' },
  { bic8:'ACCESSNG', name:'Access Bank PLC',                       shortName:'Access Bank',       city:'Lagos',          country:'Nigeria',          countryCode:'NG', category:'Commercial',  currency:'NGN' },
  { bic8:'FIDTKENX', name:'KCB Bank Kenya Limited',                shortName:'KCB Bank',          city:'Nairobi',        country:'Kenya',            countryCode:'KE', category:'Commercial',  currency:'KES' },
  { bic8:'CBKNKENA', name:'Central Bank of Kenya',                 shortName:'CBK',               city:'Nairobi',        country:'Kenya',            countryCode:'KE', category:'Central Bank',currency:'KES' },
  { bic8:'EQBLKENA', name:'Equity Bank Kenya Limited',             shortName:'Equity Bank',       city:'Nairobi',        country:'Kenya',            countryCode:'KE', category:'Commercial',  currency:'KES' },

  // ── Canada ─────────────────────────────────────────────────────────────────
  { bic8:'ROYCCAT2', name:'Royal Bank of Canada',                  shortName:'RBC',               city:'Toronto',        country:'Canada',           countryCode:'CA', category:'Commercial',  currency:'CAD' },
  { bic8:'TDOMCATTTOR',name:'Toronto-Dominion Bank',               shortName:'TD Bank',           city:'Toronto',        country:'Canada',           countryCode:'CA', category:'Commercial',  currency:'CAD' },
  { bic8:'BOFMCAM2', name:'Bank of Montreal',                      shortName:'BMO',               city:'Montreal',       country:'Canada',           countryCode:'CA', category:'Commercial',  currency:'CAD' },
  { bic8:'NOSCCAT2', name:'Bank of Nova Scotia',                   shortName:'Scotiabank',        city:'Toronto',        country:'Canada',           countryCode:'CA', category:'Commercial',  currency:'CAD' },
  { bic8:'CIBCCATT', name:'CIBC – Canadian Imperial Bank',         shortName:'CIBC',              city:'Toronto',        country:'Canada',           countryCode:'CA', category:'Commercial',  currency:'CAD' },
  { bic8:'BOCMCAM2', name:'Bank of Canada',                        shortName:'Bank of Canada',    city:'Ottawa',         country:'Canada',           countryCode:'CA', category:'Central Bank',currency:'CAD' },

  // ── Latin America ──────────────────────────────────────────────────────────
  { bic8:'BRASBRRJ', name:'Banco do Brasil S.A.',                  shortName:'Banco do Brasil',   city:'Brasília',       country:'Brazil',           countryCode:'BR', category:'Commercial',  currency:'BRL' },
  { bic8:'ITAUBRSP', name:'Itaú Unibanco S.A.',                    shortName:'Itaú',              city:'São Paulo',      country:'Brazil',           countryCode:'BR', category:'Commercial',  currency:'BRL' },
  { bic8:'ISBKBRSP', name:'Banco Bradesco S.A.',                   shortName:'Bradesco',          city:'São Paulo',      country:'Brazil',           countryCode:'BR', category:'Commercial',  currency:'BRL' },
  { bic8:'BCBRBRSP', name:'Banco Central do Brasil',               shortName:'Banco Central',     city:'Brasília',       country:'Brazil',           countryCode:'BR', category:'Central Bank',currency:'BRL' },
  { bic8:'BCMRMXMM', name:'Banco de México',                       shortName:'Banxico',           city:'Mexico City',    country:'Mexico',           countryCode:'MX', category:'Central Bank',currency:'MXN' },
  { bic8:'BCMEMXMM', name:'BBVA Bancomer S.A.',                    shortName:'BBVA México',       city:'Mexico City',    country:'Mexico',           countryCode:'MX', category:'Commercial',  currency:'MXN' },

  // ── Nordic ─────────────────────────────────────────────────────────────────
  { bic8:'NDEASESS', name:'Nordea Bank Abp, Sweden Branch',        shortName:'Nordea SE',         city:'Stockholm',      country:'Sweden',           countryCode:'SE', category:'Commercial',  currency:'SEK' },
  { bic8:'HANDSESS', name:'Svenska Handelsbanken AB',              shortName:'Handelsbanken',     city:'Stockholm',      country:'Sweden',           countryCode:'SE', category:'Commercial',  currency:'SEK' },
  { bic8:'SWEDSESS', name:'Swedbank AB',                           shortName:'Swedbank',          city:'Stockholm',      country:'Sweden',           countryCode:'SE', category:'Commercial',  currency:'SEK' },
  { bic8:'DNBANOKKK',name:'DNB Bank ASA',                          shortName:'DNB Bank',          city:'Oslo',           country:'Norway',           countryCode:'NO', category:'Commercial',  currency:'NOK' },
  { bic8:'NDEADKKK', name:'Nordea Bank Abp, Denmark Branch',       shortName:'Nordea DK',         city:'Copenhagen',     country:'Denmark',          countryCode:'DK', category:'Commercial',  currency:'DKK' },
  { bic8:'DABADKKK', name:'Danske Bank A/S',                       shortName:'Danske Bank',       city:'Copenhagen',     country:'Denmark',          countryCode:'DK', category:'Commercial',  currency:'DKK' },

  // ── Eastern Europe / Russia ────────────────────────────────────────────────
  { bic8:'SABRRUMM', name:'Sberbank of Russia',                    shortName:'Sberbank',          city:'Moscow',         country:'Russia',           countryCode:'RU', category:'Commercial',  currency:'RUB' },
  { bic8:'VTBRRUMM', name:'VTB Bank PJSC',                         shortName:'VTB Bank',          city:'Moscow',         country:'Russia',           countryCode:'RU', category:'Commercial',  currency:'RUB' },
  { bic8:'CBRFRUMM', name:'Central Bank of the Russian Federation',shortName:'Bank of Russia',    city:'Moscow',         country:'Russia',           countryCode:'RU', category:'Central Bank',currency:'RUB' },
  { bic8:'PKOPPLPW', name:'PKO Bank Polski S.A.',                  shortName:'PKO Bank',          city:'Warsaw',         country:'Poland',           countryCode:'PL', category:'Commercial',  currency:'PLN' },
  { bic8:'NBPLPLPW', name:'Narodowy Bank Polski',                  shortName:'NBP',               city:'Warsaw',         country:'Poland',           countryCode:'PL', category:'Central Bank',currency:'PLN' },
];

/** Build a lookup map keyed by BIC8 (normalised, uppercase) */
const LOOKUP = new Map<string, BankInfo>();
DIRECTORY.forEach(b => {
  LOOKUP.set(b.bic8.toUpperCase().slice(0, 8), b);
  // Also index the full BIC11 variant if provided
  if (b.bic8.length > 8) LOOKUP.set(b.bic8.toUpperCase(), b);
});

/**
 * Look up a bank from any BIC (8 or 11 chars).
 * Returns null if not found.
 */
export function lookupBIC(bic: string): BankInfo | null {
  if (!bic || bic.length < 8) return null;
  const normalised = bic.toUpperCase().replace(/\s+/g, '');
  // Try full BIC first
  if (LOOKUP.has(normalised)) return LOOKUP.get(normalised)!;
  // Try 8-char prefix
  const bic8 = normalised.slice(0, 8);
  return LOOKUP.get(bic8) ?? null;
}

/** Get category badge colour */
export function categoryColour(cat: string): string {
  switch (cat) {
    case 'Central Bank': return 'bg-purple-100 text-purple-700 border-purple-200';
    case 'Islamic':      return 'bg-emerald-100 text-emerald-700 border-emerald-200';
    case 'Investment':   return 'bg-blue-100 text-blue-700 border-blue-200';
    case 'Custodian':    return 'bg-amber-100 text-amber-700 border-amber-200';
    case 'Development':  return 'bg-teal-100 text-teal-700 border-teal-200';
    default:             return 'bg-gray-100 text-gray-600 border-gray-200';
  }
}

export { DIRECTORY };
