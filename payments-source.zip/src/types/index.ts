// ─── Standards ────────────────────────────────────────────────────────────────
export type MessageStandard = 'SWIFT_MT' | 'ISO20022';

export type MTMessageType = 'MT199' | 'MT799' | 'MT705' | 'MT760' | 'MT700';

export type ISO20022MessageType =
  // pacs
  | 'pacs.008' | 'pacs.002' | 'pacs.004' | 'pacs.009' | 'pacs.010'
  // camt
  | 'camt.053' | 'camt.054' | 'camt.056' | 'camt.029' | 'camt.052' | 'camt.060'
  // pain
  | 'pain.001' | 'pain.002'
  // PIN
  | 'pin.001' | 'pin.002';

export type AnyMessageType = MTMessageType | ISO20022MessageType;

// ─── SWIFT MT Blocks ──────────────────────────────────────────────────────────
export interface SWIFTBlock1 {
  applicationId: string;
  serviceId: string;
  logicalTerminalAddress: string;
  sessionNumber: string;
  sequenceNumber: string;
}
export interface SWIFTBlock2 {
  ioIndicator: 'I' | 'O';
  messageType: string;
  receiverAddress?: string;
  messagePriority?: string;
  senderInputTime?: string;
  mIRDate?: string;
  mIRLogicalTerminal?: string;
  mIRSessionNumber?: string;
  mIRSequenceNumber?: string;
  receiverOutputDate?: string;
  receiverOutputTime?: string;
}
export interface SWIFTBlock3 {
  uetr?: string;
  messageUserReference?: string;
  bankingPriority?: string;
  serviceIdentifier?: string;
}
export interface SWIFTBlock4Fields { [tag: string]: string; }
export interface SWIFTBlock5 {
  checksum?: string;
  possibleDuplicateEmission?: string;
  messageReference?: string;
  addresseeInformation?: string;
}

// ─── MT700 ────────────────────────────────────────────────────────────────────
export interface MT700Fields {
  tag27?: string; tag40A: string; tag20: string; tag23?: string; tag31C?: string;
  tag31D: string; tag50: string; tag59: string; tag32B: string; tag39A?: string;
  tag39B?: string; tag41A?: string; tag41D?: string; tag42C?: string; tag42A?: string;
  tag42D?: string; tag43P?: string; tag43T?: string; tag44A?: string; tag44E?: string;
  tag44F?: string; tag44B?: string; tag44C?: string; tag44D?: string; tag45A?: string;
  tag46A?: string; tag47A?: string; tag71B?: string; tag48?: string; tag49: string;
  tag53A?: string; tag53D?: string; tag78?: string; tag57A?: string; tag57D?: string;
  tag72?: string;
}
// ─── MT705 ────────────────────────────────────────────────────────────────────
export interface MT705Fields {
  tag27?: string; tag40A: string; tag20: string; tag23?: string; tag31C?: string;
  tag31D: string; tag50: string; tag59: string; tag32B: string; tag39A?: string;
  tag41A?: string; tag41D?: string; tag44C?: string; tag44D?: string; tag44E?: string;
  tag44F?: string; tag45A?: string; tag49: string;
}
// ─── MT760 ────────────────────────────────────────────────────────────────────
export interface MT760Fields {
  tag27?: string; tag20: string; tag23?: string; tag77C: string; tag22D: string;
  tag40C: string; tag31C?: string; tag99A?: string; tag31D?: string; tag35C?: string;
  tag50: string; tag59: string; tag32B: string; tag39A?: string; tag41A?: string;
  tag41D?: string; tag44A?: string; tag45A?: string; tag46A?: string; tag47A?: string;
  tag71B?: string; tag49?: string; tag72?: string; tag57A?: string; tag57D?: string;
}
// ─── MT199 / MT799 ────────────────────────────────────────────────────────────
export interface MT199Fields { tag20: string; tag21?: string; tag79: string; }
export interface MT799Fields { tag20: string; tag21?: string; tag79: string; }

export type MTFields = MT700Fields | MT705Fields | MT760Fields | MT199Fields | MT799Fields;

// ─── ISO 20022 Field Interfaces ───────────────────────────────────────────────

// pacs.008 – FI to FI Customer Credit Transfer
export interface Pacs008Fields {
  msgId: string;
  creDtTm: string;
  nbOfTxs: string;
  sttlmMtd: string;        // INDA | INGA | COVE | CLRG
  sttlmDt: string;
  instrId: string;
  endToEndId: string;
  uetr: string;
  intrBkSttlmAmt: string;
  intrBkSttlmCcy: string;
  chrgBr: string;          // DEBT | CRED | SHAR | SLEV
  instgAgt: string;        // BIC
  instdAgt: string;        // BIC
  dbtrNm: string;
  dbtrAcct: string;
  dbtrAgtBIC: string;
  dbtrAgtNm?: string;      // Auto-filled from BIC directory
  dbtrStrtNm?: string;
  dbtrTwnNm?: string;
  dbtrPstCd?: string;
  dbtrCtry?: string;
  cdtrNm: string;
  cdtrAcct: string;
  cdtrAgtBIC: string;
  cdtrAgtNm?: string;      // Auto-filled from BIC directory
  cdtrAdrLine?: string;
  cdtrTwnNm?: string;
  cdtrCtry?: string;
  instgAgtNm?: string;     // Auto-filled from BIC directory
  instdAgtNm?: string;     // Auto-filled from BIC directory
  rmtInf?: string;
  purp?: string;
  txId?: string;
}

// pacs.002 – FI to FI Payment Status Report
export interface Pacs002Fields {
  msgId: string;
  creDtTm: string;
  orgnlMsgId: string;
  orgnlMsgNmId: string;    // pacs.008.001.08
  orgnlEndToEndId: string;
  orgnlUETR: string;
  txSts: string;           // ACCP | RJCT | PDNG | ACSP | ACSC | ACWC
  rsnCd?: string;          // Reject reason code
  addtlInf?: string;
  instgAgt: string;
  instdAgt: string;
}

// pacs.004 – Payment Return
export interface Pacs004Fields {
  msgId: string;
  creDtTm: string;
  nbOfTxs: string;
  orgnlMsgId: string;
  orgnlMsgNmId: string;
  rtrId: string;
  orgnlEndToEndId: string;
  orgnlUETR: string;
  rtrdIntrBkSttlmAmt: string;
  rtrdIntrBkSttlmCcy: string;
  sttlmDt: string;
  rsnCd: string;           // AC04 | DUPL | FRAD | NARR etc.
  addtlRsnInf?: string;
  instgAgt: string;
  instdAgt: string;
  dbtrNm: string;
  cdtrNm: string;
}

// pacs.009 – Financial Institution Credit Transfer
export interface Pacs009Fields {
  msgId: string;
  creDtTm: string;
  nbOfTxs: string;
  sttlmMtd: string;
  sttlmDt: string;
  instrId: string;
  endToEndId: string;
  uetr: string;
  intrBkSttlmAmt: string;
  intrBkSttlmCcy: string;
  chrgBr: string;
  instgAgt: string;
  instdAgt: string;
  dbtrNm: string;
  cdtrNm: string;
  purp?: string;
  rmtInf?: string;
}

// camt.053 – Bank to Customer Statement
export interface Camt053Fields {
  msgId: string;
  creDtTm: string;
  acctId: string;
  acctCcy: string;
  acctOwnrNm: string;
  svcr: string;             // BIC of account servicer
  stmtId: string;
  elctrncSeqNb: string;
  frDt: string;
  toDt: string;
  openingBal: string;
  openingBalCcy: string;
  closingBal: string;
  closingBalCcy: string;
  ntryAmt: string;
  ntryCcy: string;
  ntryDt: string;
  cdtDbtInd: string;        // CRDT | DBIT
  ntryRef: string;
  endToEndId: string;
  rmtInf?: string;
}

// camt.054 – Bank to Customer Debit/Credit Notification
export interface Camt054Fields {
  msgId: string;
  creDtTm: string;
  acctId: string;
  acctCcy: string;
  acctOwnrNm: string;
  svcr: string;          // Servicer BIC
  ntfctnId: string;      // Notification ID
  ntryAmt: string;
  ntryCcy: string;
  ntryDt: string;        // Booking/value date ISO
  valDt?: string;        // Value date if different from ntryDt
  cdtDbtInd: string;     // CRDT | DBIT
  ntryRef: string;       // Bank transaction reference
  instrId: string;       // Instruction ID
  endToEndId: string;
  txId: string;          // Transaction ID
  uetr: string;
  dbtrNm?: string;       // Debtor name (for credit notification)
  dbtrAcct?: string;     // Debtor IBAN
  dbtrAgtBIC?: string;   // Debtor agent BIC
  cdtrNm?: string;       // Creditor name
  cdtrAcct?: string;     // Creditor IBAN
  cdtrAgtBIC?: string;   // Creditor agent BIC
  rmtInf?: string;       // Remittance information
  purp?: string;         // Purpose code
  bkTxCd?: string;       // Bank transaction code e.g. PMNT
  addtlNtryInf?: string; // Additional entry info
}

// camt.056 – FI to FI Payment Cancellation Request
export interface Camt056Fields {
  msgId: string;
  creDtTm: string;
  orgnlMsgId: string;
  orgnlMsgNmId: string;
  orgnlEndToEndId: string;
  orgnlUETR: string;
  orgnlIntrBkSttlmAmt: string;
  orgnlIntrBkSttlmCcy: string;
  cxlRsnCd: string;         // DUPL | FRAD | TECH | NARR etc.
  addtlCxlRsnInf?: string;
  instgAgt: string;
  instdAgt: string;
}

// camt.029 – Resolution of Investigation
export interface Camt029Fields {
  msgId: string;
  creDtTm: string;
  orgnlMsgId: string;
  orgnlMsgNmId: string;
  orgnlEndToEndId: string;
  orgnlUETR: string;
  sts: string;              // CNCL | RJCR | PDCR
  rsnCd?: string;
  addtlInf?: string;
  instgAgt: string;
  instdAgt: string;
}

// camt.052 – Bank to Customer Account Report
export interface Camt052Fields {
  msgId: string;
  creDtTm: string;
  acctId: string;
  acctCcy: string;
  acctOwnrNm: string;
  svcr: string;
  rptId: string;
  frDt: string;
  toDt: string;
  ntryAmt: string;
  ntryCcy: string;
  ntryDt: string;
  cdtDbtInd: string;
  ntryRef: string;
  endToEndId: string;
}

// camt.060 – Account Reporting Request
export interface Camt060Fields {
  msgId: string;
  creDtTm: string;
  rptgReqId: string;
  acctId: string;
  acctOwnrBIC: string;
  acctSvcrBIC: string;
  frDtTm: string;
  toDtTm: string;
  rptTp: string;            // CAMT052 | CAMT053 | CAMT054
}

// pain.001 – Customer Credit Transfer Initiation
export interface Pain001Fields {
  msgId: string;
  creDtTm: string;
  nbOfTxs: string;
  ctrlSum: string;
  initgPtyNm: string;
  pmtInfId: string;
  pmtMtd: string;           // TRF
  reqdExctnDt: string;
  dbtrNm: string;
  dbtrAcct: string;
  dbtrAgtBIC: string;
  cdtrNm: string;
  cdtrAcct: string;
  cdtrAgtBIC: string;
  instrAmt: string;
  instrCcy: string;
  endToEndId: string;
  purp?: string;
  rmtInf?: string;
}

// pain.002 – Customer Payment Status Report
export interface Pain002Fields {
  msgId: string;
  creDtTm: string;
  orgnlMsgId: string;
  orgnlMsgNmId: string;
  orgnlNbOfTxs: string;
  orgnlCtrlSum: string;
  grpSts: string;           // ACCP | RJCT | PDNG | ACSC
  orgnlEndToEndId: string;
  txSts: string;
  rsnCd?: string;
  addtlStsRsnInf?: string;
  initgPtyNm: string;
}

// pin.001 – Payment Initiation Notification
export interface Pin001Fields {
  msgId: string;
  creDtTm: string;
  instrId: string;
  endToEndId: string;
  uetr: string;
  instgAgt: string;
  instdAgt: string;
  intrBkSttlmAmt: string;
  intrBkSttlmCcy: string;
  sttlmDt: string;
  dbtrNm: string;
  dbtrAcct: string;
  cdtrNm: string;
  cdtrAcct: string;
  ntfctnPurp: string;       // NEWT | CANC | CNCL
  addtlInf?: string;
}

// pin.002 – Payment Initiation Status Notification
export interface Pin002Fields {
  msgId: string;
  creDtTm: string;
  orgnlMsgId: string;
  orgnlInstrId: string;
  orgnlEndToEndId: string;
  orgnlUETR: string;
  ntfctnSts: string;        // RCVD | ACCP | RJCT
  rsnCd?: string;
  addtlInf?: string;
  instgAgt: string;
  instdAgt: string;
}

export type ISO20022Fields =
  | Pacs008Fields | Pacs002Fields | Pacs004Fields | Pacs009Fields
  | Camt053Fields | Camt054Fields | Camt056Fields | Camt029Fields
  | Camt052Fields | Camt060Fields
  | Pain001Fields | Pain002Fields
  | Pin001Fields  | Pin002Fields;

// ─── Unified Message Record ────────────────────────────────────────────────────
export interface GeneratedIdentifiers {
  uetr: string;
  transactionRef: string;
  sessionId: string;
  messageId: string;
  routingId: string;
}

export interface SWIFTMessage {
  id: string;
  standard: MessageStandard;
  messageType: AnyMessageType;
  createdAt: string;
  updatedAt: string;
  senderBIC: string;
  receiverBIC: string;
  // MT only
  block1?: SWIFTBlock1;
  block2?: SWIFTBlock2;
  block3?: SWIFTBlock3;
  block4?: MTFields;
  block5?: SWIFTBlock5;
  // ISO 20022 only
  isoFields?: ISO20022Fields;
  // shared
  identifiers: GeneratedIdentifiers;
  rawMessage: string;
  status: 'draft' | 'final';
  description?: string;
  linkedTo?: string;   // ID of parent message (e.g. pacs.008 that generated this camt.054)
}

export type AppView = 'dashboard' | 'compose' | 'history' | 'viewer';

export interface SearchFilters {
  query: string;
  messageType: AnyMessageType | '';
  bank: string;
  dateFrom: string;
  dateTo: string;
  status: 'draft' | 'final' | '';
  standard: MessageStandard | '';
}
