import { useState, useEffect, useCallback } from 'react';
import {
  LayoutDashboard, PlusCircle, Clock, X, ChevronRight,
  Shield, FileText, LogOut, Globe, Activity
} from 'lucide-react';
import { SWIFTMessage, AppView } from './types';
import { loadMessages, saveMessage } from './utils/storage';
import { getSession, logout, avatarColor, User } from './utils/auth';
import { MessageProfile } from './utils/profiles';
import { Dashboard } from './components/dashboard/Dashboard';
import { ComposeView } from './components/compose/ComposeView';
import { HistoryView } from './components/history/HistoryView';
import { MessageViewer } from './components/viewer/MessageViewer';
import { Modal } from './components/ui/Modal';
import { RegisterPage } from './components/auth/RegisterPage';
import { LoginPage } from './components/auth/LoginPage';
import { UserMenu } from './components/auth/UserMenu';
import { SwiftSidebarLogo, SwiftWordmark } from './components/auth/SwiftLogo';

const SWIFT_BLUE   = '#003366';
const SWIFT_NAVY   = '#001A3A';
const SWIFT_ORANGE = '#F7941D';

const NAV_ITEMS = [
  { id: 'dashboard' as AppView, label: 'Dashboard', icon: LayoutDashboard },
  { id: 'compose'   as AppView, label: 'Compose',   icon: PlusCircle },
  { id: 'history'   as AppView, label: 'History',   icon: Clock },
];

const MT_TYPES = [
  { type: 'MT199', desc: 'Free Format Cat.1',     dot: '#F59E0B' },
  { type: 'MT799', desc: 'Free Format Cat.7',     dot: '#FB923C' },
  { type: 'MT705', desc: 'Pre-Advice of DC',      dot: '#A78BFA' },
  { type: 'MT760', desc: 'Guarantee / SBLC',      dot: '#34D399' },
  { type: 'MT700', desc: 'Documentary Credit',    dot: '#60A5FA' },
];

export default function App() {
  // ── Auth ────────────────────────────────────────────────────────────────────
  const [user,        setUser]        = useState<User | null>(null);
  const [registering, setRegistering] = useState(false);
  const [authReady,   setAuthReady]   = useState(false);

  // ── App ─────────────────────────────────────────────────────────────────────
  const [view,          setView]          = useState<AppView>('dashboard');
  const [messages,      setMessages]      = useState<SWIFTMessage[]>([]);
  const [editMsg,       setEditMsg]       = useState<SWIFTMessage | null>(null);
  const [viewMsg,       setViewMsg]       = useState<SWIFTMessage | null>(null);
  const [activeProfile, setActiveProfile] = useState<MessageProfile | null>(null);
  const [toast,         setToast]         = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [sidebarOpen,   setSidebarOpen]   = useState(false);

  // ── Bootstrap ───────────────────────────────────────────────────────────────
  useEffect(() => {

    const session = getSession();
    if (session) setUser(session);
    setAuthReady(true);
  }, []);

  useEffect(() => {
    if (user) setMessages(loadMessages());
  }, [user]);

  // ── Helpers ─────────────────────────────────────────────────────────────────
  const showToast = useCallback((type: 'success' | 'error', text: string) => {
    setToast({ type, text });
    setTimeout(() => setToast(null), 3500);
  }, []);

  const handleLogin = (u: User) => {
    setUser(u);
    setView('dashboard');
    showToast('success', `Welcome back, ${u.fullName.split(' ')[0]}!`);
  };

  const handleLogout = () => {
    logout();
    setUser(null);
    setMessages([]);
    setEditMsg(null);
    setViewMsg(null);
    setView('dashboard');
  };

  const handleSaved = (msg: SWIFTMessage) => {
    const updated = saveMessage(msg);
    setMessages(updated);
    setEditMsg(null);
    showToast('success', `${msg.messageType} ${msg.status === 'final' ? 'finalised' : 'saved as draft'} — Ref: ${msg.identifiers.transactionRef}`);
    setView('history');
  };

  const handlePreview      = (msg: SWIFTMessage) => setViewMsg(msg);
  const handleEdit         = (msg: SWIFTMessage) => { setEditMsg(msg); setView('compose'); setViewMsg(null); };
  const handleViewMessage  = (msg: SWIFTMessage) => setViewMsg(msg);

  const handleNavigate = (v: AppView) => {
    if (v !== 'compose') setEditMsg(null);
    setView(v);
    setSidebarOpen(false);
  };

  const handleComposeWithProfile = (profile?: MessageProfile) => {
    setEditMsg(null);
    setActiveProfile(profile ?? null);
    setView('compose');
    setSidebarOpen(false);
  };

  // ── Loading ──────────────────────────────────────────────────────────────────
  if (!authReady) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: SWIFT_NAVY }}>
        <div className="flex flex-col items-center gap-6">
          {/* Real SWIFT 2023 logo — large, centred */}
          <SwiftWordmark height={52} />
          <div className="flex items-center gap-2 text-white/40 text-sm">
            <svg className="animate-spin w-4 h-4" viewBox="0 0 24 24" fill="none">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"/>
            </svg>
            Loading SWIFT Platform…
          </div>
        </div>
      </div>
    );
  }

  // ── Auth screens ─────────────────────────────────────────────────────────────
  if (!user) {
    return registering ? <RegisterPage onRegistered={handleLogin} onGoLogin={() => setRegistering(false)} /> : <><button className="fixed bottom-6 right-6 z-50 rounded bg-orange-500 px-5 py-3 text-white" onClick={() => setRegistering(true)}>Create demo account</button><LoginPage onLogin={handleLogin} /></>;
  }

  // ── Main App ─────────────────────────────────────────────────────────────────
  return (
    <div className="min-h-screen flex" style={{ fontFamily: "'Inter','Helvetica Neue',Arial,sans-serif", background: '#0B1525' }}>

      {/* ── Sidebar Overlay (mobile) ─────────────────────────────────────── */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-20 lg:hidden"
          style={{ background: 'rgba(0,10,26,0.75)', backdropFilter: 'blur(4px)' }}
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* ── Sidebar ───────────────────────────────────────────────────────── */}
      <aside
        className={`
          fixed lg:static inset-y-0 left-0 z-30 w-64 flex flex-col
          transition-transform duration-200 border-r
          ${sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
        `}
        style={{ background: SWIFT_BLUE, borderColor: 'rgba(255,255,255,0.08)' }}
      >
        {/* ── Logo ── */}
        <div
          className="flex items-center justify-between px-4 py-4 border-b"
          style={{ borderColor: 'rgba(255,255,255,0.08)', background: 'rgba(0,0,0,0.2)' }}
        >
          <SwiftSidebarLogo />
          <button className="lg:hidden cursor-pointer text-white/30 hover:text-white/70" onClick={() => setSidebarOpen(false)}>
            <X size={15} />
          </button>
        </div>

        {/* ── Navigation ── */}
        <nav className="flex-1 p-3 overflow-y-auto">
          {/* Main nav */}
          <p className="text-[9px] font-black uppercase tracking-widest px-3 py-2 mb-1" style={{ color: 'rgba(255,255,255,0.3)' }}>
            Platform
          </p>
          {NAV_ITEMS.map(item => {
            const Icon = item.icon;
            const active = view === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleNavigate(item.id)}
                className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-semibold mb-0.5 transition-all cursor-pointer"
                style={{
                  background: active ? 'rgba(247,148,29,0.15)' : 'transparent',
                  color: active ? SWIFT_ORANGE : 'rgba(255,255,255,0.6)',
                  border: active ? `1px solid ${SWIFT_ORANGE}30` : '1px solid transparent',
                }}
                onMouseEnter={e => { if (!active) (e.currentTarget as HTMLButtonElement).style.background = 'rgba(255,255,255,0.06)'; }}
                onMouseLeave={e => { if (!active) (e.currentTarget as HTMLButtonElement).style.background = 'transparent'; }}
              >
                <Icon size={16} />
                {item.label}
                {item.id === 'history' && messages.length > 0 && (
                  <span
                    className="ml-auto text-[10px] font-bold px-1.5 py-0.5 rounded-full"
                    style={{ background: 'rgba(247,148,29,0.2)', color: SWIFT_ORANGE }}
                  >
                    {messages.length}
                  </span>
                )}
              </button>
            );
          })}

          {/* Divider */}
          <div className="my-4 border-t" style={{ borderColor: 'rgba(255,255,255,0.08)' }} />

          {/* MT Types */}
          <p className="text-[9px] font-black uppercase tracking-widest px-3 py-2 mb-1" style={{ color: 'rgba(255,255,255,0.3)' }}>
            Supported MT Types
          </p>
          {MT_TYPES.map(mt => (
            <button
              key={mt.type}
              onClick={() => { setEditMsg(null); handleNavigate('compose'); }}
              className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl transition-all cursor-pointer text-left"
              onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.background = 'rgba(255,255,255,0.05)'; }}
              onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.background = 'transparent'; }}
            >
              <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: mt.dot }} />
              <span className="font-black text-xs font-mono" style={{ color: mt.dot }}>{mt.type}</span>
              <span className="text-[10px] truncate" style={{ color: 'rgba(255,255,255,0.35)' }}>{mt.desc}</span>
            </button>
          ))}

          {/* Divider */}
          <div className="my-4 border-t" style={{ borderColor: 'rgba(255,255,255,0.08)' }} />

          {/* Compliance */}
          <div className="px-3 space-y-1.5">
            {[
              { icon: <Shield size={10} />, label: 'SWIFT FIN Compliant' },
              { icon: <FileText size={10} />, label: 'ISO 20022 / MT Ready' },
              { icon: <Globe size={10} />, label: 'swift.com Platform' },
            ].map(c => (
              <div key={c.label} className="flex items-center gap-2 text-[10px]" style={{ color: 'rgba(255,255,255,0.25)' }}>
                <span style={{ color: SWIFT_ORANGE }}>{c.icon}</span>
                {c.label}
              </div>
            ))}
          </div>
        </nav>

        {/* ── User Menu ── */}
        <div className="p-3 border-t" style={{ borderColor: 'rgba(255,255,255,0.08)' }}>
          <UserMenu user={user} onLogout={handleLogout} />
        </div>
      </aside>

      {/* ── Main Content ──────────────────────────────────────────────────── */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">

        {/* ── Top Bar ── */}
        <header
          className="h-14 flex items-center px-4 gap-4 sticky top-0 z-10 border-b"
          style={{ background: 'rgba(11,21,37,0.95)', borderColor: 'rgba(255,255,255,0.07)', backdropFilter: 'blur(12px)' }}
        >
          {/* Mobile menu toggle */}
          <button
            className="lg:hidden cursor-pointer transition-colors"
            style={{ color: 'rgba(255,255,255,0.4)' }}
            onClick={() => setSidebarOpen(true)}
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <line x1="3" y1="6" x2="21" y2="6" />
              <line x1="3" y1="12" x2="21" y2="12" />
              <line x1="3" y1="18" x2="21" y2="18" />
            </svg>
          </button>

          {/* SWIFT brand in header — real 2023 logo */}
          <div className="hidden sm:flex items-center gap-2">
            <SwiftWordmark height={20} />
            <span className="text-xs font-bold hidden sm:inline" style={{ color: SWIFT_ORANGE }}>.com</span>
          </div>

          {/* Breadcrumb */}
          <div className="flex items-center gap-1.5 text-sm">
            <ChevronRight size={13} style={{ color: 'rgba(255,255,255,0.2)' }} />
            <span className="font-semibold text-white/70 capitalize">
              {view === 'compose' && editMsg ? `Edit ${editMsg.messageType}` : view}
            </span>
          </div>

          {/* Right side */}
          <div className="ml-auto flex items-center gap-3">
            {/* Status indicator */}
            <div className="hidden sm:flex items-center gap-2 text-xs" style={{ color: 'rgba(255,255,255,0.35)' }}>
              <Activity size={11} className="text-emerald-400" />
              <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              <span>SWIFT FIN Online</span>
            </div>

            {/* Separator */}
            <div className="hidden lg:block w-px h-5" style={{ background: 'rgba(255,255,255,0.08)' }} />

            {/* User pill — header */}
            <div className="hidden lg:flex items-center gap-2">
              <HeaderAvatar user={user} />
              <div className="hidden xl:block">
                <p className="text-xs font-bold text-white leading-tight">{user.fullName.split(' ')[0]}</p>
                <p className="text-[10px] leading-tight capitalize" style={{ color: SWIFT_ORANGE }}>{user.role}</p>
              </div>
              <button
                onClick={handleLogout}
                title="Sign out of SWIFT"
                className="ml-1 transition-colors cursor-pointer"
                style={{ color: 'rgba(255,255,255,0.25)' }}
                onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.color = '#F87171'; }}
                onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.color = 'rgba(255,255,255,0.25)'; }}
              >
                <LogOut size={14} />
              </button>
            </div>
          </div>
        </header>

        {/* ── Page Content ── */}
        <main className="flex-1 overflow-y-auto p-4 md:p-6">
          <div className="max-w-5xl mx-auto">

            {view === 'dashboard' && (
              <Dashboard
                messages={messages}
                onCompose={handleComposeWithProfile}
                onViewHistory={() => handleNavigate('history')}
                onViewMessage={handleViewMessage}
              />
            )}

            {view === 'compose' && (
              <div
                className="rounded-2xl border p-5 md:p-6"
                style={{ background: '#0F1E33', borderColor: 'rgba(255,255,255,0.07)' }}
              >
                <div className="flex items-center gap-3 mb-6">
                  <div
                    className="w-9 h-9 rounded-xl flex items-center justify-center"
                    style={{ background: 'rgba(247,148,29,0.15)', border: `1px solid ${SWIFT_ORANGE}30` }}
                  >
                    <PlusCircle size={16} style={{ color: SWIFT_ORANGE }} />
                  </div>
                  <div>
                    <h1 className="text-base font-black text-white">
                      {editMsg ? `Edit ${editMsg.messageType}` : 'Compose SWIFT Message'}
                    </h1>
                    <p className="text-xs text-white/40">
                      {editMsg
                        ? `Editing Ref: ${editMsg.identifiers.transactionRef}`
                        : 'Generate a structurally accurate SWIFT MT FIN message'}
                    </p>
                  </div>
                </div>
                <ComposeView
                  editMessage={editMsg}
                  profile={activeProfile}
                  onSaved={handleSaved}
                  onPreview={handlePreview}
                />
              </div>
            )}

            {view === 'history' && (
              <div>
                <div className="flex items-center gap-3 mb-6">
                  <div
                    className="w-9 h-9 rounded-xl flex items-center justify-center"
                    style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)' }}
                  >
                    <Clock size={16} className="text-white/60" />
                  </div>
                  <div>
                    <h1 className="text-base font-black text-white">Message History</h1>
                    <p className="text-xs text-white/40">Search, manage, and export your SWIFT messages</p>
                  </div>
                </div>
                <HistoryView
                  messages={messages}
                  onMessagesChange={setMessages}
                  onEdit={handleEdit}
                />
              </div>
            )}

          </div>
        </main>

        {/* ── Footer bar ── */}
        <div
          className="flex items-center justify-between px-6 py-2 border-t text-[10px]"
          style={{ borderColor: 'rgba(255,255,255,0.06)', color: 'rgba(255,255,255,0.2)' }}
        >
          <span>© 2025 SWIFT SCRL · Avenue Adèle 1 · La Hulpe, Belgium</span>
          <span className="hidden sm:flex items-center gap-1">
            <Globe size={9} />
            swift.com
          </span>
        </div>
      </div>

      {/* ── Message Preview Modal ──────────────────────────────────────────── */}
      <Modal
        open={!!viewMsg}
        onClose={() => setViewMsg(null)}
        size="2xl"
        title={viewMsg ? `${viewMsg.messageType} — Message Viewer` : ''}
        subtitle={viewMsg ? `Ref: ${viewMsg.identifiers.transactionRef}` : ''}
      >
        {viewMsg && (
          <MessageViewer
            message={viewMsg}
            onEdit={() => { handleEdit(viewMsg); setViewMsg(null); }}
            onDelete={() => {
              if (confirm('Delete this message?')) {
                setMessages(msgs => msgs.filter(m => m.id !== viewMsg.id));
                setViewMsg(null);
                showToast('success', 'Message deleted.');
              }
            }}
          />
        )}
      </Modal>

      {/* ── Toast ─────────────────────────────────────────────────────────── */}
      {toast && (
        <div
          className={`fixed bottom-5 right-5 z-50 flex items-start gap-3 px-4 py-3 rounded-xl shadow-2xl border max-w-sm transition-all duration-300`}
          style={{
            background: toast.type === 'success' ? '#0A2E1A' : '#2E0A0A',
            borderColor: toast.type === 'success' ? 'rgba(52,211,153,0.3)' : 'rgba(248,113,113,0.3)',
          }}
        >
          <div
            className="w-4 h-4 rounded-full flex-shrink-0 mt-0.5"
            style={{ background: toast.type === 'success' ? '#34D399' : '#F87171' }}
          />
          <p className="text-xs font-semibold leading-relaxed text-white/80">{toast.text}</p>
          <button
            onClick={() => setToast(null)}
            className="ml-2 text-white/30 hover:text-white/60 cursor-pointer"
          >
            <X size={12} />
          </button>
        </div>
      )}
    </div>
  );
}

// ── Inline header avatar ─────────────────────────────────────────────────────
function HeaderAvatar({ user }: { user: User }) {
  const { bg, text } = avatarColor(user.avatar);
  const ini = user.fullName.split(' ').filter(Boolean).slice(0, 2).map((n: string) => n[0].toUpperCase()).join('');
  return (
    <div className={`w-7 h-7 ${bg} ${text} rounded-lg flex items-center justify-center text-[10px] font-black flex-shrink-0`}>
      {ini}
    </div>
  );
}

