import React from 'react';
import { MTMessageType } from '../../types';
import { cn } from '../../utils/cn';

interface MessageTypeSelectorProps {
  value: MTMessageType | '';
  onChange: (type: MTMessageType) => void;
}

const MESSAGE_TYPES: { type: MTMessageType; title: string; desc: string; color: string }[] = [
  {
    type: 'MT700',
    title: 'MT700',
    desc: 'Issue of a Documentary Credit',
    color: 'blue',
  },
  {
    type: 'MT705',
    title: 'MT705',
    desc: 'Pre-Advice of a Documentary Credit',
    color: 'violet',
  },
  {
    type: 'MT760',
    title: 'MT760',
    desc: 'Guarantee / Standby Letter of Credit',
    color: 'emerald',
  },
  {
    type: 'MT199',
    title: 'MT199',
    desc: 'Free Format Message (Category 1)',
    color: 'amber',
  },
  {
    type: 'MT799',
    title: 'MT799',
    desc: 'Free Format Message (Category 7)',
    color: 'orange',
  },
];

const colorMap: Record<string, string> = {
  blue:    'border-blue-500/40 bg-blue-950/40 hover:border-blue-400 hover:bg-blue-950/60',
  violet:  'border-violet-500/40 bg-violet-950/40 hover:border-violet-400 hover:bg-violet-950/60',
  emerald: 'border-emerald-500/40 bg-emerald-950/40 hover:border-emerald-400 hover:bg-emerald-950/60',
  amber:   'border-amber-500/40 bg-amber-950/40 hover:border-amber-400 hover:bg-amber-950/60',
  orange:  'border-orange-500/40 bg-orange-950/40 hover:border-orange-400 hover:bg-orange-950/60',
};

const selectedColorMap: Record<string, string> = {
  blue:    'border-blue-400 bg-blue-900/60 ring-2 ring-blue-500/30',
  violet:  'border-violet-400 bg-violet-900/60 ring-2 ring-violet-500/30',
  emerald: 'border-emerald-400 bg-emerald-900/60 ring-2 ring-emerald-500/30',
  amber:   'border-amber-400 bg-amber-900/60 ring-2 ring-amber-500/30',
  orange:  'border-orange-400 bg-orange-900/60 ring-2 ring-orange-500/30',
};

const badgeColorMap: Record<string, string> = {
  blue:    'text-blue-300 bg-blue-900/80 border border-blue-700/50',
  violet:  'text-violet-300 bg-violet-900/80 border border-violet-700/50',
  emerald: 'text-emerald-300 bg-emerald-900/80 border border-emerald-700/50',
  amber:   'text-amber-300 bg-amber-900/80 border border-amber-700/50',
  orange:  'text-orange-300 bg-orange-900/80 border border-orange-700/50',
};

export const MessageTypeSelector: React.FC<MessageTypeSelectorProps> = ({ value, onChange }) => (
  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-3">
    {MESSAGE_TYPES.map(mt => (
      <button
        key={mt.type}
        onClick={() => onChange(mt.type)}
        className={cn(
          'flex flex-col items-start gap-2 p-4 rounded-xl border-2 transition-all duration-150 text-left cursor-pointer',
          value === mt.type ? selectedColorMap[mt.color] : colorMap[mt.color]
        )}
      >
        <span className={cn(
          'font-mono font-bold text-sm px-2 py-0.5 rounded',
          badgeColorMap[mt.color]
        )}>
          {mt.title}
        </span>
        <span className="text-xs text-slate-300 leading-snug">{mt.desc}</span>
        {value === mt.type && (
          <span className="text-[10px] font-semibold text-white/70 uppercase tracking-wider mt-auto">
            ✓ Selected
          </span>
        )}
      </button>
    ))}
  </div>
);
