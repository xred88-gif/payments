import React from 'react';
import { MT705Fields } from '../../../types';
import { Input, Textarea, Select } from '../../ui/Input';
import { DatePicker } from '../../ui/DatePicker';
import { CurrencyPicker } from '../../ui/CurrencyPicker';

interface Props {
  fields: Partial<MT705Fields>;
  onChange: (fields: Partial<MT705Fields>) => void;
}

const SectionHeader: React.FC<{ title: string }> = ({ title }) => (
  <div className="flex items-center gap-3 pt-2">
    <span className="text-xs font-bold text-slate-300 uppercase tracking-widest whitespace-nowrap">{title}</span>
    <div className="flex-1 h-px bg-slate-700" />
  </div>
);

const formOfCreditOptions = [
  { value: '', label: 'Select...' },
  { value: 'IRREVOCABLE', label: 'IRREVOCABLE' },
  { value: 'REVOCABLE', label: 'REVOCABLE' },
  { value: 'IRREVOCABLE TRANSFERABLE', label: 'IRREVOCABLE TRANSFERABLE' },
  { value: 'IRREVOCABLE STANDBY', label: 'IRREVOCABLE STANDBY' },
];
const confirmationOptions = [
  { value: '', label: 'Select...' },
  { value: 'CONFIRM', label: 'CONFIRM' },
  { value: 'MAY ADD', label: 'MAY ADD' },
  { value: 'WITHOUT', label: 'WITHOUT' },
];

function extractDate(val: string): string { return (val ?? '').slice(0, 6); }
function extractPlace(val: string): string { return (val ?? '').slice(7); }
function extractCcy(val: string): string { return (val ?? '').slice(0, 3).toUpperCase(); }
function extractAmt(val: string): string { return (val ?? '').slice(3).replace(',', '.'); }
function buildTag32B(ccy: string, amt: string): string {
  const num = parseFloat(amt.replace(',', '.'));
  if (!ccy) return '';
  if (isNaN(num)) return `${ccy}`;
  return `${ccy}${num.toFixed(2).replace('.', ',')}`;
}

export const MT705Form: React.FC<Props> = ({ fields, onChange }) => {
  const set = <K extends keyof MT705Fields>(k: K, v: string) =>
    onChange({ ...fields, [k]: v });
  const setE = <K extends keyof MT705Fields>(k: K) =>
    (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) =>
      set(k, e.target.value);

  const date31D = extractDate(fields.tag31D ?? '');
  const place31D = extractPlace(fields.tag31D ?? '');
  const ccy32B = extractCcy(fields.tag32B ?? '');
  const amt32B = extractAmt(fields.tag32B ?? '');

  return (
    <div className="space-y-6">
      <div className="bg-cyan-950/30 border border-cyan-700/30 rounded-lg px-4 py-3">
        <p className="text-xs text-cyan-300">
          <strong>MT705 – Pre-Advice of a Documentary Credit:</strong> Sent before the full MT700 to
          give advance notice that a documentary credit will be issued. Contains key details only.
        </p>
      </div>

      {/* ── Section A ──────────────────────────────────────────────── */}
      <SectionHeader title="A — Credit Identification" />
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Select label=":40A: Form of Documentary Credit *" options={formOfCreditOptions}
          value={fields.tag40A ?? ''} onChange={setE('tag40A')} />
        <Input label=":20: Documentary Credit Number *" placeholder="e.g. LC2025-001234"
          value={fields.tag20 ?? ''} onChange={setE('tag20')} mono />
        <Input label=":23: Further Identification" placeholder="e.g. PREADV/2025/001"
          value={fields.tag23 ?? ''} onChange={setE('tag23')} mono />
        <Input label=":27: Sequence of Total" placeholder="1/1"
          value={fields.tag27 ?? ''} onChange={setE('tag27')} mono />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <DatePicker
          label=":31C: Date of Issue *"
          value={fields.tag31C ?? ''}
          onChange={v => set('tag31C', v)}
          format="YYMMDD"
          required
        />
        <div className="space-y-1">
          <DatePicker
            label=":31D: Date of Expiry *"
            value={date31D}
            onChange={v => set('tag31D', `${v} ${place31D}`.trim())}
            format="YYMMDD"
            required
          />
          <Input label=":31D: Place of Expiry *" placeholder="NEW YORK, UNITED STATES"
            value={place31D}
            onChange={e => set('tag31D', `${date31D} ${e.target.value}`)} />
        </div>
      </div>

      {/* ── Section B ──────────────────────────────────────────────── */}
      <SectionHeader title="B — Parties" />
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Textarea label=":50: Applicant *" rows={4}
          placeholder="ACME CORPORATION&#10;123 MAIN STREET&#10;NEW YORK, NY 10001&#10;UNITED STATES"
          value={fields.tag50 ?? ''} onChange={setE('tag50')} />
        <Textarea label=":59: Beneficiary *" rows={4}
          placeholder="GLOBAL EXPORTS LIMITED&#10;456 HIGH STREET&#10;LONDON EC1A 1BB&#10;UNITED KINGDOM"
          value={fields.tag59 ?? ''} onChange={setE('tag59')} />
      </div>

      {/* ── Section C ──────────────────────────────────────────────── */}
      <SectionHeader title="C — Amount & Terms" />
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <CurrencyPicker
          label=":32B: Currency *"
          value={ccy32B}
          onChange={v => set('tag32B', buildTag32B(v, amt32B))}
          required
        />
        <div>
          <label className="block text-xs font-medium text-slate-400 mb-1">:32B: Amount *</label>
          <input
            type="text"
            value={amt32B}
            onChange={e => set('tag32B', buildTag32B(ccy32B, e.target.value))}
            placeholder="500000.00"
            className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm font-mono
              text-white placeholder-slate-600 focus:outline-none focus:border-[#F7941D]
              focus:ring-1 focus:ring-[#F7941D]/30 transition-all"
          />
          {fields.tag32B && (
            <p className="text-[10px] font-mono text-emerald-400 mt-1">SWIFT: <span className="text-white">{fields.tag32B}</span></p>
          )}
        </div>
        <Input label=":39A: Tolerance (%)" placeholder="05/05"
          value={fields.tag39A ?? ''} onChange={setE('tag39A')} mono />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Input label=":41A: Available With/By (BIC)" placeholder="CHASUS33XXX BY SIGHT PAYMENT"
          value={fields.tag41A ?? ''} onChange={setE('tag41A')} mono />
        <Select label=":49: Confirmation Instructions" options={confirmationOptions}
          value={fields.tag49 ?? ''} onChange={setE('tag49')} />
      </div>

      {/* ── Section D ──────────────────────────────────────────────── */}
      <SectionHeader title="D — Shipment" />
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Input label=":44E: Port of Loading" placeholder="PORT OF ROTTERDAM, NETHERLANDS"
          value={fields.tag44E ?? ''} onChange={setE('tag44E')} />
        <Input label=":44F: Port of Discharge" placeholder="PORT OF NEW YORK, UNITED STATES"
          value={fields.tag44F ?? ''} onChange={setE('tag44F')} />
        <DatePicker
          label=":44C: Latest Shipment Date"
          value={fields.tag44C ?? ''}
          onChange={v => set('tag44C', v)}
          format="YYMMDD"
        />
        <Input label=":44D: Shipment Period" placeholder="DURING JUNE 2025"
          value={fields.tag44D ?? ''} onChange={setE('tag44D')} />
      </div>

      <Textarea label=":45A: Description of Goods" rows={3}
        placeholder="GENERAL MERCHANDISE AS PER PROFORMA INVOICE&#10;CFR NEW YORK INCOTERMS 2020"
        value={fields.tag45A ?? ''} onChange={setE('tag45A')} />
    </div>
  );
};
