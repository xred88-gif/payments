import React from 'react';
import { MT760Fields } from '../../../types';
import { Input, Textarea, Select } from '../../ui/Input';
import { DatePicker } from '../../ui/DatePicker';
import { CurrencyPicker } from '../../ui/CurrencyPicker';

interface Props {
  fields: Partial<MT760Fields>;
  onChange: (fields: Partial<MT760Fields>) => void;
}

const SectionHeader: React.FC<{ title: string }> = ({ title }) => (
  <div className="flex items-center gap-3 pt-2">
    <span className="text-xs font-bold text-slate-300 uppercase tracking-widest whitespace-nowrap">{title}</span>
    <div className="flex-1 h-px bg-slate-700" />
  </div>
);

const formOfGuaranteeOptions = [
  { value: '', label: 'Select...' },
  { value: 'DGAR', label: 'DGAR – Demand Guarantee' },
  { value: 'STBY', label: 'STBY – Standby Letter of Credit' },
  { value: 'TGAR', label: 'TGAR – Tender Guarantee' },
  { value: 'PGAR', label: 'PGAR – Performance Guarantee' },
  { value: 'AVAL', label: 'AVAL – Aval' },
  { value: 'CGAR', label: 'CGAR – Counter Guarantee' },
  { value: 'LGAR', label: 'LGAR – Loan Guarantee' },
  { value: 'OTHR', label: 'OTHR – Other' },
];
const applicableRulesOptions = [
  { value: '', label: 'Select...' },
  { value: 'URDG', label: 'URDG – ICC Uniform Rules for Demand Guarantees 758' },
  { value: 'ISDGP', label: 'ISDGP – ISP98' },
  { value: 'ISPR', label: 'ISPR – ISP98 (Standby)' },
  { value: 'UCPR', label: 'UCPR – UCP Latest Version' },
  { value: 'OTHR', label: 'OTHR – Other Rules' },
];

function extractDate(val: string): string { return (val ?? '').slice(0, 6); }
function extractPlace(val: string): string { return (val ?? '').slice(7); }
function extractCcy(val: string): string { return (val ?? '').slice(0, 3).toUpperCase(); }
function extractAmt(val: string): string { return (val ?? '').slice(3).replace(',', '.'); }
function buildTag32B(ccy: string, amt: string): string {
  const num = parseFloat(amt.replace(',', '.'));
  if (!ccy) return '';
  if (isNaN(num)) return `${ccy}`;
  return `${ccy}${num.toFixed(2).replace('.', ',')}`;
}

export const MT760Form: React.FC<Props> = ({ fields, onChange }) => {
  const set = <K extends keyof MT760Fields>(k: K, v: string) =>
    onChange({ ...fields, [k]: v });
  const setE = <K extends keyof MT760Fields>(k: K) =>
    (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) =>
      set(k, e.target.value);

  const date31D = extractDate(fields.tag31D ?? '');
  const place31D = extractPlace(fields.tag31D ?? '');
  const ccy32B = extractCcy(fields.tag32B ?? '');
  const amt32B = extractAmt(fields.tag32B ?? '');

  return (
    <div className="space-y-6">
      <div className="bg-emerald-950/30 border border-emerald-700/30 rounded-lg px-4 py-3">
        <p className="text-xs text-emerald-300">
          <strong>MT760 – Guarantee / Standby LC:</strong> Used to issue or request issuance of a
          guarantee or standby letter of credit. Governed by URDG 758 or ISP98.
        </p>
      </div>

      {/* ── Section A ──────────────────────────────────────────────── */}
      <SectionHeader title="A — Guarantee Identification" />
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Input label=":20: Transaction Reference Number *" placeholder="e.g. GUAR2025-001"
          value={fields.tag20 ?? ''} onChange={setE('tag20')} mono />
        <Input label=":23: Further Identification" placeholder="ISSUE"
          value={fields.tag23 ?? ''} onChange={setE('tag23')} mono />
        <Select label=":22D: Form of Guarantee *" options={formOfGuaranteeOptions}
          value={fields.tag22D ?? ''} onChange={setE('tag22D')} />
        <Select label=":40C: Applicable Rules *" options={applicableRulesOptions}
          value={fields.tag40C ?? ''} onChange={setE('tag40C')} />
        <Input label=":27: Sequence of Total" placeholder="1/1"
          value={fields.tag27 ?? ''} onChange={setE('tag27')} mono />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <DatePicker
          label=":31C: Date of Issue *"
          value={fields.tag31C ?? ''}
          onChange={v => set('tag31C', v)}
          format="YYMMDD"
          required
        />
        <div className="space-y-1">
          <DatePicker
            label=":31D: Date of Expiry"
            value={date31D}
            onChange={v => set('tag31D', `${v} ${place31D}`.trim())}
            format="YYMMDD"
          />
          <Input label=":31D: Place of Expiry" placeholder="LONDON, UNITED KINGDOM"
            value={place31D}
            onChange={e => set('tag31D', `${date31D} ${e.target.value}`)} />
        </div>
      </div>

      {/* ── Section B ──────────────────────────────────────────────── */}
      <SectionHeader title="B — Parties" />
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Textarea label=":50: Applicant / Principal *" rows={4}
          placeholder="ACME CORPORATION&#10;123 MAIN STREET&#10;NEW YORK, NY 10001&#10;UNITED STATES"
          value={fields.tag50 ?? ''} onChange={setE('tag50')} />
        <Textarea label=":59: Beneficiary *" rows={4}
          placeholder="MINISTRY OF FINANCE&#10;1 PARLIAMENT SQUARE&#10;LONDON SW1A 2BQ&#10;UNITED KINGDOM"
          value={fields.tag59 ?? ''} onChange={setE('tag59')} />
        <Input label=":57A: Advise Through Bank (BIC)" placeholder="BARCGB22XXX"
          value={fields.tag57A ?? ''} onChange={setE('tag57A')} mono />
        <Input label=":57D: Advise Through Bank (Name)" placeholder="BARCLAYS BANK PLC, LONDON"
          value={fields.tag57D ?? ''} onChange={setE('tag57D')} />
      </div>

      {/* ── Section C ──────────────────────────────────────────────── */}
      <SectionHeader title="C — Amount & Terms" />
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <CurrencyPicker
          label=":32B: Currency *"
          value={ccy32B}
          onChange={v => set('tag32B', buildTag32B(v, amt32B))}
          required
        />
        <div>
          <label className="block text-xs font-medium text-slate-400 mb-1">:32B: Amount *</label>
          <input
            type="text"
            value={amt32B}
            onChange={e => set('tag32B', buildTag32B(ccy32B, e.target.value))}
            placeholder="250000.00"
            className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm font-mono
              text-white placeholder-slate-600 focus:outline-none focus:border-[#F7941D]
              focus:ring-1 focus:ring-[#F7941D]/30 transition-all"
          />
          {fields.tag32B && (
            <p className="text-[10px] font-mono text-emerald-400 mt-1">SWIFT: <span className="text-white">{fields.tag32B}</span></p>
          )}
        </div>
        <Input label=":39A: Tolerance (%)" placeholder="05/05"
          value={fields.tag39A ?? ''} onChange={setE('tag39A')} mono />
      </div>

      {/* ── Section D ──────────────────────────────────────────────── */}
      <SectionHeader title="D — Guarantee Text" />
      <div className="space-y-4">
        <Textarea label=":77C: Details of Guarantee *" rows={10}
          placeholder="WE HEREBY ISSUE THIS DEMAND GUARANTEE IN YOUR FAVOUR&#10;FOR AN AMOUNT NOT EXCEEDING USD 250,000.00&#10;&#10;THIS GUARANTEE IS ISSUED IN ACCORDANCE WITH THE&#10;UNIFORM RULES FOR DEMAND GUARANTEES (URDG) 758&#10;&#10;WE UNDERTAKE TO PAY YOU ANY AMOUNT OR AMOUNTS&#10;NOT EXCEEDING IN TOTAL USD 250,000.00 UPON RECEIPT&#10;OF YOUR FIRST WRITTEN DEMAND"
          value={fields.tag77C ?? ''} onChange={setE('tag77C')} />
        <Input label=":72: Sender to Receiver Information" placeholder="/GUAR/PERFORMANCE GUARANTEE&#10;/REF/CONTRACT NO. CTR-2025-001"
          value={fields.tag72 ?? ''} onChange={setE('tag72')} mono />
      </div>
    </div>
  );
};
