import React from 'react';
import { MT199Fields, MT799Fields, MTMessageType } from '../../../types';
import { Input, Textarea } from '../../ui/Input';

interface Props {
  messageType: MTMessageType;
  fields: Partial<MT199Fields | MT799Fields>;
  onChange: (fields: Partial<MT199Fields | MT799Fields>) => void;
}

export const FreeFormatForm: React.FC<Props> = ({ messageType, fields, onChange }) => {
  const set = <K extends keyof (MT199Fields & MT799Fields)>(k: K) =>
    (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
      onChange({ ...fields, [k]: e.target.value });

  const isMT799 = messageType === 'MT799';

  return (
    <div className="space-y-6">
      <div className={`rounded-lg px-4 py-3 border ${
        isMT799
          ? 'bg-orange-950/30 border-orange-700/30'
          : 'bg-amber-950/30 border-amber-700/30'
      }`}>
        <p className={`text-xs ${isMT799 ? 'text-orange-300' : 'text-amber-300'}`}>
          <strong>{messageType} – Free Format Message:</strong>{' '}
          {isMT799
            ? 'Category 7 – Documentary Credits and Guarantees. Used for free-format communication between banks regarding trade finance operations.'
            : 'Category 1 – Customer Transfers and Cheques. Used for free-format communication between financial institutions for payment-related matters.'}
        </p>
      </div>

      <SectionHeader title="Message Fields" />
      <div className="space-y-4">
        <Input
          label=":20: Transaction Reference Number *"
          placeholder="e.g. TRN20240115001"
          value={(fields as MT199Fields).tag20 ?? ''}
          onChange={set('tag20')}
          mono
          hint="Maximum 16 characters (SWIFT field 20)"
        />
        <Input
          label=":21: Related Reference"
          placeholder="e.g. RLREF20240115"
          value={(fields as MT199Fields).tag21 ?? ''}
          onChange={set('tag21')}
          mono
          hint="Optional: Reference to a related transaction"
        />
        <Textarea
          label=":79: Narrative *"
          placeholder={isMT799
            ? "WE REFER TO LC NO. [LC NUMBER] DATED [DATE] ISSUED BY [ISSUING BANK].\n\nPLEASE ADVISE THE BENEFICIARY THAT WE HAVE RECEIVED DOCUMENTS UNDER THE ABOVE CREDIT.\n\nALL DOCUMENTS ARE IN STRICT COMPLIANCE WITH THE TERMS AND CONDITIONS OF THE CREDIT."
            : "WE ADVISE YOU THAT WE HAVE CREDITED YOUR ACCOUNT WITH USD 100,000.00 (ONE HUNDRED THOUSAND UNITED STATES DOLLARS) ON VALUE DATE [DATE].\n\nTHIS REPRESENTS PAYMENT UNDER CONTRACT NO. [CONTRACT NUMBER].\n\nPLEASE ACKNOWLEDGE RECEIPT."}
          value={(fields as MT199Fields).tag79 ?? ''}
          onChange={set('tag79')}
          rows={12}
          mono
          hint="Free narrative text — maximum 35 characters per line, up to 35 lines"
          className="text-xs leading-relaxed"
        />
      </div>

      <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-4">
        <h4 className="text-xs font-semibold text-slate-300 mb-2 uppercase tracking-wide">Field :79 Guidelines</h4>
        <ul className="space-y-1">
          {[
            'Maximum 35 characters per line',
            'Maximum 35 lines',
            'Use CAPITAL LETTERS for bank names and amounts',
            'Spell out amounts in full where required',
            'Reference related transaction numbers clearly',
            'Include value dates for all financial references',
          ].map((tip, i) => (
            <li key={i} className="text-xs text-slate-500 flex items-start gap-2">
              <span className="text-slate-600 mt-0.5">›</span>
              {tip}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

const SectionHeader: React.FC<{ title: string }> = ({ title }) => (
  <div className="flex items-center gap-3 pt-2">
    <div className="h-px flex-1 bg-slate-700" />
    <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest whitespace-nowrap">{title}</span>
    <div className="h-px flex-1 bg-slate-700" />
  </div>
);
