import React from 'react';
import { MT700Fields } from '../../../types';
import { Input, Textarea, Select } from '../../ui/Input';
import { DatePicker } from '../../ui/DatePicker';
import { CurrencyPicker } from '../../ui/CurrencyPicker';

interface Props {
  fields: Partial<MT700Fields>;
  onChange: (fields: Partial<MT700Fields>) => void;
}

const SectionHeader: React.FC<{ title: string }> = ({ title }) => (
  <div className="flex items-center gap-3 pt-2">
    <span className="text-xs font-bold text-slate-300 uppercase tracking-widest whitespace-nowrap">{title}</span>
    <div className="flex-1 h-px bg-slate-700" />
  </div>
);

const formOfCreditOptions = [
  { value: '', label: 'Select...' },
  { value: 'IRREVOCABLE', label: 'IRREVOCABLE' },
  { value: 'REVOCABLE', label: 'REVOCABLE' },
  { value: 'IRREVOCABLE TRANSFERABLE', label: 'IRREVOCABLE TRANSFERABLE' },
  { value: 'IRREVOCABLE STANDBY', label: 'IRREVOCABLE STANDBY' },
];
const confirmationOptions = [
  { value: '', label: 'Select...' },
  { value: 'CONFIRM', label: 'CONFIRM' },
  { value: 'MAY ADD', label: 'MAY ADD' },
  { value: 'WITHOUT', label: 'WITHOUT' },
];
const partialShipmentOptions = [
  { value: '', label: 'Select...' },
  { value: 'ALLOWED', label: 'ALLOWED' },
  { value: 'NOT ALLOWED', label: 'NOT ALLOWED' },
  { value: 'CONDITIONAL', label: 'CONDITIONAL' },
];
const transshipmentOptions = [
  { value: '', label: 'Select...' },
  { value: 'ALLOWED', label: 'ALLOWED' },
  { value: 'NOT ALLOWED', label: 'NOT ALLOWED' },
  { value: 'CONDITIONAL', label: 'CONDITIONAL' },
];

/** Extract just the YYMMDD part from a field that may have "YYMMDD PLACE" */
function extractDate(val: string): string {
  return (val ?? '').slice(0, 6);
}
/** Extract the place part from ":31D: YYMMDD PLACE" */
function extractPlace(val: string): string {
  return (val ?? '').slice(7);
}

/** Extract currency code from :32B: "USD1000000,00" */
function extractCcy(val: string): string {
  return (val ?? '').slice(0, 3).toUpperCase();
}
/** Extract amount from :32B: "USD1000000,00" */
function extractAmt(val: string): string {
  return (val ?? '').slice(3).replace(',', '.');
}
/** Build :32B: combined "USD1000000,00" */
function buildTag32B(ccy: string, amt: string): string {
  const num = parseFloat(amt.replace(',', '.'));
  if (!ccy) return '';
  if (isNaN(num)) return `${ccy}`;
  return `${ccy}${num.toFixed(2).replace('.', ',')}`;
}

export const MT700Form: React.FC<Props> = ({ fields, onChange }) => {
  const set = <K extends keyof MT700Fields>(k: K, v: string) =>
    onChange({ ...fields, [k]: v });

  const setE = <K extends keyof MT700Fields>(k: K) =>
    (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) =>
      set(k, e.target.value);

  // :31D: compound field
  const date31D = extractDate(fields.tag31D ?? '');
  const place31D = extractPlace(fields.tag31D ?? '');

  // :32B: compound field
  const ccy32B = extractCcy(fields.tag32B ?? '');
  const amt32B = extractAmt(fields.tag32B ?? '');

  return (
    <div className="space-y-6">
      {/* ── Section A: Credit Basics ─────────────────────────────────── */}
      <SectionHeader title="A — Credit Identification" />
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Select label=":40A: Form of Documentary Credit *" options={formOfCreditOptions}
          value={fields.tag40A ?? ''} onChange={setE('tag40A')} />
        <Input label=":20: Documentary Credit Number *" placeholder="e.g. LC2025-001234"
          value={fields.tag20 ?? ''} onChange={setE('tag20')} mono />
        <Input label=":23: Reference to Pre-Advice" placeholder="e.g. PREADV/2025/001"
          value={fields.tag23 ?? ''} onChange={setE('tag23')} mono />
        <Input label=":27: Sequence of Total" placeholder="1/1"
          value={fields.tag27 ?? ''} onChange={setE('tag27')} mono />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <DatePicker
          label=":31C: Date of Issue *"
          value={fields.tag31C ?? ''}
          onChange={v => set('tag31C', v)}
          format="YYMMDD"
          required
        />
        <div className="space-y-1">
          <DatePicker
            label=":31D: Date of Expiry *"
            value={date31D}
            onChange={v => set('tag31D', `${v} ${place31D}`.trim())}
            format="YYMMDD"
            required
          />
          <Input label=":31D: Place of Expiry *" placeholder="LONDON, UNITED KINGDOM"
            value={place31D}
            onChange={e => set('tag31D', `${date31D} ${e.target.value}`)} />
        </div>
      </div>

      {/* ── Section B: Parties ──────────────────────────────────────── */}
      <SectionHeader title="B — Parties" />
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Textarea label=":50: Applicant *" placeholder="ACME CORPORATION&#10;123 MAIN STREET, SUITE 400&#10;NEW YORK, NY 10001&#10;UNITED STATES OF AMERICA"
          value={fields.tag50 ?? ''} onChange={setE('tag50')} rows={4} />
        <Textarea label=":59: Beneficiary *" placeholder="GLOBAL EXPORTS LIMITED&#10;456 HIGH STREET&#10;LONDON EC1A 1BB&#10;UNITED KINGDOM"
          value={fields.tag59 ?? ''} onChange={setE('tag59')} rows={4} />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Input label=":57A: Advise Through Bank (BIC)" placeholder="BARCGB22XXX"
          value={fields.tag57A ?? ''} onChange={setE('tag57A')} mono />
        <Input label=":57D: Advise Through Bank (Name/Addr)" placeholder="BARCLAYS BANK PLC, LONDON"
          value={fields.tag57D ?? ''} onChange={setE('tag57D')} />
        <Input label=":53A: Reimbursing Bank (BIC)" placeholder="CITIUS33XXX"
          value={fields.tag53A ?? ''} onChange={setE('tag53A')} mono />
        <Input label=":53D: Reimbursing Bank (Name/Addr)" placeholder="CITIBANK N.A."
          value={fields.tag53D ?? ''} onChange={setE('tag53D')} />
      </div>

      {/* ── Section C: Amount ───────────────────────────────────────── */}
      <SectionHeader title="C — Amount & Terms" />
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Currency picker */}
        <CurrencyPicker
          label=":32B: Currency *"
          value={ccy32B}
          onChange={v => set('tag32B', buildTag32B(v, amt32B))}
          required
          hint="ISO 4217 currency code"
        />
        {/* Amount input */}
        <div>
          <label className="block text-xs font-medium text-slate-400 mb-1">
            :32B: Amount *
          </label>
          <input
            type="text"
            value={amt32B}
            onChange={e => set('tag32B', buildTag32B(ccy32B, e.target.value))}
            placeholder="1000000.00"
            className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm font-mono
              text-white placeholder-slate-600 focus:outline-none focus:border-[#F7941D]
              focus:ring-1 focus:ring-[#F7941D]/30 transition-all"
          />
          {fields.tag32B && (
            <p className="text-[10px] font-mono text-emerald-400 mt-1">SWIFT: <span className="text-white">{fields.tag32B}</span></p>
          )}
        </div>
        <Input label=":39A: Tolerance (%)" placeholder="05/05"
          value={fields.tag39A ?? ''} onChange={setE('tag39A')} mono hint="+/- tolerance on amount" />
      </div>

      {/* ── Section D: Credit Terms ─────────────────────────────────── */}
      <SectionHeader title="D — Credit Terms" />
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Input label=":41A: Available With/By (BIC)" placeholder="BARCGB22XXX BY NEGOTIATION"
          value={fields.tag41A ?? ''} onChange={setE('tag41A')} mono />
        <Input label=":42C: Drafts At" placeholder="90 DAYS FROM BILL OF LADING DATE"
          value={fields.tag42C ?? ''} onChange={setE('tag42C')} mono />
        <Input label=":42A: Drawee (BIC)" placeholder="BARCGB22XXX"
          value={fields.tag42A ?? ''} onChange={setE('tag42A')} mono />
        <Select label=":43P: Partial Shipments" options={partialShipmentOptions}
          value={fields.tag43P ?? ''} onChange={setE('tag43P')} />
        <Select label=":43T: Transshipment" options={transshipmentOptions}
          value={fields.tag43T ?? ''} onChange={setE('tag43T')} />
        <Select label=":49: Confirmation Instructions" options={confirmationOptions}
          value={fields.tag49 ?? ''} onChange={setE('tag49')} />
      </div>

      {/* ── Section E: Shipment ─────────────────────────────────────── */}
      <SectionHeader title="E — Shipment Details" />
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Input label=":44E: Port of Loading / Airport of Departure" placeholder="PORT OF SHANGHAI, CHINA"
          value={fields.tag44E ?? ''} onChange={setE('tag44E')} />
        <Input label=":44F: Port of Discharge / Airport of Destination" placeholder="PORT OF FELIXSTOWE, UNITED KINGDOM"
          value={fields.tag44F ?? ''} onChange={setE('tag44F')} />
        <Input label=":44B: Place of Final Destination" placeholder="LONDON, UNITED KINGDOM"
          value={fields.tag44B ?? ''} onChange={setE('tag44B')} />
        <DatePicker
          label=":44C: Latest Shipment Date"
          value={fields.tag44C ?? ''}
          onChange={v => set('tag44C', v)}
          format="YYMMDD"
          hint="Last date for shipment"
        />
        <div className="md:col-span-2">
          <Input label=":44A: Shipment Period (if :44C not used)" placeholder="SHIPMENT DURING JUNE 2025"
            value={fields.tag44A ?? ''} onChange={setE('tag44A')} />
        </div>
      </div>

      {/* ── Section F: Documents ────────────────────────────────────── */}
      <SectionHeader title="F — Documents & Conditions" />
      <div className="space-y-4">
        <Textarea label=":45A: Description of Goods and/or Services" rows={4}
          placeholder="ELECTRICAL MACHINERY AND EQUIPMENT&#10;HS CODE: 8501.10&#10;1,000 UNITS @ USD 1,000.00 PER UNIT&#10;CIF FELIXSTOWE INCOTERMS 2020"
          value={fields.tag45A ?? ''} onChange={setE('tag45A')} />
        <Textarea label=":46A: Documents Required" rows={5}
          placeholder="+FULL SET OF CLEAN ON BOARD BILLS OF LADING&#10;+COMMERCIAL INVOICE IN TRIPLICATE&#10;+PACKING LIST IN DUPLICATE&#10;+CERTIFICATE OF ORIGIN"
          value={fields.tag46A ?? ''} onChange={setE('tag46A')} />
        <Textarea label=":47A: Additional Conditions" rows={3}
          placeholder="DOCUMENTS MUST BE PRESENTED WITHIN 21 DAYS&#10;AFTER DATE OF SHIPMENT"
          value={fields.tag47A ?? ''} onChange={setE('tag47A')} />
        <Textarea label=":78: Instructions to the Paying/Accepting/Negotiating Bank" rows={3}
          placeholder="ALL DOCUMENTS MUST BE FORWARDED IN ONE LOT BY COURIER"
          value={fields.tag78 ?? ''} onChange={setE('tag78')} />
        <Input label=":72: Sender to Receiver Information" placeholder="/BNF/PAYMENT SUBJECT TO UCP 600"
          value={fields.tag72 ?? ''} onChange={setE('tag72')} mono />
      </div>
    </div>
  );
};
