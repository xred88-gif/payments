import React from 'react';
import { RefreshCw, Copy, Check } from 'lucide-react';
import { GeneratedIdentifiers } from '../../types';
import { generateAllIdentifiers } from '../../utils/identifiers';

interface IdentifiersPanelProps {
  identifiers: GeneratedIdentifiers;
  onChange: (ids: GeneratedIdentifiers) => void;
}

const idFields: { key: keyof GeneratedIdentifiers; label: string; desc: string }[] = [
  { key: 'uetr',           label: 'UETR',                    desc: 'Unique End-to-End Transaction Reference (RFC 4122 UUID v4)' },
  { key: 'transactionRef', label: 'Transaction Reference',   desc: 'SWIFT Field :20: Transaction Reference Number' },
  { key: 'sessionId',      label: 'Session Identifier',      desc: 'SWIFT Block 1 session and sequence composite' },
  { key: 'messageId',      label: 'Message ID',              desc: 'Internal message routing identifier' },
  { key: 'routingId',      label: 'Routing ID',              desc: 'Internal routing and audit trail identifier' },
];

export const IdentifiersPanel: React.FC<IdentifiersPanelProps> = ({ identifiers, onChange }) => {
  const [copied, setCopied] = React.useState<string | null>(null);

  const regenerate = () => onChange(generateAllIdentifiers());

  const copyField = async (val: string, key: string) => {
    await navigator.clipboard.writeText(val);
    setCopied(key);
    setTimeout(() => setCopied(null), 1500);
  };

  return (
    <div className="bg-slate-800/50 border border-slate-700 rounded-xl overflow-hidden">
      <div className="flex items-center justify-between px-4 py-3 border-b border-slate-700 bg-slate-800/80">
        <div>
          <h3 className="text-sm font-semibold text-white">Auto-Generated Identifiers</h3>
          <p className="text-xs text-slate-500 mt-0.5">Automatically generated per SWIFT standards</p>
        </div>
        <button
          onClick={regenerate}
          className="flex items-center gap-1.5 text-xs text-blue-400 hover:text-blue-300 transition-colors cursor-pointer"
        >
          <RefreshCw size={13} />
          Regenerate All
        </button>
      </div>

      <div className="divide-y divide-slate-700/50">
        {idFields.map(({ key, label, desc }) => (
          <div key={key} className="flex items-start gap-3 px-4 py-3 group hover:bg-slate-800/40 transition-colors">
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <span className="text-xs font-medium text-slate-400 uppercase tracking-wide">{label}</span>
              </div>
              <code className="text-xs font-mono text-emerald-400 break-all">{identifiers[key]}</code>
              <p className="text-[10px] text-slate-600 mt-0.5">{desc}</p>
            </div>
            <button
              onClick={() => copyField(identifiers[key], key)}
              className="opacity-0 group-hover:opacity-100 transition-opacity text-slate-500 hover:text-slate-300 flex-shrink-0 mt-1 cursor-pointer"
            >
              {copied === key ? <Check size={13} className="text-emerald-400" /> : <Copy size={13} />}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};
