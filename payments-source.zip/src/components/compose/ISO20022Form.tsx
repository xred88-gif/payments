/**
 * ISO 20022 Form — all 10 message types
 * pacs.008 · pacs.009 · pacs.004 · pacs.002
 * camt.056 · camt.029 · camt.053 · camt.054
 * pain.001 · pain.002
 *
 * Features:
 * • IBANField — auto-strips spaces, mod-97 validation, copy button
 * • DateTimePicker — calendar date picker + HH:MM:SS time wheel
 * • TimePicker — standalone time selector
 * • BICField — with timezone display
 * • CurrencyPicker — ISO 4217 searchable list
 */

import React from 'react';
import { ISO20022MessageType } from '../../types';
import { DateTimePicker }  from '../ui/DateTimePicker';
import { CurrencyPicker }  from '../ui/CurrencyPicker';
import { IBANField }       from '../ui/IBANField';
import { BICField }        from '../ui/BICField';

interface Props {
  msgType: ISO20022MessageType;
  fields: Record<string, string>;
  onChange: (fields: Record<string, string>) => void;
}

// ─── shared style tokens ─────────────────────────────────────────────────────
const inputCls =
  'w-full bg-white border border-gray-300 rounded px-3 py-2 text-sm font-mono ' +
  'text-gray-900 focus:outline-none focus:border-orange-500 focus:ring-1 focus:ring-orange-400';
const labelCls = 'block text-xs font-semibold text-gray-600 mb-1 uppercase tracking-wide';
const sectionCls = 'bg-gray-50 border border-gray-200 rounded-lg p-4 space-y-4';
const sectionTitle = 'text-xs font-bold text-gray-500 uppercase tracking-widest mb-3';

// ─── Primitive field ─────────────────────────────────────────────────────────
function Field({ label, name, fields, onChange, rows = 0, hint = '', required = false }: {
  label: string; name: string; fields: Record<string,string>;
  onChange: (f: Record<string,string>) => void;
  rows?: number; hint?: string; required?: boolean;
}) {
  const base = 'w-full bg-white border border-gray-300 rounded px-3 py-2 text-sm font-mono ' +
    'text-gray-900 focus:outline-none focus:border-orange-500 focus:ring-1 focus:ring-orange-400';
  return (
    <div>
      <label className={labelCls}>
        {label}{required && <span className="text-orange-500 ml-0.5">*</span>}
      </label>
      {rows > 1
        ? <textarea className={base} rows={rows}
            value={fields[name] ?? ''}
            onChange={e => onChange({ ...fields, [name]: e.target.value })} />
        : <input className={base}
            value={fields[name] ?? ''}
            onChange={e => onChange({ ...fields, [name]: e.target.value })} />
      }
      {hint && <p className="text-xs text-gray-400 mt-1">{hint}</p>}
    </div>
  );
}

// ─── Select field ────────────────────────────────────────────────────────────
function SelectField({ label, name, fields, onChange, options }: {
  label: string; name: string; fields: Record<string,string>;
  onChange: (f: Record<string,string>) => void;
  options: { value: string; label: string }[];
}) {
  return (
    <div>
      <label className={labelCls}>{label}</label>
      <select className={inputCls} value={fields[name] ?? ''}
        onChange={e => onChange({ ...fields, [name]: e.target.value })}>
        {options.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
      </select>
    </div>
  );
}

// ─── DateTime field (date calendar + time wheel) ──────────────────────────────
function DTField({ label, name, fields, onChange, dateOnly = false, required = false }: {
  label: string; name: string; fields: Record<string,string>;
  onChange: (f: Record<string,string>) => void;
  dateOnly?: boolean; required?: boolean;
}) {
  return (
    <DateTimePicker
      label={label}
      name={name}
      fields={fields}
      onChange={onChange}
      dateOnly={dateOnly}
      required={required}
    />
  );
}

// ─── Currency + amount row ────────────────────────────────────────────────────
function CcyAmtRow({ ccyName, amtName, label, fields, onChange }: {
  ccyName: string; amtName: string; label: string;
  fields: Record<string,string>; onChange: (f: Record<string,string>) => void;
}) {
  return (
    <div>
      <label className={labelCls}>{label}</label>
      <div className="flex gap-2">
        <div className="w-44">
          <CurrencyPicker
            value={fields[ccyName] ?? 'USD'}
            onChange={v => onChange({ ...fields, [ccyName]: v })}
          />
        </div>
        <input
          className={inputCls + ' flex-1'}
          placeholder="0.00"
          value={fields[amtName] ?? ''}
          onChange={e => onChange({ ...fields, [amtName]: e.target.value })}
        />
      </div>
    </div>
  );
}

// BICField is imported from ../ui/BICField — validated ISO 9362 component

// ─── Grid helpers ─────────────────────────────────────────────────────────────
const Row2 = ({ children }: { children: React.ReactNode }) => (
  <div className="grid grid-cols-2 gap-4">{children}</div>
);
const Row3 = ({ children }: { children: React.ReactNode }) => (
  <div className="grid grid-cols-3 gap-4">{children}</div>
);

// ─── Section wrapper ──────────────────────────────────────────────────────────
function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className={sectionCls}>
      <p className={sectionTitle}>{title}</p>
      <div className="space-y-4">{children}</div>
    </div>
  );
}

// ════════════════════════════════════════════════════════════════════════════════
// pacs.008 — FI to FI Customer Credit Transfer
// ════════════════════════════════════════════════════════════════════════════════
function Pacs008Form({ fields, onChange }: { fields: Record<string,string>; onChange: (f: Record<string,string>) => void }) {
  return (
    <div className="space-y-4">
      <Section title="Group Header">
        <Row2>
          <Field label="Message ID" name="msgId" fields={fields} onChange={onChange} required />
          <DTField label="Creation Date / Time" name="creDtTm" fields={fields} onChange={onChange} required />
        </Row2>
        <Row3>
          <Field label="Number of Transactions" name="nbOfTxs" fields={fields} onChange={onChange} hint="Usually 1" />
          <SelectField label="Settlement Method" name="sttlmMtd" fields={fields} onChange={onChange}
            options={[{value:'INDA',label:'INDA – Instructed Agent'},{value:'INGA',label:'INGA – Instructing Agent'},{value:'COVE',label:'COVE – Cover'},{value:'CLRG',label:'CLRG – Clearing'}]} />
          <DTField label="Settlement Date" name="sttlmDt" fields={fields} onChange={onChange} dateOnly required />
        </Row3>
      </Section>

      <Section title="Agents">
        <Row2>
          <BICField label="Instructing Agent BIC" name="instgAgt" fields={fields} onChange={onChange} required />
          <BICField label="Instructed Agent BIC" name="instdAgt" fields={fields} onChange={onChange} required />
        </Row2>
      </Section>

      <Section title="Transaction IDs">
        <Row2>
          <Field label="Instruction ID" name="instrId" fields={fields} onChange={onChange} required />
          <Field label="End-to-End ID" name="endToEndId" fields={fields} onChange={onChange} required />
        </Row2>
        <Row2>
          <Field label="Transaction ID" name="txId" fields={fields} onChange={onChange} />
          <Field label="UETR" name="uetr" fields={fields} onChange={onChange} hint="UUID v4 format" required />
        </Row2>
      </Section>

      <Section title="Settlement Amount">
        <Row2>
          <CcyAmtRow ccyName="intrBkSttlmCcy" amtName="intrBkSttlmAmt" label="Interbank Settlement Amount *" fields={fields} onChange={onChange} />
          <SelectField label="Charge Bearer" name="chrgBr" fields={fields} onChange={onChange}
            options={[{value:'DEBT',label:'DEBT – Debtor'},{value:'CRED',label:'CRED – Creditor'},{value:'SHAR',label:'SHAR – Shared'},{value:'SLEV',label:'SLEV – Service Level'}]} />
        </Row2>
      </Section>

      <Section title="Debtor">
        <Row2>
          <Field label="Debtor Name" name="dbtrNm" fields={fields} onChange={onChange} required />
          <Field label="Debtor Street" name="dbtrStrtNm" fields={fields} onChange={onChange} hint="Street address" />
        </Row2>
        <Row3>
          <Field label="Debtor Town" name="dbtrTwnNm" fields={fields} onChange={onChange} />
          <Field label="Postal Code" name="dbtrPstCd" fields={fields} onChange={onChange} />
          <Field label="Country (2-letter)" name="dbtrCtry" fields={fields} onChange={onChange} hint="e.g. US" />
        </Row3>
        <Row2>
          <IBANField label="Debtor Account" name="dbtrAcct" fields={fields} onChange={onChange}
            hint="IBAN or account number — spaces stripped automatically" />
          <BICField label="Debtor Agent BIC *" name="dbtrAgtBIC" fields={fields} onChange={onChange}
            required
            onResolvedName={name => onChange({ ...fields, dbtrAgtBIC: fields.dbtrAgtBIC ?? '', dbtrAgtNm: name })} />
        </Row2>
        <Field label="Debtor Agent Name" name="dbtrAgtNm" fields={fields} onChange={onChange}
          hint="Auto-filled from BIC directory when BIC is recognised" />
      </Section>

      <Section title="Creditor">
        <Row2>
          <Field label="Creditor Name" name="cdtrNm" fields={fields} onChange={onChange} required />
          <Field label="Creditor Address Line" name="cdtrAdrLine" fields={fields} onChange={onChange} />
        </Row2>
        <Row3>
          <Field label="Creditor Town" name="cdtrTwnNm" fields={fields} onChange={onChange} />
          <Field label="Country (2-letter)" name="cdtrCtry" fields={fields} onChange={onChange} hint="e.g. GB" />
          <BICField label="Creditor Agent BIC *" name="cdtrAgtBIC" fields={fields} onChange={onChange}
            required
            onResolvedName={name => onChange({ ...fields, cdtrAgtBIC: fields.cdtrAgtBIC ?? '', cdtrAgtNm: name })} />
        </Row3>
        <Row2>
          <IBANField label="Creditor Account (IBAN)" name="cdtrAcct" fields={fields} onChange={onChange} required
            hint="Spaces stripped automatically, IBAN validated" />
          <Field label="Creditor Agent Name" name="cdtrAgtNm" fields={fields} onChange={onChange}
            hint="Auto-filled from BIC directory when BIC is recognised" />
        </Row2>
      </Section>

      <Section title="Additional">
        <Row2>
          <Field label="Purpose Code" name="purp" fields={fields} onChange={onChange} hint="e.g. SUPP, INTC, SALA" />
          <Field label="Remittance Information" name="rmtInf" fields={fields} onChange={onChange} rows={2} />
        </Row2>
      </Section>
    </div>
  );
}

// ════════════════════════════════════════════════════════════════════════════════
// pacs.009 — Financial Institution Credit Transfer
// ════════════════════════════════════════════════════════════════════════════════
function Pacs009Form({ fields, onChange }: { fields: Record<string,string>; onChange: (f: Record<string,string>) => void }) {
  return (
    <div className="space-y-4">
      <Section title="Group Header">
        <Row2>
          <Field label="Message ID" name="msgId" fields={fields} onChange={onChange} required />
          <DTField label="Creation Date / Time" name="creDtTm" fields={fields} onChange={onChange} required />
        </Row2>
        <Row3>
          <Field label="Number of Transactions" name="nbOfTxs" fields={fields} onChange={onChange} />
          <SelectField label="Settlement Method" name="sttlmMtd" fields={fields} onChange={onChange}
            options={[{value:'INDA',label:'INDA'},{value:'INGA',label:'INGA'},{value:'COVE',label:'COVE'},{value:'CLRG',label:'CLRG'}]} />
          <DTField label="Settlement Date" name="sttlmDt" fields={fields} onChange={onChange} dateOnly required />
        </Row3>
      </Section>

      <Section title="Agents">
        <Row2>
          <BICField label="Instructing Agent BIC" name="instgAgt" fields={fields} onChange={onChange} required />
          <BICField label="Instructed Agent BIC" name="instdAgt" fields={fields} onChange={onChange} required />
        </Row2>
      </Section>

      <Section title="Transaction IDs">
        <Row2>
          <Field label="Instruction ID" name="instrId" fields={fields} onChange={onChange} required />
          <Field label="End-to-End ID" name="endToEndId" fields={fields} onChange={onChange} required />
        </Row2>
        <Field label="UETR" name="uetr" fields={fields} onChange={onChange} hint="UUID v4" required />
      </Section>

      <Section title="Settlement Amount">
        <Row2>
          <CcyAmtRow ccyName="intrBkSttlmCcy" amtName="intrBkSttlmAmt" label="Interbank Settlement Amount *" fields={fields} onChange={onChange} />
          <SelectField label="Charge Bearer" name="chrgBr" fields={fields} onChange={onChange}
            options={[{value:'DEBT',label:'DEBT'},{value:'CRED',label:'CRED'},{value:'SHAR',label:'SHAR'},{value:'SLEV',label:'SLEV'}]} />
        </Row2>
      </Section>

      <Section title="Debtor Financial Institution">
        <Row2>
          <BICField label="Debtor FI BIC" name="dbtrBIC" fields={fields} onChange={onChange}
            onResolvedName={n => onChange({ ...fields, dbtrBIC: fields.dbtrBIC ?? '', dbtrNm: n })} />
          <Field label="Debtor FI Name" name="dbtrNm" fields={fields} onChange={onChange} required
            hint="Auto-filled from BIC directory" />
        </Row2>
        <IBANField label="Debtor Account (IBAN)" name="dbtrAcct" fields={fields} onChange={onChange}
          hint="Spaces are stripped automatically" />
      </Section>

      <Section title="Creditor Financial Institution">
        <Row2>
          <BICField label="Creditor FI BIC" name="cdtrBIC" fields={fields} onChange={onChange}
            onResolvedName={n => onChange({ ...fields, cdtrBIC: fields.cdtrBIC ?? '', cdtrNm: n })} />
          <Field label="Creditor FI Name" name="cdtrNm" fields={fields} onChange={onChange} required
            hint="Auto-filled from BIC directory" />
        </Row2>
        <IBANField label="Creditor Account (IBAN)" name="cdtrAcct" fields={fields} onChange={onChange}
          hint="Spaces are stripped automatically" />
        <Row2>
          <Field label="Purpose Code" name="purp" fields={fields} onChange={onChange} hint="e.g. INTC, CORT" />
          <Field label="Remittance Info" name="rmtInf" fields={fields} onChange={onChange} />
        </Row2>
      </Section>
    </div>
  );
}

// ════════════════════════════════════════════════════════════════════════════════
// pacs.004 — Payment Return
// ════════════════════════════════════════════════════════════════════════════════
function Pacs004Form({ fields, onChange }: { fields: Record<string,string>; onChange: (f: Record<string,string>) => void }) {
  return (
    <div className="space-y-4">
      <Section title="Group Header">
        <Row2>
          <Field label="Message ID" name="msgId" fields={fields} onChange={onChange} required />
          <DTField label="Creation Date / Time" name="creDtTm" fields={fields} onChange={onChange} required />
        </Row2>
        <Row2>
          <Field label="Number of Transactions" name="nbOfTxs" fields={fields} onChange={onChange} />
          <DTField label="Settlement Date" name="sttlmDt" fields={fields} onChange={onChange} dateOnly required />
        </Row2>
      </Section>

      <Section title="Agents">
        <Row2>
          <BICField label="Instructing Agent BIC" name="instgAgt" fields={fields} onChange={onChange} required />
          <BICField label="Instructed Agent BIC" name="instdAgt" fields={fields} onChange={onChange} required />
        </Row2>
      </Section>

      <Section title="Original Message Reference">
        <Row2>
          <Field label="Original Message ID" name="orgnlMsgId" fields={fields} onChange={onChange} required />
          <Field label="Original Message Name ID" name="orgnlMsgNmId" fields={fields} onChange={onChange} hint="e.g. pacs.008.001.02" />
        </Row2>
        <Row2>
          <Field label="Return ID" name="rtrId" fields={fields} onChange={onChange} required />
          <Field label="Original End-to-End ID" name="orgnlEndToEndId" fields={fields} onChange={onChange} required />
        </Row2>
        <Field label="Original UETR" name="orgnlUETR" fields={fields} onChange={onChange} hint="UUID v4 of original message" required />
      </Section>

      <Section title="Return Amount">
        <CcyAmtRow ccyName="rtrdIntrBkSttlmCcy" amtName="rtrdIntrBkSttlmAmt" label="Returned Interbank Settlement Amount *" fields={fields} onChange={onChange} />
      </Section>

      <Section title="Return Reason">
        <Row2>
          <SelectField label="Return Reason Code" name="rsnCd" fields={fields} onChange={onChange}
            options={[
              {value:'AC04',label:'AC04 – Closed Account'},{value:'DUPL',label:'DUPL – Duplicate'},
              {value:'FRAD',label:'FRAD – Fraudulent'},{value:'NARR',label:'NARR – Narrative'},
              {value:'NOAS',label:'NOAS – No Answer'},{value:'AGNT',label:'AGNT – Agent Decision'},
              {value:'CUST',label:'CUST – Customer Decision'},{value:'UPAY',label:'UPAY – Undue Payment'},
            ]} />
          <Field label="Additional Return Reason" name="addtlRsnInf" fields={fields} onChange={onChange} rows={2} />
        </Row2>
      </Section>

      <Section title="Original Parties">
        <Row2>
          <Field label="Original Debtor Name" name="dbtrNm" fields={fields} onChange={onChange} />
          <Field label="Original Creditor Name" name="cdtrNm" fields={fields} onChange={onChange} />
        </Row2>
        <Row2>
          <IBANField label="Original Debtor IBAN" name="dbtrAcct" fields={fields} onChange={onChange} />
          <IBANField label="Original Creditor IBAN" name="cdtrAcct" fields={fields} onChange={onChange} />
        </Row2>
      </Section>
    </div>
  );
}

// ════════════════════════════════════════════════════════════════════════════════
// pacs.002 — FI to FI Payment Status Report
// ════════════════════════════════════════════════════════════════════════════════
function Pacs002Form({ fields, onChange }: { fields: Record<string,string>; onChange: (f: Record<string,string>) => void }) {
  return (
    <div className="space-y-4">
      <Section title="Group Header">
        <Row2>
          <Field label="Message ID" name="msgId" fields={fields} onChange={onChange} required />
          <DTField label="Creation Date / Time" name="creDtTm" fields={fields} onChange={onChange} required />
        </Row2>
        <Row2>
          <BICField label="Instructing Agent BIC" name="instgAgt" fields={fields} onChange={onChange} required />
          <BICField label="Instructed Agent BIC" name="instdAgt" fields={fields} onChange={onChange} required />
        </Row2>
      </Section>

      <Section title="Original Message Reference">
        <Row2>
          <Field label="Original Message ID" name="orgnlMsgId" fields={fields} onChange={onChange} required />
          <Field label="Original Message Name ID" name="orgnlMsgNmId" fields={fields} onChange={onChange} hint="e.g. pacs.008.001.02" />
        </Row2>
        <Row2>
          <Field label="Original End-to-End ID" name="orgnlEndToEndId" fields={fields} onChange={onChange} required />
          <Field label="Original UETR" name="orgnlUETR" fields={fields} onChange={onChange} required />
        </Row2>
      </Section>

      <Section title="Transaction Status">
        <Row2>
          <SelectField label="Transaction Status" name="txSts" fields={fields} onChange={onChange}
            options={[
              {value:'ACCP',label:'ACCP – Accepted'},{value:'ACSC',label:'ACSC – Settlement Completed'},
              {value:'ACSP',label:'ACSP – Settlement in Process'},{value:'ACWC',label:'ACWC – Accepted With Change'},
              {value:'PDNG',label:'PDNG – Pending'},{value:'RJCT',label:'RJCT – Rejected'},
            ]} />
          <Field label="Reason Code" name="rsnCd" fields={fields} onChange={onChange} hint="e.g. AC01, NARR (optional)" />
        </Row2>
        <Field label="Additional Information" name="addtlInf" fields={fields} onChange={onChange} rows={2} />
      </Section>
    </div>
  );
}

// ════════════════════════════════════════════════════════════════════════════════
// camt.056 — FI to FI Payment Cancellation Request
// ════════════════════════════════════════════════════════════════════════════════
function Camt056Form({ fields, onChange }: { fields: Record<string,string>; onChange: (f: Record<string,string>) => void }) {
  return (
    <div className="space-y-4">
      <Section title="Assignment">
        <Row2>
          <Field label="Message ID" name="msgId" fields={fields} onChange={onChange} required />
          <DTField label="Creation Date / Time" name="creDtTm" fields={fields} onChange={onChange} required />
        </Row2>
        <Row2>
          <BICField label="Assigning Agent (Instructing) BIC" name="instgAgt" fields={fields} onChange={onChange} required />
          <BICField label="Assigned Agent (Instructed) BIC" name="instdAgt" fields={fields} onChange={onChange} required />
        </Row2>
      </Section>

      <Section title="Original Message Reference">
        <Row2>
          <Field label="Original Message ID" name="orgnlMsgId" fields={fields} onChange={onChange} required />
          <Field label="Original Message Name ID" name="orgnlMsgNmId" fields={fields} onChange={onChange} hint="e.g. pacs.008.001.02" />
        </Row2>
        <Row2>
          <Field label="Original End-to-End ID" name="orgnlEndToEndId" fields={fields} onChange={onChange} required />
          <Field label="Original UETR" name="orgnlUETR" fields={fields} onChange={onChange} required />
        </Row2>
      </Section>

      <Section title="Original Amount">
        <CcyAmtRow ccyName="orgnlIntrBkSttlmCcy" amtName="orgnlIntrBkSttlmAmt" label="Original Interbank Settlement Amount *" fields={fields} onChange={onChange} />
      </Section>

      <Section title="Cancellation Reason">
        <Row2>
          <SelectField label="Cancellation Reason Code" name="cxlRsnCd" fields={fields} onChange={onChange}
            options={[
              {value:'DUPL',label:'DUPL – Duplicate Payment'},{value:'FRAD',label:'FRAD – Fraudulent Origin'},
              {value:'TECH',label:'TECH – Technical Problem'},{value:'NARR',label:'NARR – Narrative'},
              {value:'CUST',label:'CUST – Customer Request'},{value:'UPAY',label:'UPAY – Undue Payment'},
            ]} />
          <Field label="Additional Cancellation Info" name="addtlCxlRsnInf" fields={fields} onChange={onChange} rows={2} />
        </Row2>
      </Section>
    </div>
  );
}

// ════════════════════════════════════════════════════════════════════════════════
// camt.029 — Resolution of Investigation
// ════════════════════════════════════════════════════════════════════════════════
function Camt029Form({ fields, onChange }: { fields: Record<string,string>; onChange: (f: Record<string,string>) => void }) {
  return (
    <div className="space-y-4">
      <Section title="Assignment">
        <Row2>
          <Field label="Message ID" name="msgId" fields={fields} onChange={onChange} required />
          <DTField label="Creation Date / Time" name="creDtTm" fields={fields} onChange={onChange} required />
        </Row2>
        <Row2>
          <BICField label="Assigning Agent BIC" name="instgAgt" fields={fields} onChange={onChange} required />
          <BICField label="Assigned Agent BIC" name="instdAgt" fields={fields} onChange={onChange} required />
        </Row2>
      </Section>

      <Section title="Original Message Reference">
        <Row2>
          <Field label="Original Message ID" name="orgnlMsgId" fields={fields} onChange={onChange} required />
          <Field label="Original Message Name ID" name="orgnlMsgNmId" fields={fields} onChange={onChange} hint="e.g. camt.056.001.08" />
        </Row2>
        <Row2>
          <Field label="Original End-to-End ID" name="orgnlEndToEndId" fields={fields} onChange={onChange} required />
          <Field label="Original UETR" name="orgnlUETR" fields={fields} onChange={onChange} required />
        </Row2>
      </Section>

      <Section title="Resolution Status">
        <Row2>
          <SelectField label="Status" name="sts" fields={fields} onChange={onChange}
            options={[
              {value:'CNCL',label:'CNCL – Cancelled'},{value:'RJCR',label:'RJCR – Rejected'},
              {value:'PDCR',label:'PDCR – Pending Cancellation'},{value:'IPAY',label:'IPAY – In Progress'},
            ]} />
          <Field label="Reason Code" name="rsnCd" fields={fields} onChange={onChange} hint="Optional reason code" />
        </Row2>
        <Field label="Additional Information" name="addtlInf" fields={fields} onChange={onChange} rows={3} />
      </Section>
    </div>
  );
}

// ════════════════════════════════════════════════════════════════════════════════
// camt.053 — Bank to Customer Statement
// ════════════════════════════════════════════════════════════════════════════════
function Camt053Form({ fields, onChange }: { fields: Record<string,string>; onChange: (f: Record<string,string>) => void }) {
  return (
    <div className="space-y-4">
      <Section title="Group Header">
        <Row2>
          <Field label="Message ID" name="msgId" fields={fields} onChange={onChange} required />
          <DTField label="Creation Date / Time" name="creDtTm" fields={fields} onChange={onChange} required />
        </Row2>
      </Section>

      <Section title="Statement">
        <Row3>
          <Field label="Statement ID" name="stmtId" fields={fields} onChange={onChange} required />
          <Field label="Electronic Sequence No." name="elctrncSeqNb" fields={fields} onChange={onChange} />
          <div>
            <label className={labelCls}>Currency</label>
            <CurrencyPicker value={fields['acctCcy'] ?? 'USD'} onChange={v => onChange({ ...fields, acctCcy: v })} />
          </div>
        </Row3>
        <Row2>
          <DTField label="From Date" name="frDt" fields={fields} onChange={onChange} dateOnly required />
          <DTField label="To Date" name="toDt" fields={fields} onChange={onChange} dateOnly required />
        </Row2>
      </Section>

      <Section title="Account">
        <Row2>
          <IBANField label="Account IBAN" name="acctId" fields={fields} onChange={onChange} required
            hint="Spaces stripped automatically" />
          <Field label="Account Owner Name" name="acctOwnrNm" fields={fields} onChange={onChange} required />
        </Row2>
        <Row2>
          <BICField label="Account Servicer BIC" name="svcr" fields={fields} onChange={onChange} required
            onResolvedName={n => onChange({ ...fields, svcr: fields.svcr ?? '', svcrNm: n })} />
          <Field label="Servicer Name" name="svcrNm" fields={fields} onChange={onChange}
            hint="Auto-filled from BIC directory" />
        </Row2>
      </Section>

      <Section title="Balances">
        <Row2>
          <div>
            <label className={labelCls}>Opening Balance *</label>
            <div className="flex gap-2">
              <div className="w-36"><CurrencyPicker value={fields['openingBalCcy'] ?? 'USD'} onChange={v => onChange({ ...fields, openingBalCcy: v })} /></div>
              <input className={inputCls + ' flex-1'} placeholder="0.00" value={fields['openingBal'] ?? ''} onChange={e => onChange({ ...fields, openingBal: e.target.value })} />
            </div>
          </div>
          <div>
            <label className={labelCls}>Closing Balance *</label>
            <div className="flex gap-2">
              <div className="w-36"><CurrencyPicker value={fields['closingBalCcy'] ?? 'USD'} onChange={v => onChange({ ...fields, closingBalCcy: v })} /></div>
              <input className={inputCls + ' flex-1'} placeholder="0.00" value={fields['closingBal'] ?? ''} onChange={e => onChange({ ...fields, closingBal: e.target.value })} />
            </div>
          </div>
        </Row2>
      </Section>

      <Section title="Entry">
        <Row3>
          <div>
            <label className={labelCls}>Entry Amount *</label>
            <div className="flex gap-2">
              <div className="w-28"><CurrencyPicker value={fields['ntryCcy'] ?? 'USD'} onChange={v => onChange({ ...fields, ntryCcy: v })} /></div>
              <input className={inputCls + ' flex-1'} placeholder="0.00" value={fields['ntryAmt'] ?? ''} onChange={e => onChange({ ...fields, ntryAmt: e.target.value })} />
            </div>
          </div>
          <SelectField label="Credit/Debit" name="cdtDbtInd" fields={fields} onChange={onChange}
            options={[{value:'CRDT',label:'CRDT – Credit'},{value:'DBIT',label:'DBIT – Debit'}]} />
          <DTField label="Entry Date" name="ntryDt" fields={fields} onChange={onChange} dateOnly required />
        </Row3>
        <Row2>
          <Field label="Account Servicer Reference" name="ntryRef" fields={fields} onChange={onChange} />
          <Field label="End-to-End ID" name="endToEndId" fields={fields} onChange={onChange} />
        </Row2>
        <Field label="Remittance Information" name="rmtInf" fields={fields} onChange={onChange} rows={2} />
      </Section>
    </div>
  );
}

// ════════════════════════════════════════════════════════════════════════════════
// camt.054 — Bank to Customer Debit/Credit Notification
// ════════════════════════════════════════════════════════════════════════════════
function Camt054Form({ fields, onChange }: { fields: Record<string,string>; onChange: (f: Record<string,string>) => void }) {
  return (
    <div className="space-y-4">
      <Section title="Group Header">
        <Row2>
          <Field label="Message ID" name="msgId" fields={fields} onChange={onChange} required />
          <DTField label="Creation Date / Time" name="creDtTm" fields={fields} onChange={onChange} required />
        </Row2>
      </Section>

      <Section title="Account">
        <Row2>
          <IBANField label="Account IBAN" name="acctId" fields={fields} onChange={onChange} required
            hint="Spaces stripped automatically, IBAN validated" />
          <Field label="Account Owner Name" name="acctOwnrNm" fields={fields} onChange={onChange} required />
        </Row2>
        <Row2>
          <div>
            <label className={labelCls}>Account Currency</label>
            <CurrencyPicker value={fields['acctCcy'] ?? 'USD'} onChange={v => onChange({ ...fields, acctCcy: v })} />
          </div>
          <BICField label="Account Servicer BIC" name="svcr" fields={fields} onChange={onChange} required
            onResolvedName={n => onChange({ ...fields, svcr: fields.svcr ?? '', svcrNm: n })} />
        </Row2>
        <Field label="Servicer Name" name="svcrNm" fields={fields} onChange={onChange}
          hint="Auto-filled from BIC directory when BIC is recognised" />
      </Section>

      <Section title="Notification">
        <Field label="Notification ID" name="ntfctnId" fields={fields} onChange={onChange} required />
      </Section>

      <Section title="Entry">
        <Row3>
          <div>
            <label className={labelCls}>Entry Amount *</label>
            <div className="flex gap-2">
              <div className="w-28"><CurrencyPicker value={fields['ntryCcy'] ?? 'USD'} onChange={v => onChange({ ...fields, ntryCcy: v })} /></div>
              <input className={inputCls + ' flex-1'} placeholder="0.00" value={fields['ntryAmt'] ?? ''} onChange={e => onChange({ ...fields, ntryAmt: e.target.value })} />
            </div>
          </div>
          <SelectField label="Credit/Debit" name="cdtDbtInd" fields={fields} onChange={onChange}
            options={[{value:'CRDT',label:'CRDT – Credit'},{value:'DBIT',label:'DBIT – Debit'}]} />
          <SelectField label="Bank Tx Code" name="bkTxCd" fields={fields} onChange={onChange}
            options={[{value:'ICDT',label:'ICDT – Issued Credit Transfer'},{value:'RDDT',label:'RDDT – Received Direct Debit'},{value:'RCDT',label:'RCDT – Received Credit Transfer'},{value:'IDDT',label:'IDDT – Issued Direct Debit'}]} />
        </Row3>
        <Row2>
          <DTField label="Booking Date" name="ntryDt" fields={fields} onChange={onChange} dateOnly required />
          <DTField label="Value Date" name="valDt" fields={fields} onChange={onChange} dateOnly />
        </Row2>
        <Field label="Account Servicer Reference" name="ntryRef" fields={fields} onChange={onChange} />
      </Section>

      <Section title="Transaction References">
        <Row2>
          <Field label="Instruction ID" name="instrId" fields={fields} onChange={onChange} required />
          <Field label="End-to-End ID" name="endToEndId" fields={fields} onChange={onChange} required />
        </Row2>
        <Row2>
          <Field label="Transaction ID" name="txId" fields={fields} onChange={onChange} />
          <Field label="UETR" name="uetr" fields={fields} onChange={onChange} required />
        </Row2>
      </Section>

      <Section title="Debtor">
        <Row2>
          <BICField label="Debtor Agent BIC" name="dbtrAgtBIC" fields={fields} onChange={onChange}
            onResolvedName={n => onChange({ ...fields, dbtrAgtBIC: fields.dbtrAgtBIC ?? '', dbtrAgtNm: n })} />
          <Field label="Debtor Agent Name" name="dbtrAgtNm" fields={fields} onChange={onChange}
            hint="Auto-filled from BIC directory" />
        </Row2>
        <Row2>
          <Field label="Debtor Name" name="dbtrNm" fields={fields} onChange={onChange} />
          <IBANField label="Debtor IBAN" name="dbtrAcct" fields={fields} onChange={onChange}
            hint="Spaces stripped automatically" />
        </Row2>
      </Section>

      <Section title="Creditor">
        <Row2>
          <BICField label="Creditor Agent BIC" name="cdtrAgtBIC" fields={fields} onChange={onChange}
            onResolvedName={n => onChange({ ...fields, cdtrAgtBIC: fields.cdtrAgtBIC ?? '', cdtrAgtNm: n })} />
          <Field label="Creditor Agent Name" name="cdtrAgtNm" fields={fields} onChange={onChange}
            hint="Auto-filled from BIC directory" />
        </Row2>
        <Row2>
          <Field label="Creditor Name" name="cdtrNm" fields={fields} onChange={onChange} />
          <IBANField label="Creditor IBAN" name="cdtrAcct" fields={fields} onChange={onChange}
            hint="Spaces stripped automatically" />
        </Row2>
      </Section>

      <Section title="Additional">
        <Row2>
          <Field label="Purpose Code" name="purp" fields={fields} onChange={onChange} hint="e.g. SUPP, INTC" />
          <Field label="Additional Entry Info" name="addtlNtryInf" fields={fields} onChange={onChange} />
        </Row2>
        <Field label="Remittance Information" name="rmtInf" fields={fields} onChange={onChange} rows={3} />
      </Section>
    </div>
  );
}

// ════════════════════════════════════════════════════════════════════════════════
// pain.001 — Customer Credit Transfer Initiation
// ════════════════════════════════════════════════════════════════════════════════
function Pain001Form({ fields, onChange }: { fields: Record<string,string>; onChange: (f: Record<string,string>) => void }) {
  return (
    <div className="space-y-4">
      <Section title="Group Header">
        <Row2>
          <Field label="Message ID" name="msgId" fields={fields} onChange={onChange} required />
          <DTField label="Creation Date / Time" name="creDtTm" fields={fields} onChange={onChange} required />
        </Row2>
        <Row3>
          <Field label="Number of Transactions" name="nbOfTxs" fields={fields} onChange={onChange} />
          <Field label="Control Sum" name="ctrlSum" fields={fields} onChange={onChange} hint="Total amount" />
          <Field label="Initiating Party Name" name="initgPtyNm" fields={fields} onChange={onChange} required />
        </Row3>
      </Section>

      <Section title="Payment Information">
        <Row2>
          <Field label="Payment Information ID" name="pmtInfId" fields={fields} onChange={onChange} required />
          <SelectField label="Payment Method" name="pmtMtd" fields={fields} onChange={onChange}
            options={[{value:'TRF',label:'TRF – Credit Transfer'},{value:'CHK',label:'CHK – Cheque'},{value:'DD',label:'DD – Direct Debit'}]} />
        </Row2>
        <DTField label="Requested Execution Date" name="reqdExctnDt" fields={fields} onChange={onChange} dateOnly required />
      </Section>

      <Section title="Debtor">
        <Row2>
          <BICField label="Debtor Agent BIC *" name="dbtrAgtBIC" fields={fields} onChange={onChange} required
            onResolvedName={n => onChange({ ...fields, dbtrAgtBIC: fields.dbtrAgtBIC ?? '', dbtrAgtNm: n })} />
          <Field label="Debtor Agent Name" name="dbtrAgtNm" fields={fields} onChange={onChange}
            hint="Auto-filled from BIC directory" />
        </Row2>
        <Row2>
          <Field label="Debtor Name" name="dbtrNm" fields={fields} onChange={onChange} required />
          <IBANField label="Debtor IBAN" name="dbtrAcct" fields={fields} onChange={onChange} required
            hint="Spaces stripped automatically" />
        </Row2>
      </Section>

      <Section title="Credit Transfer Transaction">
        <Field label="End-to-End ID" name="endToEndId" fields={fields} onChange={onChange} required />
        <CcyAmtRow ccyName="instrCcy" amtName="instrAmt" label="Instructed Amount *" fields={fields} onChange={onChange} />
      </Section>

      <Section title="Creditor">
        <Row2>
          <BICField label="Creditor Agent BIC *" name="cdtrAgtBIC" fields={fields} onChange={onChange} required
            onResolvedName={n => onChange({ ...fields, cdtrAgtBIC: fields.cdtrAgtBIC ?? '', cdtrAgtNm: n })} />
          <Field label="Creditor Agent Name" name="cdtrAgtNm" fields={fields} onChange={onChange}
            hint="Auto-filled from BIC directory" />
        </Row2>
        <Row2>
          <Field label="Creditor Name" name="cdtrNm" fields={fields} onChange={onChange} required />
          <IBANField label="Creditor IBAN" name="cdtrAcct" fields={fields} onChange={onChange} required
            hint="Spaces stripped automatically" />
        </Row2>
      </Section>

      <Section title="Additional">
        <Row2>
          <Field label="Purpose Code" name="purp" fields={fields} onChange={onChange} hint="e.g. SUPP, SALA" />
          <Field label="Remittance Information" name="rmtInf" fields={fields} onChange={onChange} rows={2} />
        </Row2>
      </Section>
    </div>
  );
}

// ════════════════════════════════════════════════════════════════════════════════
// pain.002 — Customer Payment Status Report
// ════════════════════════════════════════════════════════════════════════════════
function Pain002Form({ fields, onChange }: { fields: Record<string,string>; onChange: (f: Record<string,string>) => void }) {
  return (
    <div className="space-y-4">
      <Section title="Group Header">
        <Row2>
          <Field label="Message ID" name="msgId" fields={fields} onChange={onChange} required />
          <DTField label="Creation Date / Time" name="creDtTm" fields={fields} onChange={onChange} required />
        </Row2>
        <Field label="Initiating Party Name" name="initgPtyNm" fields={fields} onChange={onChange} required />
      </Section>

      <Section title="Original Group Info & Status">
        <Row2>
          <Field label="Original Message ID" name="orgnlMsgId" fields={fields} onChange={onChange} required />
          <Field label="Original Message Name ID" name="orgnlMsgNmId" fields={fields} onChange={onChange} hint="e.g. pain.001.001.09" />
        </Row2>
        <Row2>
          <Field label="Original Number of Transactions" name="orgnlNbOfTxs" fields={fields} onChange={onChange} />
          <Field label="Original Control Sum" name="orgnlCtrlSum" fields={fields} onChange={onChange} />
        </Row2>
        <SelectField label="Group Status" name="grpSts" fields={fields} onChange={onChange}
          options={[
            {value:'ACCP',label:'ACCP – Accepted'},{value:'ACSC',label:'ACSC – Settlement Completed'},
            {value:'ACSP',label:'ACSP – Settlement in Process'},{value:'PDNG',label:'PDNG – Pending'},
            {value:'RJCT',label:'RJCT – Rejected'},
          ]} />
      </Section>

      <Section title="Original Payment Info & Status">
        <Row2>
          <Field label="Original End-to-End ID" name="orgnlEndToEndId" fields={fields} onChange={onChange} required />
          <SelectField label="Transaction Status" name="txSts" fields={fields} onChange={onChange}
            options={[
              {value:'ACCP',label:'ACCP – Accepted'},{value:'RJCT',label:'RJCT – Rejected'},
              {value:'PDNG',label:'PDNG – Pending'},{value:'ACSP',label:'ACSP – In Process'},
            ]} />
        </Row2>
        <Row2>
          <Field label="Reason Code" name="rsnCd" fields={fields} onChange={onChange} hint="e.g. AC01, NARR (optional)" />
          <Field label="Additional Status Reason Info" name="addtlStsRsnInf" fields={fields} onChange={onChange} rows={2} />
        </Row2>
      </Section>
    </div>
  );
}

// ════════════════════════════════════════════════════════════════════════════════
// Main dispatcher
// ════════════════════════════════════════════════════════════════════════════════
export const ISO20022Form: React.FC<Props> = ({ msgType, fields, onChange }) => {
  switch (msgType) {
    case 'pacs.008': return <Pacs008Form fields={fields} onChange={onChange} />;
    case 'pacs.009': return <Pacs009Form fields={fields} onChange={onChange} />;
    case 'pacs.004': return <Pacs004Form fields={fields} onChange={onChange} />;
    case 'pacs.002': return <Pacs002Form fields={fields} onChange={onChange} />;
    case 'camt.056': return <Camt056Form fields={fields} onChange={onChange} />;
    case 'camt.029': return <Camt029Form fields={fields} onChange={onChange} />;
    case 'camt.053': return <Camt053Form fields={fields} onChange={onChange} />;
    case 'camt.054': return <Camt054Form fields={fields} onChange={onChange} />;
    case 'pain.001': return <Pain001Form fields={fields} onChange={onChange} />;
    case 'pain.002': return <Pain002Form fields={fields} onChange={onChange} />;
    default:
      return (
        <div className="text-center py-12 text-gray-400">
          <p className="text-lg font-semibold">Select a message type to begin</p>
        </div>
      );
  }
};
