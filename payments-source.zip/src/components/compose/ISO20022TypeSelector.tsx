import React from 'react';
import { ISO20022MessageType } from '../../types';
import { cn } from '../../utils/cn';

interface Props {
  value: ISO20022MessageType | '';
  onChange: (type: ISO20022MessageType) => void;
}

const GROUPS = [
  {
    family: 'pacs — Payments Clearing & Settlement',
    color: 'blue',
    items: [
      { type: 'pacs.008' as ISO20022MessageType, title: 'pacs.008', desc: 'FI to FI Customer Credit Transfer' },
      { type: 'pacs.002' as ISO20022MessageType, title: 'pacs.002', desc: 'FI to FI Payment Status Report' },
      { type: 'pacs.004' as ISO20022MessageType, title: 'pacs.004', desc: 'Payment Return' },
      { type: 'pacs.009' as ISO20022MessageType, title: 'pacs.009', desc: 'Financial Institution Credit Transfer' },
    ],
  },
  {
    family: 'camt — Cash Management',
    color: 'violet',
    items: [
      { type: 'camt.053' as ISO20022MessageType, title: 'camt.053', desc: 'Bank to Customer Statement' },
      { type: 'camt.054' as ISO20022MessageType, title: 'camt.054', desc: 'Bank to Customer Debit/Credit Notification' },
      { type: 'camt.056' as ISO20022MessageType, title: 'camt.056', desc: 'FI to FI Payment Cancellation Request' },
      { type: 'camt.029' as ISO20022MessageType, title: 'camt.029', desc: 'Resolution of Investigation' },
      { type: 'camt.052' as ISO20022MessageType, title: 'camt.052', desc: 'Bank to Customer Account Report' },
      { type: 'camt.060' as ISO20022MessageType, title: 'camt.060', desc: 'Account Reporting Request' },
    ],
  },
  {
    family: 'pain — Payments Initiation',
    color: 'amber',
    items: [
      { type: 'pain.001' as ISO20022MessageType, title: 'pain.001', desc: 'Customer Credit Transfer Initiation' },
      { type: 'pain.002' as ISO20022MessageType, title: 'pain.002', desc: 'Customer Payment Status Report' },
    ],
  },
  {
    family: 'pin — Payment Initiation Notification',
    color: 'emerald',
    items: [
      { type: 'pin.001' as ISO20022MessageType, title: 'pin.001', desc: 'Payment Initiation Notification' },
      { type: 'pin.002' as ISO20022MessageType, title: 'pin.002', desc: 'Payment Initiation Status Notification' },
    ],
  },
];

const colorMap: Record<string, string> = {
  blue:    'border-blue-500/40 bg-blue-950/40 hover:border-blue-400',
  violet:  'border-violet-500/40 bg-violet-950/40 hover:border-violet-400',
  amber:   'border-amber-500/40 bg-amber-950/40 hover:border-amber-400',
  emerald: 'border-emerald-500/40 bg-emerald-950/40 hover:border-emerald-400',
};
const selectedMap: Record<string, string> = {
  blue:    'border-blue-400 bg-blue-900/60 ring-2 ring-blue-500/30',
  violet:  'border-violet-400 bg-violet-900/60 ring-2 ring-violet-500/30',
  amber:   'border-amber-400 bg-amber-900/60 ring-2 ring-amber-500/30',
  emerald: 'border-emerald-400 bg-emerald-900/60 ring-2 ring-emerald-500/30',
};
const badgeMap: Record<string, string> = {
  blue:    'text-blue-300 bg-blue-900/80 border border-blue-700/50',
  violet:  'text-violet-300 bg-violet-900/80 border border-violet-700/50',
  amber:   'text-amber-300 bg-amber-900/80 border border-amber-700/50',
  emerald: 'text-emerald-300 bg-emerald-900/80 border border-emerald-700/50',
};
const headerMap: Record<string, string> = {
  blue:    'text-blue-400',
  violet:  'text-violet-400',
  amber:   'text-amber-400',
  emerald: 'text-emerald-400',
};

export const ISO20022TypeSelector: React.FC<Props> = ({ value, onChange }) => (
  <div className="space-y-6">
    {GROUPS.map(group => (
      <div key={group.family}>
        <p className={cn('text-xs font-bold uppercase tracking-widest mb-3', headerMap[group.color])}>
          {group.family}
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
          {group.items.map(item => (
            <button
              key={item.type}
              onClick={() => onChange(item.type)}
              className={cn(
                'flex flex-col items-start gap-2 p-4 rounded-xl border-2 transition-all duration-150 text-left cursor-pointer',
                value === item.type ? selectedMap[group.color] : colorMap[group.color]
              )}
            >
              <span className={cn('font-mono font-bold text-sm px-2 py-0.5 rounded', badgeMap[group.color])}>
                {item.title}
              </span>
              <span className="text-xs text-slate-400 leading-tight">{item.desc}</span>
            </button>
          ))}
        </div>
      </div>
    ))}
  </div>
);
