import React, { useState, useCallback, useEffect, useRef } from 'react';
import { v4 as uuidv4 } from 'uuid';
import {
  Send, Save, Eye, RefreshCw, ChevronDown, Search,
  CheckCircle, AlertCircle, Copy, Check, Sparkles, X
} from 'lucide-react';
import {
  AnyMessageType, MTMessageType, ISO20022MessageType,
  SWIFTMessage, MT700Fields, MT705Fields, MT760Fields,
  MT199Fields, MT799Fields, MTFields, ISO20022Fields, MessageStandard
} from '../../types';
import { generateAllIdentifiers } from '../../utils/identifiers';
import {
  buildSWIFTMessage, buildBlock1, buildBlock2Input, buildBlock3, defaultBlock5
} from '../../utils/swiftBuilder';
import { buildISO20022Message } from '../../utils/iso20022Builder';
import { saveMessage } from '../../utils/storage';
import { getDefaultFields, BANK_BICS } from '../../utils/autofill';
import { MessageProfile } from '../../utils/profiles';
import { BICField } from '../ui/BICField';
import { lookupBIC } from '../../utils/bicDirectory';
import { MT700Form } from './forms/MT700Form';
import { MT705Form } from './forms/MT705Form';
import { MT760Form } from './forms/MT760Form';
import { FreeFormatForm } from './forms/FreeFormatForm';
import { ISO20022Form } from './ISO20022Form';



interface ComposeViewProps {
  editMessage?: SWIFTMessage | null;
  profile?: MessageProfile | null;
  onSaved: (msg: SWIFTMessage) => void;
  onPreview: (msg: SWIFTMessage) => void;
}

const MT_TYPES: MTMessageType[] = ['MT199', 'MT799', 'MT705', 'MT760', 'MT700'];

const MT_INFO: Record<string, { label: string; color: string; desc: string }> = {
  MT700: { label: 'MT700', color: 'blue',    desc: 'Issue of a Documentary Credit' },
  MT705: { label: 'MT705', color: 'cyan',    desc: 'Pre-Advice of a Documentary Credit' },
  MT760: { label: 'MT760', color: 'emerald', desc: 'Guarantee / Standby LC' },
  MT199: { label: 'MT199', color: 'amber',   desc: 'Free Format Message (Cat. 1)' },
  MT799: { label: 'MT799', color: 'orange',  desc: 'Free Format Message (Cat. 7)' },
};

const ISO_INFO: Record<string, { label: string; color: string; desc: string }> = {
  'pacs.008': { label: 'pacs.008', color: 'violet', desc: 'FI to FI Customer Credit Transfer' },
  'pacs.009': { label: 'pacs.009', color: 'indigo', desc: 'Financial Institution Credit Transfer' },
  'pacs.004': { label: 'pacs.004', color: 'blue',   desc: 'Payment Return' },
  'pacs.002': { label: 'pacs.002', color: 'purple', desc: 'FI to FI Payment Status Report' },
  'camt.056': { label: 'camt.056', color: 'rose',   desc: 'FI to FI Payment Cancellation Request' },
  'camt.029': { label: 'camt.029', color: 'pink',   desc: 'Resolution of Investigation' },
  'camt.053': { label: 'camt.053', color: 'teal',   desc: 'Bank-to-Customer Statement' },
  'camt.054': { label: 'camt.054', color: 'cyan',   desc: 'Debit/Credit Notification' },
  'pain.001': { label: 'pain.001', color: 'emerald',desc: 'Customer Credit Transfer Initiation' },
  'pain.002': { label: 'pain.002', color: 'green',  desc: 'Customer Payment Status Report' },
};

function detectStandard(t: AnyMessageType | ''): MessageStandard {
  if (!t) return 'SWIFT_MT';
  return (MT_TYPES as string[]).includes(t) ? 'SWIFT_MT' : 'ISO20022';
}

// ─── Bank Quick Pick (dropdown only — BIC input handled by BICField above) ───
const BankQuickPick: React.FC<{
  value: string; onChange: (v: string) => void;
}> = ({ value: _v, onChange }) => {
  const [open, setOpen] = useState(false);
  const [q, setQ]       = useState('');
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const filtered = BANK_BICS.filter(b =>
    !q ||
    b.bic.toLowerCase().includes(q.toLowerCase()) ||
    b.name.toLowerCase().includes(q.toLowerCase()) ||
    b.country.toLowerCase().includes(q.toLowerCase())
  );

  return (
    <div className="relative mt-1" ref={ref}>
      <button
        type="button"
        onClick={() => setOpen(o => !o)}
        className="flex items-center gap-1.5 text-[10px] text-slate-400 hover:text-[#F7941D]
          transition-colors cursor-pointer px-2 py-1 rounded border border-slate-700 hover:border-[#F7941D]/40 bg-slate-800/60"
      >
        <Search size={10} />
        Pick from known banks
        <ChevronDown size={10} className={`transition-transform ${open ? 'rotate-180' : ''}`} />
      </button>

      {open && (
        <div className="absolute z-50 top-full mt-1 left-0 w-96 bg-[#1a2035] border border-slate-600 rounded-xl shadow-2xl overflow-hidden">
          <div className="p-2 border-b border-slate-700">
            <div className="flex items-center gap-2 bg-slate-800 rounded-lg px-2 py-1.5">
              <Search size={11} className="text-slate-500" />
              <input
                className="flex-1 bg-transparent text-xs text-white placeholder-slate-500 outline-none"
                placeholder="Search bank name, BIC, or country…"
                value={q}
                onChange={e => setQ(e.target.value)}
                autoFocus
              />
              {q && (
                <button type="button" onClick={() => setQ('')}
                  className="text-slate-500 hover:text-white">
                  <X size={10}/>
                </button>
              )}
            </div>
          </div>
          <div className="max-h-64 overflow-y-auto">
            {filtered.map(b => {
              const dir = lookupBIC(b.bic);
              return (
                <button
                  key={b.bic}
                  type="button"
                  onClick={() => { onChange(b.bic); setOpen(false); setQ(''); }}
                  className="w-full flex items-start gap-2.5 px-3 py-2.5 hover:bg-slate-700/60 transition-colors cursor-pointer text-left border-b border-slate-700/30 last:border-0"
                >
                  {/* BIC badge */}
                  <span className="shrink-0 mt-0.5 text-xs font-mono text-[#F7941D] font-bold bg-slate-800 border border-slate-600 rounded px-1.5 py-0.5">
                    {b.bic}
                  </span>
                  <div className="flex-1 min-w-0">
                    {/* Full bank name from directory or fallback */}
                    <p className="text-xs text-white font-medium truncate">
                      {dir ? dir.name : b.name}
                    </p>
                    <div className="flex items-center gap-2 mt-0.5">
                      <span className="text-[10px] text-slate-400">{dir ? dir.city : b.country}</span>
                      {dir && (
                        <span className="text-[10px] text-slate-500">·</span>
                      )}
                      {dir && (
                        <span className="text-[10px] text-slate-400">{dir.country}</span>
                      )}
                      {dir?.currency && (
                        <span className="ml-auto text-[10px] font-mono text-orange-400 bg-orange-900/30 border border-orange-800/40 rounded px-1">
                          {dir.currency}
                        </span>
                      )}
                    </div>
                  </div>
                </button>
              );
            })}
            {filtered.length === 0 && (
              <p className="text-xs text-slate-500 text-center py-4">No banks match "{q}"</p>
            )}
          </div>
          <div className="px-3 py-1.5 border-t border-slate-700 bg-slate-800/60">
            <p className="text-[10px] text-slate-500">{filtered.length} of {BANK_BICS.length} banks shown</p>
          </div>
        </div>
      )}
    </div>
  );
};

// ─── Identifiers strip ────────────────────────────────────────────────────────
const IdentifierStrip: React.FC<{
  identifiers: ReturnType<typeof generateAllIdentifiers>;
  onRegenerate: () => void;
}> = ({ identifiers, onRegenerate }) => {
  const [copied, setCopied] = useState<string | null>(null);
  const copy = async (val: string, key: string) => {
    await navigator.clipboard.writeText(val);
    setCopied(key);
    setTimeout(() => setCopied(null), 1200);
  };

  const items = [
    { key: 'uetr',           label: 'UETR',     val: identifiers.uetr },
    { key: 'transactionRef', label: 'TRN :20:', val: identifiers.transactionRef },
    { key: 'messageId',      label: 'MSG-ID',   val: identifiers.messageId },
    { key: 'sessionId',      label: 'SESSION',  val: identifiers.sessionId },
    { key: 'routingId',      label: 'ROUTE',    val: identifiers.routingId },
  ];

  return (
    <div className="bg-[#0d1117] border border-slate-700/60 rounded-xl overflow-hidden">
      <div className="flex items-center justify-between px-4 py-2.5 border-b border-slate-700/60 bg-slate-800/60">
        <div className="flex items-center gap-2">
          <Sparkles size={13} className="text-[#F7941D]" />
          <span className="text-xs font-semibold text-white">Auto-Generated Identifiers</span>
          <span className="text-[10px] text-slate-500 bg-slate-700 px-1.5 py-0.5 rounded">SWIFT + ISO 20022</span>
        </div>
        <button
          onClick={onRegenerate}
          className="flex items-center gap-1.5 text-xs text-[#F7941D] hover:text-orange-300 transition-colors cursor-pointer"
        >
          <RefreshCw size={12} />
          Regenerate
        </button>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 divide-y sm:divide-y-0 sm:divide-x divide-slate-700/40">
        {items.map(({ key, label, val }) => (
          <div key={key} className="px-3 py-2.5 group">
            <div className="flex items-center justify-between mb-1">
              <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">{label}</span>
              <button
                onClick={() => copy(val, key)}
                className="opacity-0 group-hover:opacity-100 transition-opacity text-slate-500 hover:text-slate-300 cursor-pointer"
              >
                {copied === key ? <Check size={10} className="text-emerald-400" /> : <Copy size={10} />}
              </button>
            </div>
            <code className="text-[10px] font-mono text-emerald-400 break-all leading-tight">{val}</code>
          </div>
        ))}
      </div>
    </div>
  );
};

// ─── Raw preview panel ────────────────────────────────────────────────────────
const RawPreview: React.FC<{ raw: string; isMT: boolean; msgType: string }> = ({ raw, isMT, msgType }) => (
  <div className="bg-[#0d1117] border border-slate-700/60 rounded-xl overflow-hidden shadow-xl">
    <div className="flex items-center justify-between px-4 py-2.5 bg-[#161b22] border-b border-slate-700/60">
      <span className="text-xs font-mono text-slate-400">
        {isMT ? 'SWIFT FIN' : 'ISO 20022 XML'} · <span className="text-[#F7941D]">{msgType}</span> · LIVE PREVIEW
      </span>
      <div className="flex gap-1.5">
        {['#FF5F57', '#FEBC2E', '#28C840'].map((c, i) => (
          <div key={i} style={{ background: c }} className="w-2.5 h-2.5 rounded-full" />
        ))}
      </div>
    </div>
    <pre className="p-4 text-xs font-mono leading-[1.75] overflow-auto max-h-[420px] whitespace-pre">
      {raw.split('\n').map((line, i) => {
        if (isMT) {
          if (/^\{[1-5]:/.test(line) || line === '{4:')
            return <span key={i} className="block text-blue-400 font-bold">{line}{'\n'}</span>;
          if (line.trim() === '-}')
            return <span key={i} className="block text-teal-400">{line}{'\n'}</span>;
          if (/^\{5:/.test(line))
            return <span key={i} className="block text-slate-500">{line}{'\n'}</span>;
          const tagMatch = line.match(/^(:\d{2}[A-Z]?:)(.*)/s);
          if (tagMatch)
            return <span key={i} className="block">
              <span className="text-[#F7941D] font-bold">{tagMatch[1]}</span>
              <span className="text-emerald-300">{tagMatch[2]}</span>{'\n'}
            </span>;
        } else {
          if (line.trim().startsWith('<?') || line.trim().startsWith('<AppHdr') || line.trim().startsWith('<Document'))
            return <span key={i} className="block text-blue-400 font-bold">{line}{'\n'}</span>;
          if (line.trim().startsWith('</'))
            return <span key={i} className="block text-blue-300">{line}{'\n'}</span>;
          if (line.trim().startsWith('<') && line.includes('>'))
            return <span key={i} className="block text-cyan-300">{line}{'\n'}</span>;
        }
        return <span key={i} className="block text-slate-300">{line}{'\n'}</span>;
      })}
    </pre>
  </div>
);

// ─── Main ComposeView ─────────────────────────────────────────────────────────
// eslint-disable-next-line @typescript-eslint/no-unused-vars
export const ComposeView: React.FC<ComposeViewProps> = ({ editMessage, profile, onSaved, onPreview: _onPreview }) => {
  // Profile pre-filling: if a profile is provided and no editMessage, pre-populate from profile
  const profileMsgType = profile?.messageType as AnyMessageType | undefined;
  const profileIsISO   = profileMsgType && !((['MT199','MT799','MT705','MT760','MT700'] as string[]).includes(profileMsgType));
  const initStd: MessageStandard = editMessage
    ? detectStandard(editMessage.messageType)
    : profileIsISO ? 'ISO20022' : 'SWIFT_MT';

  const [standard, setStandard] = useState<MessageStandard>(initStd);
  const [msgType, setMsgType]   = useState<AnyMessageType | ''>(editMessage?.messageType ?? profileMsgType ?? '');
  const [senderBIC, setSenderBIC]     = useState(editMessage?.senderBIC   ?? profile?.senderBIC   ?? 'CHASUS33');
  const [receiverBIC, setReceiverBIC] = useState(editMessage?.receiverBIC ?? profile?.receiverBIC ?? 'BARCGB22');
  const [priority, setPriority]   = useState(editMessage?.block2?.messagePriority ?? 'N');
  const [description, setDescription] = useState(editMessage?.description ?? '');
  const [identifiers, setIdentifiers] = useState(editMessage?.identifiers ?? generateAllIdentifiers());
  // Merge profile fields with defaults when a profile is provided
  const initMT  = editMessage?.block4  ?? (profile?.mtFields  ? profile.mtFields  as Partial<MTFields>       : {});
  const initISO = editMessage?.isoFields ?? (profile?.isoFields ? { ...getDefaultFields(profileMsgType ?? 'pacs.008'), ...profile.isoFields } as Partial<ISO20022Fields> : {});
  const [mtFields,  setMtFields]  = useState<Partial<MTFields>>(initMT);
  const [isoFields, setIsoFields] = useState<Partial<ISO20022Fields>>(initISO);
  const [errors, setErrors] = useState<string[]>([]);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [showPreview, setShowPreview] = useState(false);

  const isMT = standard === 'SWIFT_MT';

  // ── Auto-fill when message type is selected ─────────────────────────────
  const selectMsgType = useCallback((t: AnyMessageType) => {
    setMsgType(t);
    setErrors([]);
    const defaults = getDefaultFields(t);
    if ((MT_TYPES as string[]).includes(t)) {
      setMtFields(defaults as Partial<MTFields>);
    } else {
      setIsoFields(defaults as Partial<ISO20022Fields>);
    }
    setIdentifiers(generateAllIdentifiers());
    setShowPreview(false);
  }, []);

  const selectStandard = (s: MessageStandard) => {
    setStandard(s);
    setMsgType('');
    setMtFields({});
    setIsoFields({});
    setErrors([]);
    setShowPreview(false);
  };

  // ── Auto-fill all codes ─────────────────────────────────────────────────
  const autoFillAll = useCallback(() => {
    if (!msgType) return;
    const defaults = getDefaultFields(msgType as string);
    if (isMT) setMtFields(defaults as Partial<MTFields>);
    else setIsoFields(defaults as Partial<ISO20022Fields>);
    setIdentifiers(generateAllIdentifiers());
  }, [msgType, isMT]);

  const buildMessage = useCallback((status: 'draft' | 'final'): SWIFTMessage => {
    const senderUpper = senderBIC.toUpperCase().trim();
    const receiverUpper = receiverBIC.toUpperCase().trim();

    if (isMT) {
      const parts = identifiers.sessionId.replace('SES-', '').split('-');
      const session = (parts[0] ?? '0001').padStart(4, '0').slice(-4);
      const seq = (parts[1] ?? '000001').padStart(6, '0').slice(-6);
      const block1 = buildBlock1(senderUpper, session, seq);
      const block2 = buildBlock2Input(msgType as string, receiverUpper, priority);
      const block3 = buildBlock3(identifiers.uetr, identifiers.transactionRef);
      const block5 = defaultBlock5();
      const msg: SWIFTMessage = {
        id: editMessage?.id ?? uuidv4(),
        standard: 'SWIFT_MT',
        messageType: msgType as MTMessageType,
        createdAt: editMessage?.createdAt ?? new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        senderBIC: senderUpper,
        receiverBIC: receiverUpper,
        block1, block2, block3,
        block4: mtFields as MTFields,
        block5, identifiers,
        rawMessage: '',
        status,
        description,
      };
      msg.rawMessage = buildSWIFTMessage(msg);
      return msg;
    } else {
      const f = isoFields as Record<string, string>;
      const msg: SWIFTMessage = {
        id: editMessage?.id ?? uuidv4(),
        standard: 'ISO20022',
        messageType: msgType as ISO20022MessageType,
        createdAt: editMessage?.createdAt ?? new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        senderBIC: senderBIC.toUpperCase().trim(),
        receiverBIC: receiverBIC.toUpperCase().trim(),
        isoFields: { ...isoFields, uetr: f.uetr || identifiers.uetr } as ISO20022Fields,
        identifiers,
        rawMessage: '',
        status,
        description,
      };
      msg.rawMessage = buildISO20022Message(msg);
      return msg;
    }
  }, [isMT, msgType, senderBIC, receiverBIC, priority, identifiers, mtFields, isoFields, description, editMessage]);

  const liveRaw = useCallback((): string => {
    if (!msgType) return '// Select a message type to preview output';
    try { return buildMessage('draft').rawMessage; } catch { return '// Complete required fields to see preview'; }
  }, [msgType, buildMessage]);

  const validate = (): string[] => {
    const errs: string[] = [];
    if (!msgType) errs.push('Select a message type.');
    if (!senderBIC.trim()) errs.push('Sender BIC is required.');
    if (!receiverBIC.trim()) errs.push('Receiver BIC is required.');
    if (isMT) {
      if (msgType === 'MT700' || msgType === 'MT705') {
        const f = mtFields as Partial<MT700Fields>;
        if (!f.tag40A) errs.push(':40A Form of Documentary Credit is required.');
        if (!f.tag20) errs.push(':20 Documentary Credit Number is required.');
        if (!f.tag31D) errs.push(':31D Date and Place of Expiry is required.');
        if (!f.tag50) errs.push(':50 Applicant is required.');
        if (!f.tag59) errs.push(':59 Beneficiary is required.');
        if (!f.tag32B) errs.push(':32B Currency & Amount is required.');
      }
      if (msgType === 'MT760') {
        const f = mtFields as Partial<MT760Fields>;
        if (!f.tag20) errs.push(':20 Transaction Reference is required.');
        if (!f.tag22D) errs.push(':22D Form of Guarantee is required.');
        if (!f.tag32B) errs.push(':32B Currency & Amount is required.');
      }
      if (msgType === 'MT199' || msgType === 'MT799') {
        const f = mtFields as Partial<MT199Fields>;
        if (!f.tag20) errs.push(':20 Transaction Reference is required.');
        if (!f.tag79) errs.push(':79 Narrative is required.');
      }
    } else {
      const f = isoFields as Record<string, string>;
      if (!f.msgId) errs.push('Message ID is required.');
    }
    return errs;
  };

  const handleSave = async (status: 'draft' | 'final') => {
    const errs = validate();
    if (errs.length > 0) { setErrors(errs); return; }
    setSaving(true);
    await new Promise(r => setTimeout(r, 300));
    const msg = buildMessage(status);
    saveMessage(msg);
    onSaved(msg);
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };



  const allMsgTypes = isMT
    ? Object.entries(MT_INFO)
    : Object.entries(ISO_INFO);

  const colorMap: Record<string, string> = {
    blue:   'border-blue-500 bg-blue-950/40 ring-2 ring-blue-500/20',
    cyan:   'border-cyan-500 bg-cyan-950/40 ring-2 ring-cyan-500/20',
    emerald:'border-emerald-500 bg-emerald-950/40 ring-2 ring-emerald-500/20',
    amber:  'border-amber-500 bg-amber-950/40 ring-2 ring-amber-500/20',
    orange: 'border-orange-500 bg-orange-950/40 ring-2 ring-orange-500/20',
    violet: 'border-violet-500 bg-violet-950/40 ring-2 ring-violet-500/20',
    purple: 'border-purple-500 bg-purple-950/40 ring-2 ring-purple-500/20',
    teal:   'border-teal-500 bg-teal-950/40 ring-2 ring-teal-500/20',
    rose:   'border-rose-500 bg-rose-950/40 ring-2 ring-rose-500/20',
    pink:   'border-pink-500 bg-pink-950/40 ring-2 ring-pink-500/20',
    lime:   'border-lime-500 bg-lime-950/40 ring-2 ring-lime-500/20',
    green:  'border-green-500 bg-green-950/40 ring-2 ring-green-500/20',
  };
  const dotMap: Record<string, string> = {
    blue:'bg-blue-400', cyan:'bg-cyan-400', emerald:'bg-emerald-400', amber:'bg-amber-400',
    orange:'bg-orange-400', violet:'bg-violet-400', purple:'bg-purple-400', teal:'bg-teal-400',
    rose:'bg-rose-400', pink:'bg-pink-400', lime:'bg-lime-400', green:'bg-green-400',
  };

  return (
    <div className="space-y-6">

      {/* ── Profile banner ─────────────────────────────────────────────── */}
      {profile && (
        <div className="flex items-center gap-3 px-4 py-3 bg-orange-500/10 border border-orange-500/30 rounded-xl">
          <span className="text-xl">{profile.icon}</span>
          <div className="flex-1 min-w-0">
            <p className="text-xs font-bold text-orange-300">Profile loaded: {profile.name}</p>
            <p className="text-[10px] text-slate-500 truncate">
              {profile.senderBIC && `${profile.senderBIC} → `}{profile.receiverBIC} · {profile.messageType}
              {profile.description ? ` · ${profile.description}` : ''}
            </p>
          </div>
          <span className="text-[10px] text-orange-400/70 bg-orange-500/10 border border-orange-500/20 px-2 py-1 rounded-lg font-mono">
            Pre-filled
          </span>
        </div>
      )}

      {/* ── Header bar ─────────────────────────────────────────────────── */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-lg font-bold text-white">Compose Message</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Select a message type — all codes, dates and references are auto-filled instantly.
          </p>
        </div>
        {msgType && (
          <button
            onClick={autoFillAll}
            className="flex items-center gap-2 px-4 py-2 bg-[#F7941D]/15 hover:bg-[#F7941D]/25 border border-[#F7941D]/40 
              text-[#F7941D] rounded-xl text-xs font-semibold transition-all cursor-pointer"
          >
            <Sparkles size={13} />
            Re-fill All Codes
          </button>
        )}
      </div>

      {/* ── Standard selector ──────────────────────────────────────────── */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {([
          { id: 'SWIFT_MT' as MessageStandard, title: 'SWIFT MT (FIN)', sub: 'Traditional block format — MT700 MT705 MT760 MT199 MT799', tags: ['Block {1}–{5}', 'FIN Protocol', 'Field Tags'] },
          { id: 'ISO20022' as MessageStandard, title: 'ISO 20022 XML', sub: 'Modern XML — pacs, camt, pin message families', tags: ['XML Envelope', 'AppHdr', 'Namespace'] },
        ] as const).map(opt => (
          <button key={opt.id} onClick={() => selectStandard(opt.id)}
            className={`text-left p-4 rounded-xl border-2 transition-all cursor-pointer
              ${standard === opt.id
                ? opt.id === 'SWIFT_MT'
                  ? 'border-blue-500 bg-blue-950/30 ring-2 ring-blue-500/20'
                  : 'border-emerald-500 bg-emerald-950/30 ring-2 ring-emerald-500/20'
                : 'border-slate-700 hover:border-slate-600 bg-slate-800/30'}`}
          >
            <div className="flex items-center justify-between mb-2">
              <span className={`text-sm font-bold ${opt.id === 'SWIFT_MT' ? 'text-blue-300' : 'text-emerald-300'}`}>
                {opt.title}
              </span>
              {standard === opt.id && (
                <CheckCircle size={15} className={opt.id === 'SWIFT_MT' ? 'text-blue-400' : 'text-emerald-400'} />
              )}
            </div>
            <p className="text-xs text-slate-400 mb-2">{opt.sub}</p>
            <div className="flex gap-1 flex-wrap">
              {opt.tags.map(t => (
                <span key={t} className="text-[9px] px-1.5 py-0.5 rounded bg-slate-700 text-slate-400 font-mono">{t}</span>
              ))}
            </div>
          </button>
        ))}
      </div>

      {/* ── Message type tiles ─────────────────────────────────────────── */}
      <div>
        <p className="text-xs font-semibold text-slate-400 uppercase tracking-widest mb-3">
          Select Message Type · Auto-fills all fields on click
        </p>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-2">
          {allMsgTypes.map(([type, info]) => {
            const isSelected = msgType === type;
            return (
              <button
                key={type}
                onClick={() => selectMsgType(type as AnyMessageType)}
                className={`relative text-left p-3.5 rounded-xl border-2 transition-all cursor-pointer group
                  ${isSelected ? colorMap[info.color] : 'border-slate-700 hover:border-slate-500 bg-slate-800/30 hover:bg-slate-800/60'}`}
              >
                {isSelected && (
                  <div className="absolute top-2 right-2">
                    <CheckCircle size={13} className="text-white/80" />
                  </div>
                )}
                <div className={`w-2 h-2 rounded-full mb-2 ${dotMap[info.color]}`} />
                <p className="text-xs font-bold text-white font-mono leading-tight">{info.label}</p>
                <p className="text-[10px] text-slate-400 mt-1 leading-tight">{info.desc}</p>
              </button>
            );
          })}
        </div>
      </div>

      {/* ── Routing ────────────────────────────────────────────────────── */}
      <div className="bg-slate-800/40 border border-slate-700 rounded-xl p-5 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold text-white">Routing & Configuration</h3>
          {isMT && (
            <select
              value={priority}
              onChange={e => setPriority(e.target.value)}
              className="text-xs bg-slate-700 border border-slate-600 rounded-lg px-2 py-1.5 text-white focus:outline-none focus:border-[#F7941D] cursor-pointer"
            >
              <option value="N">Priority: Normal</option>
              <option value="U">Priority: Urgent</option>
              <option value="S">Priority: System</option>
            </select>
          )}
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Sender BIC — validated + bank quick-picker */}
          <div>
            <BICField
              label="Sender BIC *"
              name="senderBIC"
              fields={{ senderBIC }}
              onChange={f => setSenderBIC(f.senderBIC)}
              onResolvedName={n => setIsoFields(prev => ({ ...prev, instgAgtNm: n } as typeof prev))}
              required
              showTz
            />
            <BankQuickPick value={senderBIC} onChange={v => { setSenderBIC(v); }} />
          </div>
          {/* Receiver BIC — validated + bank quick-picker */}
          <div>
            <BICField
              label="Receiver BIC *"
              name="receiverBIC"
              fields={{ receiverBIC }}
              onChange={f => setReceiverBIC(f.receiverBIC)}
              onResolvedName={n => setIsoFields(prev => ({ ...prev, instdAgtNm: n } as typeof prev))}
              required
              showTz
            />
            <BankQuickPick value={receiverBIC} onChange={v => { setReceiverBIC(v); }} />
          </div>
        </div>
        <div>
          <label className="block text-xs font-medium text-slate-400 mb-1">Internal Description (optional)</label>
          <input
            className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white
              placeholder-slate-600 focus:outline-none focus:border-[#F7941D] focus:ring-1 focus:ring-[#F7941D]/30 transition-all"
            placeholder="Brief note for your records — not included in the message"
            value={description}
            onChange={e => setDescription(e.target.value)}
          />
        </div>
      </div>

      {/* ── Auto-generated identifiers ─────────────────────────────────── */}
      <IdentifierStrip
        identifiers={identifiers}
        onRegenerate={() => setIdentifiers(generateAllIdentifiers())}
      />

      {/* ── Message fields ─────────────────────────────────────────────── */}
      {msgType && (
        <div className="bg-slate-800/30 border border-slate-700 rounded-xl overflow-hidden">
          <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-700 bg-slate-800/60">
            <div className="flex items-center gap-2">
              <span className="text-sm font-semibold text-white">
                {msgType} — Message Fields
              </span>
              <span className="text-[10px] text-slate-500 bg-slate-700 px-2 py-0.5 rounded font-mono">
                {isMT ? 'SWIFT FIN' : 'ISO 20022 XML'}
              </span>
            </div>
            <button
              onClick={autoFillAll}
              className="flex items-center gap-1.5 text-[10px] text-[#F7941D] hover:text-orange-300 transition-colors cursor-pointer"
            >
              <RefreshCw size={11} />
              Reset to defaults
            </button>
          </div>
          <div className="p-5">
            {isMT ? (
              <>
                {msgType === 'MT700' && (
                  <MT700Form fields={mtFields as Partial<MT700Fields>} onChange={setMtFields} />
                )}
                {msgType === 'MT705' && (
                  <MT705Form fields={mtFields as Partial<MT705Fields>} onChange={setMtFields} />
                )}
                {msgType === 'MT760' && (
                  <MT760Form fields={mtFields as Partial<MT760Fields>} onChange={setMtFields} />
                )}
                {(msgType === 'MT199' || msgType === 'MT799') && (
                  <FreeFormatForm
                    messageType={msgType}
                    fields={mtFields as Partial<MT199Fields | MT799Fields>}
                    onChange={setMtFields}
                  />
                )}
              </>
            ) : (
              <ISO20022Form
                msgType={msgType as ISO20022MessageType}
                fields={isoFields}
                onChange={setIsoFields}
              />
            )}
          </div>
        </div>
      )}

      {/* ── Live preview toggle ────────────────────────────────────────── */}
      {msgType && (
        <div>
          <button
            onClick={() => setShowPreview(p => !p)}
            className="flex items-center gap-2 text-xs text-slate-400 hover:text-white transition-colors cursor-pointer mb-3"
          >
            <ChevronDown size={13} className={`transition-transform ${showPreview ? 'rotate-180' : ''}`} />
            {showPreview ? 'Hide' : 'Show'} Live Message Preview
          </button>
          {showPreview && (
            <RawPreview raw={liveRaw()} isMT={isMT} msgType={msgType} />
          )}
        </div>
      )}

      {/* ── Error banner ───────────────────────────────────────────────── */}
      {errors.length > 0 && (
        <div className="bg-red-950/60 border border-red-700/50 rounded-xl p-4 flex items-start gap-3">
          <AlertCircle size={15} className="text-red-400 flex-shrink-0 mt-0.5" />
          <div className="flex-1">
            <p className="text-sm font-medium text-red-300 mb-1">Please fix the following:</p>
            <ul className="space-y-0.5">
              {errors.map((e, i) => <li key={i} className="text-xs text-red-400">• {e}</li>)}
            </ul>
          </div>
          <button onClick={() => setErrors([])} className="text-red-600 hover:text-red-400 cursor-pointer">
            <X size={14} />
          </button>
        </div>
      )}

      {/* ── Success banner ─────────────────────────────────────────────── */}
      {saved && (
        <div className="bg-emerald-950/60 border border-emerald-700/50 rounded-xl p-4 flex items-center gap-3">
          <CheckCircle size={15} className="text-emerald-400" />
          <p className="text-sm font-medium text-emerald-300">Message saved successfully!</p>
        </div>
      )}

      {/* ── Action buttons ─────────────────────────────────────────────── */}
      <div className="flex items-center justify-end gap-3 pt-2 border-t border-slate-800">
        <button
          onClick={() => setShowPreview(true)}
          className="flex items-center gap-2 px-4 py-2 text-xs font-medium text-slate-300 hover:text-white 
            bg-slate-700/60 hover:bg-slate-700 rounded-xl transition-all border border-slate-600 cursor-pointer"
        >
          <Eye size={13} />
          Preview
        </button>
        <button
          onClick={() => handleSave('draft')}
          disabled={saving}
          className="flex items-center gap-2 px-4 py-2 text-xs font-medium text-slate-300 hover:text-white
            bg-slate-700/60 hover:bg-slate-700 rounded-xl transition-all border border-slate-600 cursor-pointer disabled:opacity-50"
        >
          <Save size={13} />
          Save Draft
        </button>
        <button
          onClick={() => handleSave('final')}
          disabled={saving || !msgType}
          className="flex items-center gap-2 px-5 py-2 text-xs font-bold text-white
            bg-[#F7941D] hover:bg-[#e8841a] rounded-xl transition-all shadow-lg shadow-orange-900/30 
            cursor-pointer disabled:opacity-50"
        >
          {saving ? (
            <RefreshCw size={13} className="animate-spin" />
          ) : (
            <Send size={13} />
          )}
          Finalise & Save
        </button>
      </div>
    </div>
  );
};
