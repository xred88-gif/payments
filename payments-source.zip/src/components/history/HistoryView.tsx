import React, { useState, useMemo } from 'react';
import {
  Search, Filter, Trash2, Edit2, Eye, Download, Clock,
  ChevronDown, X, CreditCard, Shield, MessageSquare, SortAsc, SortDesc
} from 'lucide-react';
import { SWIFTMessage, MTMessageType, SearchFilters } from '../../types';
import { searchMessages, deleteMessage } from '../../utils/storage';
import { exportMessageToPDF } from '../../utils/pdfExport';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';
import { Modal } from '../ui/Modal';
import { MessageViewer } from '../viewer/MessageViewer';

interface HistoryViewProps {
  messages: SWIFTMessage[];
  onMessagesChange: (msgs: SWIFTMessage[]) => void;
  onEdit: (msg: SWIFTMessage) => void;
}

const MT_ICONS: Record<string, React.ReactNode> = {
  MT700: <CreditCard size={14} />,
  MT705: <CreditCard size={14} />,
  MT760: <Shield size={14} />,
  MT199: <MessageSquare size={14} />,
  MT799: <MessageSquare size={14} />,
};

const MT_COLORS: Record<string, string> = {
  MT700: 'bg-blue-900/40 text-blue-300 border-blue-700/40',
  MT705: 'bg-violet-900/40 text-violet-300 border-violet-700/40',
  MT760: 'bg-emerald-900/40 text-emerald-300 border-emerald-700/40',
  MT199: 'bg-amber-900/40 text-amber-300 border-amber-700/40',
  MT799: 'bg-orange-900/40 text-orange-300 border-orange-700/40',
  'pacs.008': 'bg-violet-900/40 text-violet-300 border-violet-700/40',
  'pacs.009': 'bg-indigo-900/40 text-indigo-300 border-indigo-700/40',
  'pacs.004': 'bg-blue-900/40 text-blue-300 border-blue-700/40',
  'pacs.002': 'bg-purple-900/40 text-purple-300 border-purple-700/40',
  'camt.056': 'bg-rose-900/40 text-rose-300 border-rose-700/40',
  'camt.029': 'bg-pink-900/40 text-pink-300 border-pink-700/40',
  'camt.053': 'bg-teal-900/40 text-teal-300 border-teal-700/40',
  'camt.054': 'bg-cyan-900/40 text-cyan-300 border-cyan-700/40',
  'pain.001': 'bg-emerald-900/40 text-emerald-300 border-emerald-700/40',
  'pain.002': 'bg-green-900/40 text-green-300 border-green-700/40',
  'pin.001':  'bg-lime-900/40 text-lime-300 border-lime-700/40',
  'pin.002':  'bg-green-900/40 text-green-300 border-green-700/40',
};

const MSG_TYPE_OPTIONS: { value: string; label: string }[] = [
  { value: '', label: 'All Types' },
  { value: 'MT700', label: 'MT700 – Documentary Credit' },
  { value: 'MT705', label: 'MT705 – Pre-Advice' },
  { value: 'MT760', label: 'MT760 – Guarantee' },
  { value: 'MT199', label: 'MT199 – Free Format' },
  { value: 'MT799', label: 'MT799 – Free Format' },
  { value: 'pacs.008', label: 'pacs.008 – FI Customer Credit Transfer' },
  { value: 'pacs.009', label: 'pacs.009 – FI Credit Transfer' },
  { value: 'pacs.004', label: 'pacs.004 – Payment Return' },
  { value: 'pacs.002', label: 'pacs.002 – Payment Status Report' },
  { value: 'camt.056', label: 'camt.056 – Payment Cancellation' },
  { value: 'camt.029', label: 'camt.029 – Resolution of Investigation' },
  { value: 'camt.053', label: 'camt.053 – Bank Statement' },
  { value: 'camt.054', label: 'camt.054 – Debit/Credit Notification' },
  { value: 'pain.001', label: 'pain.001 – Credit Transfer Initiation' },
  { value: 'pain.002', label: 'pain.002 – Payment Status Report' },
  { value: 'pin.001',  label: 'pin.001 – Payment Notification' },
  { value: 'pin.002',  label: 'pin.002 – Notification Ack' },
];

type SortKey = 'createdAt' | 'messageType' | 'senderBIC';
type SortDir = 'asc' | 'desc';

export const HistoryView: React.FC<HistoryViewProps> = ({ messages, onMessagesChange, onEdit }) => {
  const [filters, setFilters] = useState<SearchFilters>({
    query: '', messageType: '', bank: '', dateFrom: '', dateTo: '', status: '', standard: '',
  });
  const [showFilters, setShowFilters] = useState(false);
  const [sortKey, setSortKey] = useState<SortKey>('createdAt');
  const [sortDir, setSortDir] = useState<SortDir>('desc');
  const [viewMsg, setViewMsg] = useState<SWIFTMessage | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [exporting, setExporting] = useState<string | null>(null);

  const setFilter = <K extends keyof SearchFilters>(k: K, v: SearchFilters[K]) =>
    setFilters(f => ({ ...f, [k]: v }));

  const clearFilters = () => setFilters({ query: '', messageType: '', bank: '', dateFrom: '', dateTo: '', status: '', standard: '' });

  const activeFilterCount = [
    filters.messageType, filters.bank, filters.dateFrom, filters.dateTo, filters.status
  ].filter(Boolean).length;

  const sorted = useMemo(() => {
    const results = searchMessages(messages, filters);
    return [...results].sort((a, b) => {
      let av: string = '', bv: string = '';
      if (sortKey === 'createdAt') { av = a.createdAt; bv = b.createdAt; }
      if (sortKey === 'messageType') { av = a.messageType; bv = b.messageType; }
      if (sortKey === 'senderBIC') { av = a.senderBIC; bv = b.senderBIC; }
      return sortDir === 'asc' ? av.localeCompare(bv) : bv.localeCompare(av);
    });
  }, [messages, filters, sortKey, sortDir]);

  const toggleSort = (key: SortKey) => {
    if (sortKey === key) setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    else { setSortKey(key); setSortDir('asc'); }
  };

  const handleDelete = (id: string) => {
    const updated = deleteMessage(id);
    onMessagesChange(updated);
    setDeleteId(null);
    if (viewMsg?.id === id) setViewMsg(null);
  };

  const handleExport = async (msg: SWIFTMessage) => {
    setExporting(msg.id);
    await exportMessageToPDF(msg);
    setExporting(null);
  };

  const SortIcon: React.FC<{ k: SortKey }> = ({ k }) => {
    if (sortKey !== k) return <SortAsc size={12} className="text-slate-600" />;
    return sortDir === 'asc'
      ? <SortAsc size={12} className="text-blue-400" />
      : <SortDesc size={12} className="text-blue-400" />;
  };

  return (
    <div className="flex flex-col gap-4">
      {/* Search & Filter Bar */}
      <div className="flex flex-col gap-3">
        <div className="flex items-center gap-3">
          <div className="relative flex-1">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
            <input
              className="w-full bg-slate-800 border border-slate-700 rounded-lg pl-9 pr-4 py-2 text-sm text-slate-100
                placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500"
              placeholder="Search by reference, BIC, UETR, message ID..."
              value={filters.query}
              onChange={e => setFilter('query', e.target.value)}
            />
          </div>
          <button
            onClick={() => setShowFilters(f => !f)}
            className={`flex items-center gap-2 px-3 py-2 rounded-lg border text-sm font-medium transition-all cursor-pointer
              ${showFilters
                ? 'bg-blue-900/40 border-blue-600 text-blue-300'
                : 'bg-slate-800 border-slate-700 text-slate-400 hover:border-slate-600'}`}
          >
            <Filter size={14} />
            Filters
            {activeFilterCount > 0 && (
              <span className="bg-blue-600 text-white text-[10px] rounded-full w-4 h-4 flex items-center justify-center">
                {activeFilterCount}
              </span>
            )}
            <ChevronDown size={12} className={`transition-transform ${showFilters ? 'rotate-180' : ''}`} />
          </button>
          {activeFilterCount > 0 && (
            <button onClick={clearFilters} className="text-slate-500 hover:text-slate-300 transition-colors cursor-pointer">
              <X size={14} />
            </button>
          )}
        </div>

        {showFilters && (
          <div className="bg-slate-800/60 border border-slate-700 rounded-xl p-4 grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
            <div className="flex flex-col gap-1">
              <label className="text-[10px] text-slate-500 uppercase tracking-wider">Message Type</label>
              <select
                className="bg-slate-800 border border-slate-700 rounded-lg px-2 py-1.5 text-xs text-slate-200 focus:outline-none focus:ring-1 focus:ring-blue-500"
                value={filters.messageType}
                onChange={e => setFilter('messageType', e.target.value as MTMessageType | '')}
              >
                {MSG_TYPE_OPTIONS.map(o => (
                  <option key={o.value} value={o.value} className="bg-slate-800">{o.label}</option>
                ))}
              </select>
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-[10px] text-slate-500 uppercase tracking-wider">Bank / BIC</label>
              <input
                className="bg-slate-800 border border-slate-700 rounded-lg px-2 py-1.5 text-xs text-slate-200 focus:outline-none focus:ring-1 focus:ring-blue-500"
                placeholder="e.g. CHASUS33"
                value={filters.bank}
                onChange={e => setFilter('bank', e.target.value)}
              />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-[10px] text-slate-500 uppercase tracking-wider">Date From</label>
              <input
                type="date"
                className="bg-slate-800 border border-slate-700 rounded-lg px-2 py-1.5 text-xs text-slate-200 focus:outline-none focus:ring-1 focus:ring-blue-500"
                value={filters.dateFrom}
                onChange={e => setFilter('dateFrom', e.target.value)}
              />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-[10px] text-slate-500 uppercase tracking-wider">Date To</label>
              <input
                type="date"
                className="bg-slate-800 border border-slate-700 rounded-lg px-2 py-1.5 text-xs text-slate-200 focus:outline-none focus:ring-1 focus:ring-blue-500"
                value={filters.dateTo}
                onChange={e => setFilter('dateTo', e.target.value)}
              />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-[10px] text-slate-500 uppercase tracking-wider">Status</label>
              <select
                className="bg-slate-800 border border-slate-700 rounded-lg px-2 py-1.5 text-xs text-slate-200 focus:outline-none focus:ring-1 focus:ring-blue-500"
                value={filters.status}
                onChange={e => setFilter('status', e.target.value as 'draft' | 'final' | '')}
              >
                <option value="" className="bg-slate-800">All</option>
                <option value="draft" className="bg-slate-800">Draft</option>
                <option value="final" className="bg-slate-800">Final</option>
              </select>
            </div>
          </div>
        )}
      </div>

      {/* Results Summary */}
      <div className="flex items-center justify-between">
        <p className="text-xs text-slate-500">
          {sorted.length} message{sorted.length !== 1 ? 's' : ''} found
          {messages.length !== sorted.length && ` (of ${messages.length} total)`}
        </p>
        <div className="flex items-center gap-2">
          <span className="text-[10px] text-slate-600 uppercase tracking-wide">Sort by:</span>
          {(['createdAt', 'messageType', 'senderBIC'] as SortKey[]).map(k => (
            <button
              key={k}
              onClick={() => toggleSort(k)}
              className="flex items-center gap-1 text-xs text-slate-500 hover:text-slate-300 transition-colors cursor-pointer"
            >
              {k === 'createdAt' ? 'Date' : k === 'messageType' ? 'Type' : 'Sender'}
              <SortIcon k={k} />
            </button>
          ))}
        </div>
      </div>

      {/* Message List */}
      {sorted.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 gap-4">
          <div className="w-16 h-16 rounded-2xl bg-slate-800 border border-slate-700 flex items-center justify-center">
            <Clock size={24} className="text-slate-600" />
          </div>
          <div className="text-center">
            <p className="text-sm font-medium text-slate-400">No messages found</p>
            <p className="text-xs text-slate-600 mt-1">
              {messages.length === 0 ? 'Compose your first SWIFT message to get started.' : 'Try adjusting your search or filters.'}
            </p>
          </div>
        </div>
      ) : (
        <div className="space-y-2">
          {sorted.map(msg => (
            <div
              key={msg.id}
              className="bg-slate-800/60 border border-slate-700 hover:border-slate-600 rounded-xl p-4 
                transition-all duration-150 group"
            >
              <div className="flex items-start gap-3">
                {/* Type Badge */}
                <div className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg border text-xs font-mono font-semibold flex-shrink-0 ${MT_COLORS[msg.messageType]}`}>
                  {MT_ICONS[msg.messageType]}
                  {msg.messageType}
                </div>

                {/* Info */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-sm font-mono font-semibold text-white truncate">
                      {msg.identifiers.transactionRef}
                    </span>
                    <Badge variant={msg.status === 'final' ? 'success' : 'warning'}>
                      {msg.status}
                    </Badge>
                    {msg.description && (
                      <span className="text-xs text-slate-500 truncate max-w-[200px]">{msg.description}</span>
                    )}
                  </div>

                   <div className="flex items-center gap-3 mt-1.5 flex-wrap">
                     <RouteMeta label="Sender" value={msg.block1?.logicalTerminalAddress ?? msg.senderBIC} />
                     <span className="text-slate-700 font-mono text-[10px]">→</span>
                     <RouteMeta label="Recv" value={msg.block2?.receiverAddress ?? msg.receiverBIC} />
                     <span className="text-[10px] text-slate-600 flex items-center gap-1">
                       <Clock size={10} />
                       {new Date(msg.createdAt).toLocaleString()}
                     </span>
                   </div>

                   <div className="flex items-center gap-3 mt-1.5 flex-wrap">
                     <span className="text-[10px] font-mono text-slate-600">
                       UETR: {msg.identifiers.uetr.slice(0, 23)}…
                     </span>
                     {msg.block1 && (
                       <span className="text-[10px] font-mono text-slate-600">
                         Session: {msg.block1.sessionNumber}/{msg.block1.sequenceNumber}
                       </span>
                     )}
                   </div>
                </div>

                {/* Actions */}
                <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0">
                  <button
                    onClick={() => setViewMsg(msg)}
                    className="w-8 h-8 flex items-center justify-center rounded-lg bg-slate-700 hover:bg-blue-800 text-slate-400 hover:text-blue-300 transition-all cursor-pointer"
                    title="View"
                  >
                    <Eye size={13} />
                  </button>
                  <button
                    onClick={() => handleExport(msg)}
                    className="w-8 h-8 flex items-center justify-center rounded-lg bg-slate-700 hover:bg-slate-600 text-slate-400 hover:text-slate-200 transition-all cursor-pointer"
                    title="Export PDF"
                  >
                    {exporting === msg.id ? (
                      <svg className="animate-spin h-3 w-3" viewBox="0 0 24 24" fill="none">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.4 0 0 5.4 0 12h4z" />
                      </svg>
                    ) : <Download size={13} />}
                  </button>
                  <button
                    onClick={() => onEdit(msg)}
                    className="w-8 h-8 flex items-center justify-center rounded-lg bg-slate-700 hover:bg-amber-900 text-slate-400 hover:text-amber-300 transition-all cursor-pointer"
                    title="Edit"
                  >
                    <Edit2 size={13} />
                  </button>
                  <button
                    onClick={() => setDeleteId(msg.id)}
                    className="w-8 h-8 flex items-center justify-center rounded-lg bg-slate-700 hover:bg-red-900 text-slate-400 hover:text-red-300 transition-all cursor-pointer"
                    title="Delete"
                  >
                    <Trash2 size={13} />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* View Modal */}
      <Modal
        open={!!viewMsg}
        onClose={() => setViewMsg(null)}
        size="2xl"
        title={viewMsg ? `${viewMsg.messageType} — Message Viewer` : ''}
        subtitle={viewMsg ? `Ref: ${viewMsg.identifiers.transactionRef}` : ''}
      >
        {viewMsg && (
          <MessageViewer
            message={viewMsg}
            onEdit={() => { onEdit(viewMsg); setViewMsg(null); }}
            onDelete={() => { setDeleteId(viewMsg.id); setViewMsg(null); }}
          />
        )}
      </Modal>

      {/* Delete Confirmation Modal */}
      <Modal
        open={!!deleteId}
        onClose={() => setDeleteId(null)}
        title="Delete Message"
        subtitle="This action cannot be undone."
        size="sm"
        footer={
          <>
            <Button variant="ghost" size="sm" onClick={() => setDeleteId(null)}>Cancel</Button>
            <Button variant="danger" size="sm" onClick={() => deleteId && handleDelete(deleteId)}>
              Delete
            </Button>
          </>
        }
      >
        <p className="text-sm text-slate-400">
          Are you sure you want to permanently delete this SWIFT message?
          All associated data including identifiers will be removed.
        </p>
      </Modal>
    </div>
  );
};

const RouteMeta: React.FC<{ label: string; value: string }> = ({ label, value }) => (
  <span className="text-xs text-slate-500">
    <span className="text-slate-600">{label}: </span>
    <span className="font-mono text-slate-300">{value}</span>
  </span>
);
