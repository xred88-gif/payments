import React, { useState, useRef, useEffect, useMemo } from 'react';
import { ChevronDown, Search, X } from 'lucide-react';
import { CURRENCIES, CURRENCY_GROUPS, getCurrency } from '../../utils/currencies';

interface CurrencyPickerProps {
  label?: string;
  value: string;            // ISO 4217 code e.g. "USD"
  onChange: (code: string) => void;
  hint?: string;
  required?: boolean;
  showSymbol?: boolean;
}

export const CurrencyPicker: React.FC<CurrencyPickerProps> = ({
  label, value, onChange, hint, required, showSymbol = true,
}) => {
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState('');
  const [activeGroup, setActiveGroup] = useState<string>('All');
  const ref = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const selected = getCurrency(value);

  useEffect(() => {
    const h = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', h);
    return () => document.removeEventListener('mousedown', h);
  }, []);

  useEffect(() => {
    if (open) setTimeout(() => inputRef.current?.focus(), 50);
  }, [open]);

  const filtered = useMemo(() => {
    let list = CURRENCIES;
    if (activeGroup !== 'All') {
      const grp = CURRENCY_GROUPS.find(g => g.label === activeGroup);
      if (grp) list = list.filter(c => grp.codes.includes(c.code));
    }
    if (q) {
      const ql = q.toLowerCase();
      list = list.filter(c =>
        c.code.toLowerCase().includes(ql) ||
        c.name.toLowerCase().includes(ql) ||
        c.country.toLowerCase().includes(ql)
      );
    }
    return list;
  }, [q, activeGroup]);

  const allGroups = ['All', ...CURRENCY_GROUPS.map(g => g.label)];

  return (
    <div className="relative" ref={ref}>
      <label className="block text-xs font-medium text-slate-400 mb-1">
        {label}{required && <span className="text-[#F7941D] ml-0.5">*</span>}
      </label>

      <button
        type="button"
        onClick={() => setOpen(o => !o)}
        className="w-full flex items-center justify-between bg-slate-800 border border-slate-700 rounded-lg
          px-3 py-2 text-sm transition-all focus:outline-none hover:border-slate-500
          focus:border-[#F7941D] focus:ring-1 focus:ring-[#F7941D]/30 cursor-pointer"
      >
        {selected ? (
          <div className="flex items-center gap-2">
            <span className="text-base leading-none">{selected.flag}</span>
            <span className="font-mono font-bold text-white text-sm">{selected.code}</span>
            {showSymbol && (
              <span className="text-slate-400 text-xs bg-slate-700 px-1.5 py-0.5 rounded font-mono">
                {selected.symbol}
              </span>
            )}
            <span className="text-slate-400 text-xs hidden sm:block truncate max-w-[120px]">{selected.name}</span>
          </div>
        ) : (
          <span className="text-slate-500 text-sm">Select currency…</span>
        )}
        <div className="flex items-center gap-1 flex-shrink-0">
          {value && (
            <span
              role="button"
              onClick={e => { e.stopPropagation(); onChange(''); }}
              className="text-slate-600 hover:text-slate-400 cursor-pointer"
            >
              <X size={12} />
            </span>
          )}
          <ChevronDown size={13} className={`text-slate-500 transition-transform ${open ? 'rotate-180' : ''}`} />
        </div>
      </button>

      {hint && <p className="text-[10px] text-slate-600 mt-1">{hint}</p>}

      {open && (
        <div className="absolute z-[100] top-full mt-2 left-0 w-80 bg-[#0d1117] border border-slate-600
          rounded-2xl shadow-2xl shadow-black/60 overflow-hidden">

          {/* Search */}
          <div className="p-2 border-b border-slate-700">
            <div className="flex items-center gap-2 bg-slate-800 rounded-xl px-3 py-2">
              <Search size={13} className="text-slate-500 flex-shrink-0" />
              <input
                ref={inputRef}
                className="flex-1 bg-transparent text-sm text-white placeholder-slate-500 outline-none"
                placeholder="Search code, name, country…"
                value={q}
                onChange={e => setQ(e.target.value)}
              />
              {q && (
                <button type="button" onClick={() => setQ('')} className="text-slate-500 hover:text-slate-300 cursor-pointer">
                  <X size={11} />
                </button>
              )}
            </div>
          </div>

          {/* Group tabs */}
          <div className="flex gap-1 px-2 py-2 overflow-x-auto border-b border-slate-700 scrollbar-none">
            {allGroups.map(g => (
              <button
                key={g}
                type="button"
                onClick={() => setActiveGroup(g)}
                className={`flex-shrink-0 text-[9px] px-2 py-1 rounded-lg font-semibold uppercase tracking-wide transition cursor-pointer
                  ${activeGroup === g
                    ? 'bg-[#F7941D] text-white'
                    : 'bg-slate-800 text-slate-400 hover:bg-slate-700 hover:text-white'}`}
              >
                {g === 'All' ? 'All' : g.split(' ')[0]}
              </button>
            ))}
          </div>

          {/* Currency list */}
          <div className="max-h-60 overflow-y-auto">
            {filtered.length === 0 ? (
              <div className="px-4 py-6 text-center text-xs text-slate-500">No currencies match</div>
            ) : (
              filtered.map(cur => (
                <button
                  key={cur.code}
                  type="button"
                  onClick={() => { onChange(cur.code); setOpen(false); setQ(''); }}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 hover:bg-slate-800/80 transition-colors cursor-pointer text-left
                    ${value === cur.code ? 'bg-[#F7941D]/10 border-l-2 border-[#F7941D]' : ''}`}
                >
                  <span className="text-lg leading-none w-6 flex-shrink-0">{cur.flag}</span>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-white text-sm">{cur.code}</span>
                      <span className="text-slate-500 text-[10px] bg-slate-800 px-1.5 py-0.5 rounded font-mono">{cur.symbol}</span>
                      {cur.decimals === 3 && (
                        <span className="text-[9px] text-amber-500 bg-amber-950/40 px-1 py-0.5 rounded">3dp</span>
                      )}
                      {cur.decimals === 0 && (
                        <span className="text-[9px] text-purple-400 bg-purple-950/40 px-1 py-0.5 rounded">0dp</span>
                      )}
                    </div>
                    <p className="text-[10px] text-slate-500 truncate">{cur.name}</p>
                  </div>
                  <span className="text-[9px] text-slate-600 font-mono flex-shrink-0">{cur.country.slice(0,12)}</span>
                </button>
              ))
            )}
          </div>

          {/* Footer */}
          <div className="border-t border-slate-700 px-3 py-1.5">
            <p className="text-[9px] text-slate-600 text-center">ISO 4217 · {CURRENCIES.length} currencies</p>
          </div>
        </div>
      )}
    </div>
  );
};

/** Inline currency+amount field combo */
interface AmountFieldProps {
  label: string;
  amountValue: string;
  currencyValue: string;
  onAmountChange: (v: string) => void;
  onCurrencyChange: (v: string) => void;
  hint?: string;
  required?: boolean;
  swiftFormat?: boolean; // true = show comma-decimal SWIFT format preview
}

export const AmountWithCurrency: React.FC<AmountFieldProps> = ({
  label, amountValue, currencyValue, onAmountChange, onCurrencyChange,
  hint, required, swiftFormat = false,
}) => {
  const cur = getCurrency(currencyValue);

  // Parse the combined SWIFT :32B: field like "USD1000000,00"
  const parsedAmount = amountValue.replace(/,/g, '.');
  const numVal = parseFloat(parsedAmount);

  const swiftPreview = !isNaN(numVal) && currencyValue
    ? `${currencyValue}${numVal.toFixed(cur?.decimals ?? 2).replace('.', ',')}`
    : '';

  return (
    <div className="space-y-1">
      <label className="block text-xs font-medium text-slate-400">
        {label}{required && <span className="text-[#F7941D] ml-0.5">*</span>}
      </label>
      <div className="flex gap-2">
        {/* Amount input */}
        <input
          type="text"
          value={amountValue}
          onChange={e => onAmountChange(e.target.value)}
          placeholder="1000000.00"
          className="flex-1 bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm font-mono
            text-white placeholder-slate-600 focus:outline-none focus:border-[#F7941D]
            focus:ring-1 focus:ring-[#F7941D]/30 transition-all"
        />
        {/* Currency picker inline */}
        <div className="w-36">
          <CurrencyPicker
            label=""
            value={currencyValue}
            onChange={onCurrencyChange}
            showSymbol={false}
          />
        </div>
      </div>
      {swiftFormat && swiftPreview && (
        <p className="text-[10px] text-emerald-400 font-mono">
          SWIFT format: <span className="text-white">{swiftPreview}</span>
        </p>
      )}
      {hint && <p className="text-[10px] text-slate-600">{hint}</p>}
    </div>
  );
};
