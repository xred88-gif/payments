/**
 * DateTimePicker — combined date + time picker for ISO 20022 datetime fields
 * Outputs: YYYY-MM-DDTHH:MM:SS or YYYY-MM-DD depending on mode
 */
import React from 'react';
import { DatePicker } from './DatePicker';
import { TimePicker } from './TimePicker';

interface DateTimePickerProps {
  label?: string;
  name: string;
  fields: Record<string, string>;
  onChange: (f: Record<string, string>) => void;
  dateOnly?: boolean;   // if true, only show date picker
  required?: boolean;
  hint?: string;
}

export const DateTimePicker: React.FC<DateTimePickerProps> = ({
  label, name, fields, onChange, dateOnly = false, required, hint,
}) => {
  // Split stored value into date + time parts
  const stored = fields[name] ?? '';
  const hasT = stored.includes('T');
  const datePart = hasT ? stored.split('T')[0] : stored.split(' ')[0] ?? stored;
  const timePart = hasT ? stored.split('T')[1]?.slice(0, 8) ?? '' : stored.split(' ')[1] ?? '';

  const labelCls = 'block text-xs font-semibold text-gray-600 mb-1 uppercase tracking-wide';

  const handleDateChange = (newDate: string) => {
    if (dateOnly) {
      onChange({ ...fields, [name]: newDate });
    } else {
      const t = timePart || '00:00:00';
      onChange({ ...fields, [name]: newDate ? `${newDate}T${t}` : '' });
    }
  };

  const handleTimeChange = (newTime: string) => {
    const d = datePart || new Date().toISOString().slice(0, 10);
    onChange({ ...fields, [name]: newTime ? `${d}T${newTime}` : d });
  };

  return (
    <div>
      {label && (
        <label className={labelCls}>
          {label}{required && <span className="text-orange-500 ml-0.5">*</span>}
        </label>
      )}
      <div className={`flex gap-2 ${dateOnly ? '' : 'items-start'}`}>
        <div className={dateOnly ? 'w-full' : 'flex-1'}>
          <DatePicker
            value={datePart}
            onChange={handleDateChange}
            format="ISO"
          />
        </div>
        {!dateOnly && (
          <div className="w-40">
            <TimePicker
              value={timePart}
              onChange={handleTimeChange}
              seconds={true}
            />
          </div>
        )}
      </div>
      {hint && <p className="text-[10px] text-gray-400 mt-0.5">{hint}</p>}
      {/* Show combined value */}
      {stored && (
        <p className="text-[10px] font-mono text-green-600 mt-0.5">
          {stored}
        </p>
      )}
    </div>
  );
};
