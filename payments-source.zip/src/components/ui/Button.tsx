import React from 'react';
import { cn } from '../../utils/cn';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger' | 'success' | 'outline';
  size?: 'xs' | 'sm' | 'md' | 'lg';
  loading?: boolean;
  icon?: React.ReactNode;
  iconRight?: React.ReactNode;
}

const variants = {
  primary:   'bg-blue-600 hover:bg-blue-500 text-white border border-blue-500 shadow-sm shadow-blue-900/30',
  secondary: 'bg-slate-700 hover:bg-slate-600 text-slate-100 border border-slate-600',
  ghost:     'bg-transparent hover:bg-slate-800 text-slate-300 hover:text-white border border-transparent',
  danger:    'bg-red-900/60 hover:bg-red-800 text-red-300 hover:text-red-100 border border-red-700/50',
  success:   'bg-emerald-800/60 hover:bg-emerald-700 text-emerald-300 border border-emerald-700/50',
  outline:   'bg-transparent hover:bg-slate-800 text-slate-300 border border-slate-600 hover:border-slate-500',
};

const sizes = {
  xs: 'text-xs px-2 py-1 gap-1',
  sm: 'text-xs px-3 py-1.5 gap-1.5',
  md: 'text-sm px-4 py-2 gap-2',
  lg: 'text-sm px-5 py-2.5 gap-2',
};

export const Button: React.FC<ButtonProps> = ({
  variant = 'secondary',
  size = 'md',
  loading,
  icon,
  iconRight,
  children,
  className,
  disabled,
  ...props
}) => (
  <button
    {...props}
    disabled={disabled || loading}
    className={cn(
      'inline-flex items-center justify-center font-medium rounded-lg transition-all duration-150 cursor-pointer select-none',
      'focus:outline-none focus:ring-2 focus:ring-blue-500/40 focus:ring-offset-1 focus:ring-offset-slate-900',
      'disabled:opacity-50 disabled:cursor-not-allowed',
      variants[variant],
      sizes[size],
      className
    )}
  >
    {loading ? (
      <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24" fill="none">
        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.4 0 0 5.4 0 12h4z" />
      </svg>
    ) : icon}
    {children}
    {iconRight}
  </button>
);
