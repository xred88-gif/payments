import React from 'react';
import { cn } from '../../utils/cn';

interface BadgeProps {
  children: React.ReactNode;
  variant?: 'default' | 'success' | 'warning' | 'danger' | 'info' | 'outline';
  size?: 'sm' | 'md';
  className?: string;
}

const variants = {
  default:  'bg-slate-800 text-slate-200 border border-slate-700',
  success:  'bg-emerald-900/60 text-emerald-300 border border-emerald-700/50',
  warning:  'bg-amber-900/60  text-amber-300  border border-amber-700/50',
  danger:   'bg-red-900/60    text-red-300    border border-red-700/50',
  info:     'bg-blue-900/60   text-blue-300   border border-blue-700/50',
  outline:  'bg-transparent   text-slate-300  border border-slate-600',
};

export const Badge: React.FC<BadgeProps> = ({ children, variant = 'default', size = 'sm', className }) => (
  <span className={cn(
    'inline-flex items-center font-mono font-semibold rounded tracking-wide',
    size === 'sm' ? 'text-[10px] px-1.5 py-0.5' : 'text-xs px-2 py-1',
    variants[variant],
    className
  )}>
    {children}
  </span>
);
