import React, { useEffect, useState } from 'react';
import { Clock, MapPin, Globe } from 'lucide-react';
import { getTimezoneFromBIC, TimezoneInfo } from '../../utils/timezones';

interface TimezoneDisplayProps {
  bic: string;
  label?: string;
  compact?: boolean;
}

export const TimezoneDisplay: React.FC<TimezoneDisplayProps> = ({
  bic, label = 'Instructing Agent Local Time', compact = false,
}) => {
  const [info, setInfo] = useState<TimezoneInfo | null>(null);
  const [tick, setTick] = useState(0);

  useEffect(() => {
    if (!bic || bic.length < 6) { setInfo(null); return; }
    setInfo(getTimezoneFromBIC(bic));
  }, [bic, tick]);

  // Live clock tick every 10s
  useEffect(() => {
    const t = setInterval(() => setTick(n => n + 1), 10000);
    return () => clearInterval(t);
  }, []);

  if (!info) {
    return (
      <div className="flex items-center gap-2 px-3 py-2 bg-slate-800/40 border border-slate-700/40 rounded-lg">
        <Globe size={12} className="text-slate-600" />
        <span className="text-xs text-slate-600">Enter a BIC to detect timezone</span>
      </div>
    );
  }

  if (compact) {
    return (
      <div className="flex items-center gap-2 px-3 py-1.5 bg-[#001A3A]/60 border border-blue-900/40 rounded-lg">
        <span className="text-sm">{info.flag}</span>
        <div>
          <span className="text-xs font-mono font-semibold text-blue-300">{info.currentTime}</span>
          <span className="text-[10px] text-slate-500 ml-1.5">{info.city} ({info.utcOffset})</span>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-[#0a1628] border border-blue-900/40 rounded-xl overflow-hidden">
      {/* Header */}
      <div className="flex items-center gap-2 px-4 py-2.5 bg-[#001A3A]/80 border-b border-blue-900/30">
        <Clock size={13} className="text-[#F7941D]" />
        <span className="text-xs font-semibold text-slate-300">{label}</span>
      </div>

      <div className="px-4 py-3 grid grid-cols-1 sm:grid-cols-3 gap-3">
        {/* Location */}
        <div className="flex items-start gap-2.5">
          <div className="w-7 h-7 rounded-lg bg-slate-800 flex items-center justify-center flex-shrink-0">
            <MapPin size={13} className="text-[#F7941D]" />
          </div>
          <div>
            <p className="text-[10px] text-slate-500 uppercase tracking-wider mb-0.5">Location</p>
            <p className="text-sm font-semibold text-white flex items-center gap-1.5">
              <span>{info.flag}</span>
              {info.city}
            </p>
            <p className="text-[10px] text-slate-500">{info.country}</p>
          </div>
        </div>

        {/* Current Time */}
        <div className="flex items-start gap-2.5">
          <div className="w-7 h-7 rounded-lg bg-slate-800 flex items-center justify-center flex-shrink-0">
            <Clock size={13} className="text-blue-400" />
          </div>
          <div>
            <p className="text-[10px] text-slate-500 uppercase tracking-wider mb-0.5">Local Time Now</p>
            <p className="text-xl font-bold text-white font-mono tracking-wider">{info.currentTime}</p>
            <p className="text-[10px] text-slate-500">{info.timezone}</p>
          </div>
        </div>

        {/* UTC Offset */}
        <div className="flex items-start gap-2.5">
          <div className="w-7 h-7 rounded-lg bg-slate-800 flex items-center justify-center flex-shrink-0">
            <Globe size={13} className="text-emerald-400" />
          </div>
          <div>
            <p className="text-[10px] text-slate-500 uppercase tracking-wider mb-0.5">UTC Offset</p>
            <p className="text-lg font-bold font-mono text-emerald-400">{info.utcOffset}</p>
            <p className="text-[10px] text-slate-500 font-mono">{info.localDateTime.slice(0, 16)}</p>
          </div>
        </div>
      </div>

      {/* BIC indicator */}
      <div className="px-4 py-2 border-t border-blue-900/20 bg-slate-900/30">
        <div className="flex items-center gap-2">
          <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-[10px] text-slate-500">
            Timezone resolved from BIC country code{' '}
            <span className="font-mono text-blue-400 font-bold">{bic.slice(4,6).toUpperCase()}</span>
            {' '}→ <span className="font-mono text-slate-400">{info.timezone}</span>
          </span>
        </div>
      </div>
    </div>
  );
};
