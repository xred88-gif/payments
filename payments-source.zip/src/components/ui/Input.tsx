import React from 'react';
import { cn } from '../../utils/cn';

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  hint?: string;
  error?: string;
  mono?: boolean;
}

export const Input: React.FC<InputProps> = ({ label, hint, error, mono, className, ...props }) => (
  <div className="flex flex-col gap-1">
    {label && (
      <label className="text-xs font-medium text-slate-400 uppercase tracking-wider">{label}</label>
    )}
    <input
      {...props}
      className={cn(
        'bg-slate-800 border rounded-lg px-3 py-2 text-sm transition-colors',
        'placeholder:text-slate-600 text-slate-100',
        'focus:outline-none focus:ring-2 focus:ring-blue-500/40 focus:border-blue-500',
        error
          ? 'border-red-500/60 focus:border-red-500'
          : 'border-slate-700 hover:border-slate-600',
        mono && 'font-mono',
        className
      )}
    />
    {hint && !error && <p className="text-xs text-slate-500">{hint}</p>}
    {error && <p className="text-xs text-red-400">{error}</p>}
  </div>
);

interface TextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string;
  hint?: string;
  error?: string;
  mono?: boolean;
}

export const Textarea: React.FC<TextareaProps> = ({ label, hint, error, mono, className, ...props }) => (
  <div className="flex flex-col gap-1">
    {label && (
      <label className="text-xs font-medium text-slate-400 uppercase tracking-wider">{label}</label>
    )}
    <textarea
      {...props}
      className={cn(
        'bg-slate-800 border rounded-lg px-3 py-2 text-sm transition-colors resize-y min-h-[80px]',
        'placeholder:text-slate-600 text-slate-100',
        'focus:outline-none focus:ring-2 focus:ring-blue-500/40 focus:border-blue-500',
        error
          ? 'border-red-500/60 focus:border-red-500'
          : 'border-slate-700 hover:border-slate-600',
        mono && 'font-mono text-xs',
        className
      )}
    />
    {hint && !error && <p className="text-xs text-slate-500">{hint}</p>}
    {error && <p className="text-xs text-red-400">{error}</p>}
  </div>
);

interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  label?: string;
  hint?: string;
  error?: string;
  options: { value: string; label: string }[];
}

export const Select: React.FC<SelectProps> = ({ label, hint, error, options, className, ...props }) => (
  <div className="flex flex-col gap-1">
    {label && (
      <label className="text-xs font-medium text-slate-400 uppercase tracking-wider">{label}</label>
    )}
    <select
      {...props}
      className={cn(
        'bg-slate-800 border rounded-lg px-3 py-2 text-sm transition-colors',
        'text-slate-100',
        'focus:outline-none focus:ring-2 focus:ring-blue-500/40 focus:border-blue-500',
        error
          ? 'border-red-500/60'
          : 'border-slate-700 hover:border-slate-600',
        className
      )}
    >
      {options.map(opt => (
        <option key={opt.value} value={opt.value} className="bg-slate-800">
          {opt.label}
        </option>
      ))}
    </select>
    {hint && !error && <p className="text-xs text-slate-500">{hint}</p>}
    {error && <p className="text-xs text-red-400">{error}</p>}
  </div>
);
