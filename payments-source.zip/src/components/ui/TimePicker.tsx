/**
 * TimePicker — HH:MM:SS selector with scroll wheels
 */
import React, { useState, useRef, useEffect } from 'react';
import { Clock, X, ChevronUp, ChevronDown } from 'lucide-react';

interface TimePickerProps {
  label?: string;
  value: string;        // HH:MM:SS or HH:MM
  onChange: (v: string) => void;
  seconds?: boolean;    // include seconds (default true)
  hint?: string;
  required?: boolean;
}

function pad(n: number): string {
  return String(n).padStart(2, '0');
}

function parseTime(val: string): { h: number; m: number; s: number } {
  const parts = val.split(':').map(Number);
  return {
    h: isNaN(parts[0]) ? 0 : Math.min(23, Math.max(0, parts[0])),
    m: isNaN(parts[1]) ? 0 : Math.min(59, Math.max(0, parts[1])),
    s: isNaN(parts[2]) ? 0 : Math.min(59, Math.max(0, parts[2])),
  };
}

function Wheel({ value, min, max, onChange, label }: {
  value: number; min: number; max: number;
  onChange: (v: number) => void; label: string;
}) {
  const inc = () => onChange(value >= max ? min : value + 1);
  const dec = () => onChange(value <= min ? max : value - 1);

  return (
    <div className="flex flex-col items-center select-none">
      <span className="text-[9px] font-bold text-gray-400 uppercase mb-1">{label}</span>
      <button
        type="button"
        onClick={inc}
        className="w-8 h-6 flex items-center justify-center text-gray-400 hover:text-orange-500 hover:bg-orange-50 rounded transition cursor-pointer"
      >
        <ChevronUp size={14} />
      </button>
      <div className="w-12 h-9 flex items-center justify-center bg-white border-2 border-orange-400 rounded-lg">
        <span className="text-base font-mono font-bold text-gray-900">{pad(value)}</span>
      </div>
      <button
        type="button"
        onClick={dec}
        className="w-8 h-6 flex items-center justify-center text-gray-400 hover:text-orange-500 hover:bg-orange-50 rounded transition cursor-pointer"
      >
        <ChevronDown size={14} />
      </button>
    </div>
  );
}

export const TimePicker: React.FC<TimePickerProps> = ({
  label, value, onChange, seconds = true, hint, required,
}) => {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const { h, m, s } = parseTime(value);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const emit = (nh: number, nm: number, ns: number) => {
    onChange(seconds ? `${pad(nh)}:${pad(nm)}:${pad(ns)}` : `${pad(nh)}:${pad(nm)}`);
  };

  const setNow = () => {
    const d = new Date();
    emit(d.getHours(), d.getMinutes(), d.getSeconds());
    setOpen(false);
  };

  const presets: { label: string; h: number; m: number }[] = [
    { label: '09:00', h: 9,  m: 0  },
    { label: '12:00', h: 12, m: 0  },
    { label: '14:00', h: 14, m: 0  },
    { label: '16:00', h: 16, m: 0  },
    { label: '18:00', h: 18, m: 0  },
  ];

  const labelCls = 'block text-xs font-semibold text-gray-600 mb-1 uppercase tracking-wide';
  const displayed = value || '--:--' + (seconds ? ':--' : '');

  return (
    <div className="relative" ref={ref}>
      {label && (
        <label className={labelCls}>
          {label}{required && <span className="text-orange-500 ml-0.5">*</span>}
        </label>
      )}

      {/* Trigger */}
      <button
        type="button"
        onClick={() => setOpen(o => !o)}
        className={
          `w-full flex items-center justify-between bg-white border rounded px-3 py-2 text-sm ` +
          `text-left transition-all focus:outline-none cursor-pointer ` +
          `${open ? 'border-orange-500 ring-1 ring-orange-400' : 'border-gray-300 hover:border-gray-400'}`
        }
      >
        <div className="flex items-center gap-2">
          <Clock size={14} className="text-orange-500 flex-shrink-0" />
          <span className={`font-mono text-sm ${value ? 'text-gray-900' : 'text-gray-400'}`}>
            {displayed}
          </span>
        </div>
        {value && (
          <span
            role="button"
            onClick={e => { e.stopPropagation(); onChange(''); }}
            className="text-gray-400 hover:text-gray-600 cursor-pointer"
          >
            <X size={12} />
          </span>
        )}
      </button>

      {hint && <p className="text-[10px] text-gray-400 mt-0.5">{hint}</p>}

      {/* Dropdown */}
      {open && (
        <div className="absolute z-[200] top-full mt-2 left-0 w-64 bg-white border border-gray-200 rounded-xl shadow-xl overflow-hidden">
          {/* Header */}
          <div className="flex items-center gap-2 px-4 py-2 bg-gray-50 border-b border-gray-200">
            <Clock size={13} className="text-orange-500" />
            <span className="text-xs font-bold text-gray-600 uppercase tracking-wide">Select Time</span>
          </div>

          {/* Wheels */}
          <div className="flex items-center justify-center gap-3 px-4 py-4">
            <Wheel value={h} min={0} max={23} label="HH" onChange={nh => emit(nh, m, s)} />
            <span className="text-2xl font-bold text-gray-300 mt-3">:</span>
            <Wheel value={m} min={0} max={59} label="MM" onChange={nm => emit(h, nm, s)} />
            {seconds && (
              <>
                <span className="text-2xl font-bold text-gray-300 mt-3">:</span>
                <Wheel value={s} min={0} max={59} label="SS" onChange={ns => emit(h, m, ns)} />
              </>
            )}
          </div>

          {/* Live display */}
          <div className="text-center pb-1">
            <span className="text-xl font-mono font-bold text-orange-500">
              {pad(h)}:{pad(m)}{seconds ? `:${pad(s)}` : ''}
            </span>
          </div>

          {/* Presets */}
          <div className="border-t border-gray-100 px-3 py-2">
            <p className="text-[9px] text-gray-400 font-semibold uppercase mb-2">Quick Presets</p>
            <div className="flex flex-wrap gap-1">
              <button
                type="button"
                onClick={setNow}
                className="text-[10px] px-2 py-1 rounded-lg bg-orange-50 border border-orange-200 text-orange-600 font-mono font-semibold hover:bg-orange-100 transition cursor-pointer"
              >
                Now
              </button>
              {presets.map(p => (
                <button
                  key={p.label}
                  type="button"
                  onClick={() => { emit(p.h, p.m, 0); setOpen(false); }}
                  className="text-[10px] px-2 py-1 rounded-lg bg-gray-50 border border-gray-200 text-gray-600 font-mono hover:bg-gray-100 transition cursor-pointer"
                >
                  {p.label}
                </button>
              ))}
            </div>
          </div>

          {/* Done button */}
          <div className="px-3 pb-3 pt-1">
            <button
              type="button"
              onClick={() => setOpen(false)}
              className="w-full py-1.5 rounded-lg bg-orange-500 text-white text-xs font-bold hover:bg-orange-600 transition cursor-pointer"
            >
              Done
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
