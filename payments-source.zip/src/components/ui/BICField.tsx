/**
 * BICField — ISO 9362 validated BIC / SWIFT code input
 *
 * • Strips spaces on type and paste — auto-uppercases
 * • Full ISO 9362 structure validation
 * • Auto-appends XXX branch code on blur (CHASUS33 → CHASUS33XXX)
 * • Auto-identifies bank name from directory (200+ banks)
 * • Fires onResolvedName(bankName) when a bank is matched — caller can
 *   auto-fill the adjacent "Agent Name" field
 * • Country / institution / branch breakdown chips
 * • Timezone display from country code
 * • Copy button · Test-BIC warning
 */
import React, { useState, useEffect } from 'react';
import {
  CheckCircle, XCircle, Copy, Check,
  Building2, MapPin, GitBranch, AlertTriangle, Info,
  Landmark, Globe2,
} from 'lucide-react';
import { validateBIC, normaliseBIC, formatBICDisplay, ensureXXX } from '../../utils/bicValidator';
import { lookupBIC, categoryColour } from '../../utils/bicDirectory';
import { TimezoneDisplay } from './TimezoneDisplay';

interface BICFieldProps {
  label: string;
  name: string;
  fields: Record<string, string>;
  onChange: (f: Record<string, string>) => void;
  /** Called with the resolved bank name whenever directory match is found */
  onResolvedName?: (name: string) => void;
  required?: boolean;
  hint?: string;
  showTz?: boolean;
  placeholder?: string;
}

export const BICField: React.FC<BICFieldProps> = ({
  label, name, fields, onChange,
  onResolvedName,
  required = false, hint, showTz = true,
  placeholder = 'e.g. CHASUS33XXX',
}) => {
  const [copied, setCopied]   = useState(false);
  const [touched, setTouched] = useState(false);

  const raw    = fields[name] ?? '';
  const result = raw.length >= 6 ? validateBIC(raw) : null;
  const bank   = raw.length >= 8 ? lookupBIC(raw)   : null;
  const showValidation = touched && raw.length >= 6;

  /* ── fire onResolvedName whenever bank changes ── */
  useEffect(() => {
    if (bank && onResolvedName) {
      onResolvedName(bank.shortName ?? bank.name);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [bank?.name]);

  /* ── handlers ── */
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const clean = normaliseBIC(e.target.value);
    onChange({ ...fields, [name]: clean });
    setTouched(true);
  };

  const handlePaste = (e: React.ClipboardEvent<HTMLInputElement>) => {
    e.preventDefault();
    const clean = normaliseBIC(e.clipboardData.getData('text'));
    onChange({ ...fields, [name]: clean });
    setTouched(true);
  };

  /* ── auto-append XXX on blur ── */
  const handleBlur = () => {
    setTouched(true);
    const current = fields[name] ?? '';
    if (current.length === 8) {
      const withXXX = ensureXXX(current);
      onChange({ ...fields, [name]: withXXX });
    }
  };

  const handleCopy = () => {
    if (raw) {
      navigator.clipboard.writeText(raw).catch(() => {});
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    }
  };

  /* ── border colour ── */
  let borderCls = 'border-gray-300 focus:border-orange-500 focus:ring-orange-400';
  if (showValidation && result) {
    borderCls = result.valid
      ? 'border-green-400 focus:border-green-500 focus:ring-green-400'
      : 'border-red-400  focus:border-red-500  focus:ring-red-400';
  }

  const labelCls = 'block text-xs font-semibold text-gray-600 mb-1 uppercase tracking-wide';

  return (
    <div>
      {/* ── label ── */}
      <label className={labelCls}>
        {label}
        {required && <span className="text-orange-500 ml-0.5">*</span>}
      </label>

      {/* ── input row ── */}
      <div className="relative">
        <input
          type="text"
          value={raw}
          onChange={handleChange}
          onPaste={handlePaste}
          onBlur={handleBlur}
          placeholder={placeholder}
          maxLength={11}
          spellCheck={false}
          className={
            `w-full bg-white border rounded px-3 py-2 pr-16 text-sm font-mono ` +
            `text-gray-900 uppercase tracking-wider ` +
            `focus:outline-none focus:ring-1 transition-colors ${borderCls}`
          }
        />

        {/* icons right side */}
        <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
          {showValidation && result && (
            result.valid
              ? <CheckCircle size={14} className="text-green-500" />
              : <XCircle    size={14} className="text-red-500"   />
          )}
          {raw && (
            <button
              type="button"
              onClick={handleCopy}
              className="text-gray-400 hover:text-orange-500 transition-colors"
              title="Copy BIC"
            >
              {copied ? <Check size={13} className="text-green-500" /> : <Copy size={13} />}
            </button>
          )}
        </div>
      </div>

      {/* ── XXX hint ── */}
      {raw.length === 8 && (
        <p className="text-xs text-blue-500 mt-0.5 flex items-center gap-1">
          <Info size={10} className="text-blue-400" />
          Will auto-expand to <span className="font-mono font-bold">{raw}XXX</span> on leaving the field
        </p>
      )}

      {/* ── BANK IDENTITY CARD ── */}
      {bank && result?.valid && (
        <div className="mt-1.5 bg-blue-50 border border-blue-200 rounded-lg p-2.5">
          {/* Bank name row */}
          <div className="flex items-start gap-2">
            <Landmark size={15} className="text-blue-600 mt-0.5 shrink-0" />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-bold text-blue-900 leading-tight">
                {bank.name}
              </p>
              {bank.shortName && bank.shortName !== bank.name && (
                <p className="text-xs text-blue-600 font-medium mt-0.5">
                  {bank.shortName}
                </p>
              )}
            </div>
            {/* Category badge */}
            <span className={`text-xs border rounded px-1.5 py-0.5 font-medium shrink-0 ${categoryColour(bank.category)}`}>
              {bank.category}
            </span>
          </div>

          {/* Location + currency row */}
          <div className="flex items-center gap-3 mt-2 pt-2 border-t border-blue-100">
            <div className="flex items-center gap-1 text-xs text-blue-700">
              <MapPin size={11} className="text-blue-500" />
              <span>{bank.city}</span>
            </div>
            <div className="flex items-center gap-1 text-xs text-blue-700">
              <Globe2 size={11} className="text-blue-500" />
              <span>{bank.country}</span>
              <span className="bg-blue-200 text-blue-800 font-mono font-bold rounded px-1 text-xs">
                {bank.countryCode}
              </span>
            </div>
            {bank.currency && (
              <div className="ml-auto bg-orange-100 text-orange-700 font-mono font-bold text-xs rounded px-1.5 py-0.5 border border-orange-200">
                {bank.currency}
              </div>
            )}
          </div>

          {/* Auto-filled notice */}
          {onResolvedName && (
            <p className="text-xs text-green-700 bg-green-50 border border-green-200 rounded px-2 py-0.5 mt-2 flex items-center gap-1">
              <CheckCircle size={10} className="text-green-500" />
              Agent name auto-filled from BIC directory
            </p>
          )}
        </div>
      )}

      {/* ── validation feedback ── */}
      {showValidation && result && (
        result.valid ? (
          <div className={`mt-1.5 rounded p-2 space-y-1 ${bank ? 'bg-green-50 border border-green-100' : 'bg-green-50 border border-green-200'}`}>
            {/* formatted display */}
            <p className="text-xs font-mono font-bold text-green-800 tracking-widest">
              {formatBICDisplay(result.normalised)}
            </p>

            {/* breakdown chips */}
            <div className="flex flex-wrap gap-1.5">
              <Chip icon={<Building2 size={10}/>} label="Institution" value={result.institutionCode!} color="blue" />
              <Chip icon={<MapPin     size={10}/>} label="Country"     value={result.countryCode!}    color="emerald" />
              <Chip icon={<Info       size={10}/>} label="Location"    value={result.locationCode!}   color="violet" />
              <Chip icon={<GitBranch  size={10}/>} label="Branch"      value={result.branchCode!}     color={result.isPrimary ? 'gray' : 'orange'} />
            </div>

            {/* not in directory notice */}
            {!bank && (
              <p className="text-xs text-gray-400 italic">
                BIC is structurally valid — not found in local directory
              </p>
            )}

            {/* test BIC warning */}
            {result.isTest && (
              <div className="flex items-center gap-1 text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded px-2 py-0.5">
                <AlertTriangle size={11} className="text-amber-500" />
                <span>Test BIC — location code ends in 0 (not for live transactions)</span>
              </div>
            )}
          </div>
        ) : (
          /* ── invalid: error ── */
          <div className="mt-1 flex items-center gap-1.5 text-xs text-red-600">
            <XCircle size={12} className="text-red-500 shrink-0" />
            <span>{result.error}</span>
          </div>
        )
      )}

      {/* ── timezone display ── */}
      {showTz && result?.valid && raw.length >= 6 && (
        <div className="mt-1">
          <TimezoneDisplay bic={raw} compact />
        </div>
      )}

      {hint && <p className="text-xs text-gray-400 mt-1">{hint}</p>}
    </div>
  );
};

/* ── small breakdown chip ── */
const CHIP_COLORS: Record<string, string> = {
  blue:    'bg-blue-50    text-blue-700   border-blue-200',
  emerald: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  violet:  'bg-violet-50  text-violet-700  border-violet-200',
  orange:  'bg-orange-50  text-orange-700  border-orange-200',
  gray:    'bg-gray-50    text-gray-600    border-gray-200',
};

function Chip({
  icon, label, value, color,
}: { icon: React.ReactNode; label: string; value: string; color: string }) {
  return (
    <span className={`inline-flex items-center gap-1 border rounded px-1.5 py-0.5 text-xs ${CHIP_COLORS[color] ?? CHIP_COLORS.gray}`}>
      {icon}
      <span className="text-gray-400">{label}:</span>
      <span className="font-mono font-semibold">{value}</span>
    </span>
  );
}
