import React, { useState, useRef, useEffect } from 'react';
import { ChevronLeft, ChevronRight, Calendar, X } from 'lucide-react';

interface DatePickerProps {
  label?: string;
  value: string;          // YYMMDD for SWIFT, YYYY-MM-DD for ISO
  onChange: (v: string) => void;
  format?: 'YYMMDD' | 'ISO';   // default: YYMMDD
  hint?: string;
  required?: boolean;
  minDate?: Date;
  maxDate?: Date;
}

const MONTHS = [
  'January','February','March','April','May','June',
  'July','August','September','October','November','December',
];
const DAYS = ['Su','Mo','Tu','We','Th','Fr','Sa'];

/** Parse a YYMMDD string → Date */
function parseYYMMDD(s: string): Date | null {
  if (!s || s.length < 6) return null;
  const yy = parseInt(s.slice(0, 2), 10);
  const mm = parseInt(s.slice(2, 4), 10) - 1;
  const dd = parseInt(s.slice(4, 6), 10);
  const year = yy >= 0 && yy <= 30 ? 2000 + yy : 1900 + yy;
  const d = new Date(year, mm, dd);
  return isNaN(d.getTime()) ? null : d;
}

/** Parse ISO YYYY-MM-DD → Date */
function parseISO(s: string): Date | null {
  if (!s) return null;
  const d = new Date(s + 'T00:00:00');
  return isNaN(d.getTime()) ? null : d;
}

/** Format Date → YYMMDD */
function toYYMMDD(d: Date): string {
  const yy = String(d.getFullYear()).slice(2);
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  return `${yy}${mm}${dd}`;
}

/** Format Date → YYYY-MM-DD */
function toISO(d: Date): string {
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  return `${yyyy}-${mm}-${dd}`;
}

/** Display a date nicely */
function displayDate(value: string, format: 'YYMMDD' | 'ISO'): string {
  const d = format === 'YYMMDD' ? parseYYMMDD(value) : parseISO(value);
  if (!d) return '';
  return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
}

export const DatePicker: React.FC<DatePickerProps> = ({
  label, value, onChange, format = 'YYMMDD', hint, required,
}) => {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  const parsed = format === 'YYMMDD' ? parseYYMMDD(value) : parseISO(value);
  const today = new Date();
  const [viewYear, setViewYear] = useState(parsed?.getFullYear() ?? today.getFullYear());
  const [viewMonth, setViewMonth] = useState(parsed?.getMonth() ?? today.getMonth());

  // Close on outside click
  useEffect(() => {
    const h = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', h);
    return () => document.removeEventListener('mousedown', h);
  }, []);

  // Build calendar grid
  const firstDay = new Date(viewYear, viewMonth, 1).getDay();
  const daysInMonth = new Date(viewYear, viewMonth + 1, 0).getDate();
  const cells: (number | null)[] = [
    ...Array(firstDay).fill(null),
    ...Array.from({ length: daysInMonth }, (_, i) => i + 1),
  ];
  while (cells.length % 7 !== 0) cells.push(null);

  const selectDay = (day: number) => {
    const d = new Date(viewYear, viewMonth, day);
    onChange(format === 'YYMMDD' ? toYYMMDD(d) : toISO(d));
    setOpen(false);
  };

  const isSelected = (day: number) => {
    if (!parsed) return false;
    return parsed.getFullYear() === viewYear && parsed.getMonth() === viewMonth && parsed.getDate() === day;
  };

  const isToday = (day: number) =>
    today.getFullYear() === viewYear && today.getMonth() === viewMonth && today.getDate() === day;

  const prevMonth = () => {
    if (viewMonth === 0) { setViewMonth(11); setViewYear(y => y - 1); }
    else setViewMonth(m => m - 1);
  };
  const nextMonth = () => {
    if (viewMonth === 11) { setViewMonth(0); setViewYear(y => y + 1); }
    else setViewMonth(m => m + 1);
  };

  const displayed = displayDate(value, format);

  return (
    <div className="relative" ref={ref}>
      <label className="block text-xs font-semibold text-gray-600 mb-1 uppercase tracking-wide">
        {label}{required && <span className="text-orange-500 ml-0.5">*</span>}
      </label>

      {/* Trigger */}
      <button
        type="button"
        onClick={() => {
          setOpen(o => !o);
          if (parsed) { setViewYear(parsed.getFullYear()); setViewMonth(parsed.getMonth()); }
        }}
        className="w-full flex items-center justify-between bg-white border border-gray-300 rounded
          px-3 py-2 text-sm text-left transition-all focus:outline-none hover:border-gray-400
          focus:border-orange-500 focus:ring-1 focus:ring-orange-400 cursor-pointer"
      >
        <div className="flex items-center gap-2">
          <Calendar size={14} className="text-orange-500 flex-shrink-0" />
          {displayed ? (
            <span className="text-gray-900 font-mono text-sm">{displayed}</span>
          ) : (
            <span className="text-gray-400 text-sm">Select date…</span>
          )}
        </div>
        <div className="flex items-center gap-1">
          {value && (
            <span
              role="button"
              onClick={e => { e.stopPropagation(); onChange(''); }}
              className="text-gray-400 hover:text-gray-600 cursor-pointer"
            >
              <X size={12} />
            </span>
          )}
          <span className="text-[9px] font-mono text-gray-400 bg-gray-100 px-1 py-0.5 rounded">
            {format}
          </span>
        </div>
      </button>

      {value && (
        <p className="text-[10px] font-mono text-green-600 mt-1">
          {value}
        </p>
      )}
      {hint && <p className="text-[10px] text-gray-400 mt-0.5">{hint}</p>}

      {/* Calendar dropdown */}
      {open && (
        <div className="absolute z-[100] top-full mt-2 left-0 w-72 bg-white border border-gray-200
          rounded-xl shadow-xl overflow-hidden">

          {/* Month/Year nav */}
          <div className="flex items-center justify-between px-4 py-3 bg-gray-50 border-b border-gray-200">
            <button
              type="button"
              onClick={prevMonth}
              className="p-1 rounded-lg hover:bg-gray-200 text-gray-500 hover:text-gray-800 transition cursor-pointer"
            >
              <ChevronLeft size={15} />
            </button>
            <div className="text-center">
              <span className="text-sm font-semibold text-gray-800">
                {MONTHS[viewMonth]} {viewYear}
              </span>
            </div>
            <button
              type="button"
              onClick={nextMonth}
              className="p-1 rounded-lg hover:bg-gray-200 text-gray-500 hover:text-gray-800 transition cursor-pointer"
            >
              <ChevronRight size={15} />
            </button>
          </div>

          {/* Year quick jumpers */}
          <div className="flex items-center justify-center gap-1 px-3 pt-2 pb-1">
            {[-2,-1,0,1,2].map(offset => {
              const y = today.getFullYear() + offset;
              return (
                <button
                  key={y}
                  type="button"
                  onClick={() => setViewYear(y)}
                  className={`text-[10px] px-2 py-0.5 rounded font-mono transition cursor-pointer
                    ${viewYear === y
                      ? 'bg-orange-500 text-white font-bold'
                      : 'bg-gray-100 text-gray-500 hover:bg-gray-200 hover:text-gray-800'}`}
                >
                  {y}
                </button>
              );
            })}
          </div>

          {/* Day headers */}
          <div className="grid grid-cols-7 px-3 pt-1 pb-0.5">
            {DAYS.map(d => (
              <div key={d} className="text-center text-[9px] font-bold text-gray-400 uppercase py-1">{d}</div>
            ))}
          </div>

          {/* Day cells */}
          <div className="grid grid-cols-7 px-3 pb-3 gap-0.5">
            {cells.map((day, i) => (
              <div key={i} className="aspect-square flex items-center justify-center">
                {day ? (
                  <button
                    type="button"
                    onClick={() => selectDay(day)}
                    className={`w-full h-full text-[11px] rounded-lg transition-all cursor-pointer font-mono
                      ${isSelected(day)
                        ? 'bg-orange-500 text-white font-bold shadow-sm'
                        : isToday(day)
                          ? 'bg-orange-50 text-orange-600 border border-orange-400 font-semibold'
                          : 'text-gray-700 hover:bg-gray-100 hover:text-gray-900'}`}
                  >
                    {day}
                  </button>
                ) : null}
              </div>
            ))}
          </div>

          {/* Quick actions */}
          <div className="border-t border-gray-100 px-3 py-2 flex gap-2">
            <button
              type="button"
              onClick={() => { const d = new Date(); onChange(format === 'YYMMDD' ? toYYMMDD(d) : toISO(d)); setOpen(false); }}
              className="flex-1 text-[10px] py-1 rounded-lg bg-orange-50 border border-orange-200 text-orange-600 font-semibold hover:bg-orange-100 transition cursor-pointer"
            >
              Today
            </button>
            {[1, 3, 6, 12].map(m => (
              <button
                key={m}
                type="button"
                onClick={() => {
                  const d = new Date();
                  d.setMonth(d.getMonth() + m);
                  onChange(format === 'YYMMDD' ? toYYMMDD(d) : toISO(d));
                  setOpen(false);
                }}
                className="flex-1 text-[10px] py-1 rounded-lg bg-gray-50 border border-gray-200 text-gray-600 hover:bg-gray-100 transition cursor-pointer"
              >
                +{m}m
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
