/**
 * IBANField — auto-strips spaces, validates mod-97, shows live feedback
 */
import React, { useState } from 'react';
import { CheckCircle, XCircle, AlertCircle, Copy, Check } from 'lucide-react';
import { validateIBAN, formatIBANDisplay, normaliseIBAN } from '../../utils/ibanValidator';

interface IBANFieldProps {
  label: string;
  name: string;
  fields: Record<string, string>;
  onChange: (f: Record<string, string>) => void;
  required?: boolean;
  hint?: string;
}

export const IBANField: React.FC<IBANFieldProps> = ({
  label, name, fields, onChange, required, hint,
}) => {
  const [copied, setCopied] = useState(false);
  const [touched, setTouched] = useState(false);

  const raw = fields[name] ?? '';
  const result = raw.length > 3 ? validateIBAN(raw) : null;
  const displayVal = raw;

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    // Always strip spaces as user types
    const stripped = normaliseIBAN(e.target.value);
    onChange({ ...fields, [name]: stripped });
    setTouched(true);
  };

  const handlePaste = (e: React.ClipboardEvent<HTMLInputElement>) => {
    e.preventDefault();
    const pasted = normaliseIBAN(e.clipboardData.getData('text'));
    onChange({ ...fields, [name]: pasted });
    setTouched(true);
  };

  const handleCopy = () => {
    const clean = normaliseIBAN(raw);
    if (clean) {
      navigator.clipboard.writeText(clean).catch(() => {});
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    }
  };

  // Border color based on validation state
  let borderCls = 'border-gray-300 focus:border-orange-500 focus:ring-orange-400';
  if (touched && result) {
    borderCls = result.valid
      ? 'border-green-400 focus:border-green-500 focus:ring-green-400'
      : 'border-red-400 focus:border-red-500 focus:ring-red-400';
  }

  const labelCls = 'block text-xs font-semibold text-gray-600 mb-1 uppercase tracking-wide';

  return (
    <div>
      <label className={labelCls}>
        {label}
        {required && <span className="text-orange-500 ml-0.5">*</span>}
      </label>

      <div className="relative">
        <input
          type="text"
          value={displayVal}
          onChange={handleChange}
          onPaste={handlePaste}
          onBlur={() => setTouched(true)}
          placeholder="e.g. GB14HBUK40119720675024"
          spellCheck={false}
          className={
            `w-full bg-white border rounded px-3 py-2 pr-16 text-sm font-mono text-gray-900 ` +
            `focus:outline-none focus:ring-1 transition-colors ${borderCls}`
          }
        />

        {/* Right icons */}
        <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
          {/* Validation icon */}
          {touched && result && (
            result.valid
              ? <CheckCircle size={14} className="text-green-500 flex-shrink-0" />
              : <XCircle size={14} className="text-red-500 flex-shrink-0" />
          )}
          {/* Copy button */}
          {raw && (
            <button
              type="button"
              onClick={handleCopy}
              className="text-gray-400 hover:text-orange-500 transition-colors cursor-pointer"
              title="Copy clean IBAN (no spaces)"
            >
              {copied ? <Check size={13} className="text-green-500" /> : <Copy size={13} />}
            </button>
          )}
        </div>
      </div>

      {/* Formatted display */}
      {raw && result?.valid && (
        <p className="text-[10px] font-mono text-green-600 mt-0.5">
          ✓ {formatIBANDisplay(raw)}
          {result.country && (
            <span className="ml-2 text-gray-400">({result.country} · {result.normalised.length} chars)</span>
          )}
        </p>
      )}

      {/* Error message */}
      {touched && result && !result.valid && result.error && (
        <p className="text-[10px] text-red-500 mt-0.5 flex items-center gap-1">
          <AlertCircle size={10} /> {result.error}
        </p>
      )}

      {/* Hint */}
      {hint && !result?.error && (
        <p className="text-[10px] text-gray-400 mt-0.5">{hint}</p>
      )}
    </div>
  );
};
