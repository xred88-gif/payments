import React, { useState } from 'react';
import {
  TrendingUp, FileText, Clock, CheckCircle2, AlertCircle,
  Plus, ArrowRight, CreditCard, Shield, MessageSquare, Activity,
  BookMarked, LayoutDashboard, Zap
} from 'lucide-react';
import { SWIFTMessage, MTMessageType } from '../../types';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';
import { ProfilesManager } from './ProfilesManager';
import { MessageProfile } from '../../utils/profiles';

interface DashboardProps {
  messages: SWIFTMessage[];
  onCompose: (profile?: MessageProfile) => void;
  onViewHistory: () => void;
  onViewMessage: (msg: SWIFTMessage) => void;
}

type DashTab = 'overview' | 'profiles';

const MT_COLORS: Record<string, string> = {
  MT700:      'from-blue-900/60 to-blue-950 border-blue-700/40',
  MT705:      'from-violet-900/60 to-violet-950 border-violet-700/40',
  MT760:      'from-emerald-900/60 to-emerald-950 border-emerald-700/40',
  MT199:      'from-amber-900/60 to-amber-950 border-amber-700/40',
  MT799:      'from-orange-900/60 to-orange-950 border-orange-700/40',
  'pacs.008': 'from-cyan-900/60 to-cyan-950 border-cyan-700/40',
  'pacs.009': 'from-cyan-900/60 to-cyan-950 border-cyan-700/40',
  'pacs.004': 'from-sky-900/60 to-sky-950 border-sky-700/40',
  'pacs.002': 'from-sky-900/60 to-sky-950 border-sky-700/40',
  'camt.053': 'from-teal-900/60 to-teal-950 border-teal-700/40',
  'camt.054': 'from-teal-900/60 to-teal-950 border-teal-700/40',
  'camt.056': 'from-green-900/60 to-green-950 border-green-700/40',
  'camt.029': 'from-green-900/60 to-green-950 border-green-700/40',
  'pain.001': 'from-rose-900/60 to-rose-950 border-rose-700/40',
  'pain.002': 'from-rose-900/60 to-rose-950 border-rose-700/40',
};

const MT_ICONS: Record<string, React.ReactNode> = {
  MT700: <CreditCard size={14} />, MT705: <CreditCard size={14} />,
  MT760: <Shield size={14} />,
  MT199: <MessageSquare size={14} />, MT799: <MessageSquare size={14} />,
};

const MT_DESCRIPTIONS: Record<string, string> = {
  MT700: 'Documentary Credit',   MT705: 'Pre-Advice of DC',
  MT760: 'Guarantee / SBLC',     MT199: 'Free Format Cat.1',
  MT799: 'Free Format Cat.7',
  'pacs.008': 'Credit Transfer', 'pacs.009': 'FI Credit Transfer',
  'pacs.004': 'Payment Return',  'pacs.002': 'Status Report',
  'camt.053': 'Statement',       'camt.054': 'Debit/Credit Notif.',
  'camt.056': 'Cancel Request',  'camt.029': 'Investigation Res.',
  'pain.001': 'Credit Transfer Init.', 'pain.002': 'Payment Status',
};

const ALL_TYPES = [
  'MT700','MT705','MT760','MT199','MT799',
  'pacs.008','pacs.009','pacs.004','pacs.002',
  'camt.053','camt.054','camt.056','camt.029',
  'pain.001','pain.002',
];

export const Dashboard: React.FC<DashboardProps> = ({
  messages, onCompose, onViewHistory, onViewMessage
}) => {
  const [tab, setTab] = useState<DashTab>('overview');

  const total  = messages.length;
  const finals = messages.filter(m => m.status === 'final').length;
  const drafts = messages.filter(m => m.status === 'draft').length;

  const byType = ((['MT700','MT705','MT760','MT199','MT799'] as MTMessageType[])).map(t => ({
    type: t,
    count: messages.filter(m => m.messageType === t).length,
  }));

  const recent = [...messages]
    .sort((a,b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 8);

  const stats = [
    { label: 'Total Messages', value: total,  icon: <FileText size={18} />,      color: 'text-blue-400',    bg: 'bg-blue-900/30'    },
    { label: 'Finalised',      value: finals, icon: <CheckCircle2 size={18} />,  color: 'text-emerald-400', bg: 'bg-emerald-900/30' },
    { label: 'Drafts',         value: drafts, icon: <AlertCircle size={18} />,   color: 'text-amber-400',   bg: 'bg-amber-900/30'   },
    {
      label: 'This Month',
      value: messages.filter(m => {
        const d = new Date(m.createdAt); const now = new Date();
        return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
      }).length,
      icon: <TrendingUp size={18} />, color: 'text-violet-400', bg: 'bg-violet-900/30',
    },
  ];

  // ── Tabs ────────────────────────────────────────────────────────────────────
  const TABS: { id: DashTab; label: string; icon: React.ReactNode }[] = [
    { id: 'overview', label: 'Overview',        icon: <LayoutDashboard size={13} /> },
    { id: 'profiles', label: 'Saved Profiles',  icon: <BookMarked size={13} /> },
  ];

  return (
    <div className="space-y-5">

      {/* ── Tab Bar ── */}
      <div className="flex items-center gap-1 bg-slate-800/60 border border-slate-700 rounded-xl p-1 w-fit">
        {TABS.map(t => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold transition-all cursor-pointer
              ${tab === t.id
                ? 'bg-orange-500 text-white shadow'
                : 'text-slate-400 hover:text-white hover:bg-slate-700/60'}`}
          >
            {t.icon}{t.label}
          </button>
        ))}
      </div>

      {/* ══════════════════════════════════════════════════════════════════════ */}
      {tab === 'overview' && (
        <>
          {/* ── Hero ── */}
          <div className="relative bg-gradient-to-br from-slate-800 to-slate-900 border border-slate-700 rounded-2xl p-6 overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-blue-600/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/4" />
            <div className="relative">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse" />
                <span className="text-xs text-emerald-400 font-medium uppercase tracking-widest">System Online</span>
              </div>

              <div className="flex items-center gap-3 mt-5">
                <Button variant="primary" icon={<Plus size={14} />} onClick={() => onCompose()}>
                  Compose Message
                </Button>
                <Button variant="outline" icon={<Clock size={14} />} iconRight={<ArrowRight size={12} />} onClick={onViewHistory}>
                  View History
                </Button>
                <Button variant="ghost" icon={<BookMarked size={14} />} onClick={() => setTab('profiles')}>
                  Profiles
                </Button>
              </div>
            </div>
          </div>

          {/* ── Stats ── */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {stats.map(s => (
              <div key={s.label} className="bg-slate-800/60 border border-slate-700 rounded-xl p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${s.bg} ${s.color}`}>{s.icon}</div>
                  <span className="text-2xl font-bold text-white">{s.value}</span>
                </div>
                <p className="text-xs text-slate-500">{s.label}</p>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            {/* Message Type Breakdown */}
            <div className="bg-slate-800/60 border border-slate-700 rounded-xl p-4">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-semibold text-white">By Message Type</h3>
                <Activity size={14} className="text-slate-600" />
              </div>
              <div className="space-y-2.5">
                {byType.map(({ type, count }) => (
                  <div key={type} className="flex items-center gap-3">
                    <div className={`flex items-center gap-1.5 px-2 py-1 rounded-lg border text-[10px] font-mono font-bold w-20 flex-shrink-0 bg-gradient-to-r ${MT_COLORS[type] ?? ''}`}>
                      {MT_ICONS[type]}<span className="ml-0.5">{type}</span>
                    </div>
                    <div className="flex-1">
                      <div className="h-1.5 bg-slate-700 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-gradient-to-r from-blue-500 to-blue-400 rounded-full transition-all duration-700"
                          style={{ width: total > 0 ? `${(count / total) * 100}%` : '0%' }}
                        />
                      </div>
                    </div>
                    <span className="text-xs font-semibold text-slate-300 w-6 text-right">{count}</span>
                  </div>
                ))}
                {total === 0 && <p className="text-xs text-slate-600 text-center py-4">No messages yet</p>}
              </div>
            </div>

            {/* Quick Compose */}
            <div className="bg-slate-800/60 border border-slate-700 rounded-xl p-4">
              <h3 className="text-sm font-semibold text-white mb-4">Quick Compose</h3>
              <div className="grid grid-cols-1 gap-2">
                {byType.map(({ type }) => (
                  <button
                    key={type}
                    onClick={() => onCompose()}
                    className={`flex items-center gap-3 p-3 rounded-lg border bg-gradient-to-r ${MT_COLORS[type]}
                      hover:opacity-90 transition-all text-left cursor-pointer group`}
                  >
                    <span className="text-slate-400 group-hover:text-white transition-colors">{MT_ICONS[type]}</span>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-mono font-bold text-slate-200">{type}</p>
                      <p className="text-[10px] text-slate-500">{MT_DESCRIPTIONS[type]}</p>
                    </div>
                    <Plus size={12} className="text-slate-600 group-hover:text-slate-400 transition-colors" />
                  </button>
                ))}
              </div>
            </div>

            {/* Supported Standards */}
            <div className="bg-slate-800/60 border border-slate-700 rounded-xl p-4">
              <h3 className="text-sm font-semibold text-white mb-4">Supported Standards</h3>
              <div className="space-y-3">
                {[
                  { std: 'SWIFT FIN MT',     desc: 'MT199 MT799 MT705 MT760 MT700',     status: 'Supported' },
                  { std: 'pacs (ISO 20022)',  desc: 'pacs.008 .009 .004 .002',           status: 'Supported' },
                  { std: 'camt (ISO 20022)',  desc: 'camt.053 .054 .056 .029',           status: 'Supported' },
                  { std: 'pain (ISO 20022)',  desc: 'pain.001 .002',                     status: 'Supported' },
                  { std: 'UETR / UUID v4',   desc: 'RFC 4122 — gpi compliant',          status: 'Validated' },
                  { std: 'Alliance Access',  desc: '7.7.70 PDF output format',          status: 'Supported' },
                ].map(s => (
                  <div key={s.std} className="flex items-start gap-3">
                    <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-1.5 flex-shrink-0" />
                    <div>
                      <p className="text-xs font-medium text-slate-300">{s.std}</p>
                      <p className="text-[10px] text-slate-600">{s.desc}</p>
                    </div>
                    <span className="ml-auto text-[9px] font-medium text-emerald-500 bg-emerald-900/30 border border-emerald-700/30 px-1.5 py-0.5 rounded flex-shrink-0">
                      {s.status}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* ── ISO 20022 Quick Access ── */}
          <div className="bg-slate-800/60 border border-slate-700 rounded-xl p-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                <Zap size={14} className="text-orange-400" /> ISO 20022 Quick Compose
              </h3>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2">
              {ALL_TYPES.filter(t => !t.startsWith('MT')).map(type => (
                <button
                  key={type}
                  onClick={() => onCompose()}
                  className={`flex flex-col items-start gap-1 p-3 rounded-xl border bg-gradient-to-br
                    ${MT_COLORS[type] ?? 'from-slate-800 to-slate-900 border-slate-700'}
                    hover:opacity-90 transition-all cursor-pointer group text-left`}
                >
                  <span className="text-[11px] font-mono font-bold text-slate-200">{type}</span>
                  <span className="text-[9px] text-slate-500 leading-tight">{MT_DESCRIPTIONS[type]}</span>
                </button>
              ))}
            </div>
          </div>

          {/* ── Recent Messages ── */}
          {recent.length > 0 && (
            <div className="bg-slate-800/60 border border-slate-700 rounded-xl overflow-hidden">
              <div className="flex items-center justify-between px-4 py-3 border-b border-slate-700">
                <h3 className="text-sm font-semibold text-white">Recent Messages</h3>
                <button
                  onClick={onViewHistory}
                  className="flex items-center gap-1 text-xs text-blue-400 hover:text-blue-300 transition-colors cursor-pointer"
                >
                  View all <ArrowRight size={12} />
                </button>
              </div>
              <div className="divide-y divide-slate-700/50">
                {recent.map(msg => {
                  // Pick the most meaningful ID to display per message standard
                  const iso = msg.isoFields as Record<string,string> | undefined;
                  const primaryId =
                    iso?.instrId       ||   // pacs.008 / pacs.009 / pacs.004
                    iso?.msgId         ||   // camt / pain group header
                    iso?.ntfctnId      ||   // camt.054 notification ID
                    iso?.stmtId        ||   // camt.053 statement ID
                    iso?.pmtInfId      ||   // pain.001 payment info
                    iso?.orgnlMsgId    ||   // pacs.002 / camt.056 / camt.029
                    msg.identifiers.transactionRef;

                  const secondaryId =
                    iso?.txId          ||   // transaction ID
                    iso?.endToEndId    ||   // end-to-end ID
                    iso?.uetr          ||   // UETR
                    msg.identifiers.uetr;

                  const label =
                    iso?.instrId       ? 'InstrId'    :
                    iso?.msgId         ? 'MsgId'      :
                    iso?.ntfctnId      ? 'NtfctnId'   :
                    iso?.stmtId        ? 'StmtId'     :
                    iso?.pmtInfId      ? 'PmtInfId'   :
                    iso?.orgnlMsgId    ? 'OrgnlMsgId' :
                                         'Ref';

                  const label2 =
                    iso?.txId          ? 'TxId'       :
                    iso?.endToEndId    ? 'E2EId'      :
                                         'UETR';

                  return (
                    <button
                      key={msg.id}
                      onClick={() => onViewMessage(msg)}
                      className="w-full flex items-center gap-3 px-4 py-3 hover:bg-slate-700/40 transition-colors text-left cursor-pointer"
                    >
                      {/* Type badge */}
                      <div className={`flex items-center gap-1.5 px-2 py-1 rounded-lg border text-[10px] font-mono font-bold flex-shrink-0 bg-gradient-to-r
                        ${MT_COLORS[msg.messageType] ?? 'from-slate-800 to-slate-900 border-slate-700'}`}
                      >
                        {MT_ICONS[msg.messageType] ?? <FileText size={12} />}
                        <span className="ml-0.5">{msg.messageType}</span>
                      </div>

                      {/* IDs column */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5 mb-0.5">
                          <span className="text-[9px] text-slate-500 font-mono uppercase tracking-wide flex-shrink-0">
                            {label}:
                          </span>
                          <p className="text-xs font-mono font-semibold text-slate-200 truncate">
                            {primaryId || <span className="text-slate-600 italic">—</span>}
                          </p>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <span className="text-[9px] text-slate-600 font-mono uppercase tracking-wide flex-shrink-0">
                            {label2}:
                          </span>
                          <p className="text-[10px] text-slate-500 truncate font-mono">
                            {secondaryId || '—'}
                          </p>
                        </div>
                      </div>

                      {/* Routing */}
                      <div className="hidden sm:flex flex-col items-end flex-shrink-0 min-w-0">
                        <p className="text-[10px] font-mono text-slate-400">
                          {msg.senderBIC || '—'} → {msg.receiverBIC || '—'}
                        </p>
                        <p className="text-[9px] text-slate-600">
                          {new Date(msg.createdAt).toLocaleDateString()} {new Date(msg.createdAt).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'})}
                        </p>
                      </div>

                      {/* Status */}
                      <div className="flex items-center gap-2 flex-shrink-0">
                        <Badge variant={msg.status === 'final' ? 'success' : 'warning'}>{msg.status}</Badge>
                      </div>
                      <ArrowRight size={12} className="text-slate-700 flex-shrink-0" />
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </>
      )}

      {/* ══════════════════════════════════════════════════════════════════════ */}
      {tab === 'profiles' && (
        <ProfilesManager onLoadProfile={(profile) => onCompose(profile)} />
      )}

    </div>
  );
};
