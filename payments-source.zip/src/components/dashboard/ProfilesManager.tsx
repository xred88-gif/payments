import React, { useState, useRef } from 'react';
import {
  BookMarked, Plus, Trash2, Upload, Edit2,
  Save, X, ChevronRight, Copy, RefreshCw, Check,
  FolderOpen, FileJson, Zap, Search
} from 'lucide-react';
import {
  MessageProfile, loadProfiles, saveProfile, deleteProfile,
  exportProfilesToJSON, importProfilesFromJSON,
  generateProfileId, PROFILE_COLORS, PROFILE_ICONS, MSG_TYPE_OPTIONS
} from '../../utils/profiles';

interface ProfilesManagerProps {
  onLoadProfile: (profile: MessageProfile) => void;
}

// ── Small helpers ─────────────────────────────────────────────────────────────
const colorFor = (token: string) =>
  PROFILE_COLORS.find(c => c.token === token) ?? PROFILE_COLORS[0];

// ── Sub-component: Profile Card ───────────────────────────────────────────────
const ProfileCard: React.FC<{
  profile: MessageProfile;
  onLoad: () => void;
  onEdit: () => void;
  onDelete: () => void;
  onDuplicate: () => void;
}> = ({ profile, onLoad, onEdit, onDelete, onDuplicate }) => {
  const col = colorFor(profile.color);
  const [confirmDel, setConfirmDel] = useState(false);

  return (
    <div className={`relative rounded-xl border bg-gradient-to-br ${col.bg} ${col.border} p-4 flex flex-col gap-3 group transition-all hover:scale-[1.01]`}>
      {/* Header */}
      <div className="flex items-start gap-3">
        <span className="text-2xl flex-shrink-0 mt-0.5">{profile.icon}</span>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-bold text-white truncate">{profile.name}</p>
          <p className="text-[10px] font-mono text-slate-400 mt-0.5">{profile.messageType}</p>
          {profile.description && (
            <p className="text-[10px] text-slate-500 mt-1 leading-relaxed line-clamp-2">{profile.description}</p>
          )}
        </div>
      </div>

      {/* Routing snippet */}
      {(profile.senderBIC || profile.receiverBIC) && (
        <div className="flex items-center gap-2 bg-black/20 rounded-lg px-3 py-2">
          <span className="text-[10px] font-mono text-slate-300 truncate">{profile.senderBIC || '—'}</span>
          <ChevronRight size={10} className="text-slate-600 flex-shrink-0" />
          <span className="text-[10px] font-mono text-slate-300 truncate">{profile.receiverBIC || '—'}</span>
        </div>
      )}

      {/* ISO fields preview */}
      {profile.isoFields && Object.keys(profile.isoFields).length > 0 && (
        <div className="grid grid-cols-2 gap-1">
          {Object.entries(profile.isoFields).slice(0, 4).map(([k, v]) => (
            <div key={k} className="bg-black/20 rounded px-2 py-1">
              <p className="text-[9px] text-slate-500 uppercase tracking-wider">{k}</p>
              <p className="text-[10px] font-mono text-slate-300 truncate">{v}</p>
            </div>
          ))}
        </div>
      )}

      {/* MT fields preview */}
      {profile.mtFields && Object.keys(profile.mtFields).length > 0 && (
        <div className="grid grid-cols-2 gap-1">
          {Object.entries(profile.mtFields).slice(0, 4).map(([k, v]) => (
            <div key={k} className="bg-black/20 rounded px-2 py-1">
              <p className="text-[9px] text-slate-500 uppercase tracking-wider">{k.replace('tag', ':')}</p>
              <p className="text-[10px] font-mono text-slate-300 truncate">{v}</p>
            </div>
          ))}
        </div>
      )}

      {/* Timestamp */}
      <p className="text-[9px] text-slate-600">
        Saved {new Date(profile.updatedAt).toLocaleDateString()} {new Date(profile.updatedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
      </p>

      {/* Actions */}
      <div className="flex items-center gap-2">
        <button
          onClick={onLoad}
          className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-semibold
            bg-white/10 hover:bg-white/20 text-white transition-all cursor-pointer"
        >
          <Zap size={11} /> Load & Compose
        </button>
        <button onClick={onEdit} className="p-2 rounded-lg bg-white/5 hover:bg-white/15 text-slate-400 hover:text-white transition-all cursor-pointer">
          <Edit2 size={13} />
        </button>
        <button onClick={onDuplicate} className="p-2 rounded-lg bg-white/5 hover:bg-white/15 text-slate-400 hover:text-white transition-all cursor-pointer">
          <Copy size={13} />
        </button>
        {confirmDel ? (
          <div className="flex gap-1">
            <button onClick={onDelete} className="p-2 rounded-lg bg-red-500/20 hover:bg-red-500/40 text-red-400 transition-all cursor-pointer">
              <Check size={13} />
            </button>
            <button onClick={() => setConfirmDel(false)} className="p-2 rounded-lg bg-white/5 hover:bg-white/15 text-slate-400 transition-all cursor-pointer">
              <X size={13} />
            </button>
          </div>
        ) : (
          <button onClick={() => setConfirmDel(true)} className="p-2 rounded-lg bg-white/5 hover:bg-red-500/20 text-slate-500 hover:text-red-400 transition-all cursor-pointer">
            <Trash2 size={13} />
          </button>
        )}
      </div>
    </div>
  );
};

// ── Sub-component: Profile Form (Create / Edit) ───────────────────────────────
const ProfileForm: React.FC<{
  initial?: MessageProfile | null;
  onSave: (p: MessageProfile) => void;
  onCancel: () => void;
}> = ({ initial, onSave, onCancel }) => {
  const blank: MessageProfile = {
    id: generateProfileId(),
    name: '',
    description: '',
    messageType: 'pacs.008',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    color: 'blue',
    icon: '🏦',
    senderBIC: '',
    receiverBIC: '',
    isoFields: {},
    mtFields: {},
  };

  const [form, setForm] = useState<MessageProfile>(initial ?? blank);
  const [isoRaw, setIsoRaw]  = useState(
    initial?.isoFields ? Object.entries(initial.isoFields).map(([k,v]) => `${k}=${v}`).join('\n') : ''
  );
  const [mtRaw, setMtRaw]   = useState(
    initial?.mtFields  ? Object.entries(initial.mtFields).map(([k,v]) => `${k}=${v}`).join('\n') : ''
  );

  const isISO = !form.messageType.startsWith('MT');

  const parseKV = (raw: string): Record<string,string> => {
    const result: Record<string,string> = {};
    raw.split('\n').forEach(line => {
      const eq = line.indexOf('=');
      if (eq > 0) {
        result[line.slice(0,eq).trim()] = line.slice(eq+1).trim();
      }
    });
    return result;
  };

  const handleSave = () => {
    if (!form.name.trim()) return;
    const final: MessageProfile = {
      ...form,
      isoFields: isISO ? parseKV(isoRaw) : {},
      mtFields:  !isISO ? parseKV(mtRaw) : {},
      updatedAt: new Date().toISOString(),
    };
    onSave(final);
  };

  return (
    <div className="bg-slate-800/80 border border-slate-700 rounded-2xl p-5 space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-bold text-white flex items-center gap-2">
          <BookMarked size={15} className="text-orange-400" />
          {initial ? 'Edit Profile' : 'New Profile'}
        </h3>
        <button onClick={onCancel} className="text-slate-500 hover:text-slate-300 cursor-pointer"><X size={15} /></button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Name */}
        <div className="md:col-span-2">
          <label className="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1.5">Profile Name *</label>
          <input
            value={form.name}
            onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
            placeholder="e.g. JPMorgan → HSBC USD Transfers"
            className="w-full bg-slate-900/60 border border-slate-600 rounded-lg px-3 py-2.5 text-sm text-white
              placeholder-slate-600 focus:outline-none focus:border-orange-500 transition-colors"
          />
        </div>

        {/* Description */}
        <div className="md:col-span-2">
          <label className="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1.5">Description</label>
          <input
            value={form.description ?? ''}
            onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
            placeholder="Optional notes about this profile"
            className="w-full bg-slate-900/60 border border-slate-600 rounded-lg px-3 py-2.5 text-sm text-white
              placeholder-slate-600 focus:outline-none focus:border-orange-500 transition-colors"
          />
        </div>

        {/* Message Type */}
        <div>
          <label className="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1.5">Message Type</label>
          <select
            value={form.messageType}
            onChange={e => setForm(f => ({ ...f, messageType: e.target.value }))}
            className="w-full bg-slate-900/60 border border-slate-600 rounded-lg px-3 py-2.5 text-sm text-white
              focus:outline-none focus:border-orange-500 transition-colors cursor-pointer"
          >
            {MSG_TYPE_OPTIONS.map(t => <option key={t} value={t}>{t}</option>)}
          </select>
        </div>

        {/* Icon & Color */}
        <div>
          <label className="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1.5">Icon</label>
          <div className="flex flex-wrap gap-1.5">
            {PROFILE_ICONS.map(icon => (
              <button
                key={icon}
                onClick={() => setForm(f => ({ ...f, icon }))}
                className={`w-8 h-8 rounded-lg text-lg flex items-center justify-center transition-all cursor-pointer
                  ${form.icon === icon ? 'bg-orange-500/30 ring-1 ring-orange-500' : 'bg-slate-700/50 hover:bg-slate-700'}`}
              >
                {icon}
              </button>
            ))}
          </div>
        </div>

        {/* Color */}
        <div>
          <label className="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1.5">Card Colour</label>
          <div className="flex flex-wrap gap-2">
            {PROFILE_COLORS.map(c => (
              <button
                key={c.token}
                onClick={() => setForm(f => ({ ...f, color: c.token }))}
                className={`w-6 h-6 rounded-full border-2 cursor-pointer transition-all
                  ${form.color === c.token ? 'scale-125 border-white' : 'border-transparent opacity-60 hover:opacity-100'}`}
                style={{ background: c.dot }}
              />
            ))}
          </div>
        </div>

        {/* Sender / Receiver BIC */}
        <div>
          <label className="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1.5">Sender BIC</label>
          <input
            value={form.senderBIC ?? ''}
            onChange={e => setForm(f => ({ ...f, senderBIC: e.target.value.toUpperCase() }))}
            placeholder="CHASUS33XXX"
            className="w-full bg-slate-900/60 border border-slate-600 rounded-lg px-3 py-2.5 text-sm font-mono text-white
              placeholder-slate-600 focus:outline-none focus:border-orange-500 transition-colors"
          />
        </div>
        <div>
          <label className="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1.5">Receiver BIC</label>
          <input
            value={form.receiverBIC ?? ''}
            onChange={e => setForm(f => ({ ...f, receiverBIC: e.target.value.toUpperCase() }))}
            placeholder="HBUKGB4196G"
            className="w-full bg-slate-900/60 border border-slate-600 rounded-lg px-3 py-2.5 text-sm font-mono text-white
              placeholder-slate-600 focus:outline-none focus:border-orange-500 transition-colors"
          />
        </div>

        {/* Fields (ISO or MT) */}
        {isISO ? (
          <div className="md:col-span-2">
            <label className="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1.5">
              ISO 20022 Fields <span className="text-slate-600 normal-case font-normal">(one per line: fieldName=value)</span>
            </label>
            <textarea
              rows={6}
              value={isoRaw}
              onChange={e => setIsoRaw(e.target.value)}
              placeholder={
                `dbtrNm=KOBO PRODUCTS INC\ndbtrAcct=301170955265\ndbtrAgtBIC=CHASUS33XXX\ncdtrNm=GOLD RESOURCES LTD\ncdtrAcct=GB14HBUK40119720675024\ncdtrAgtBIC=HBUKGB4196G`
              }
              className="w-full bg-slate-900/60 border border-slate-600 rounded-lg px-3 py-2.5 text-xs font-mono text-white
                placeholder-slate-600 focus:outline-none focus:border-orange-500 transition-colors resize-none"
            />
            <p className="text-[10px] text-slate-600 mt-1">These values will pre-fill the compose form when this profile is loaded.</p>
          </div>
        ) : (
          <div className="md:col-span-2">
            <label className="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1.5">
              MT Fields <span className="text-slate-600 normal-case font-normal">(one per line: tag50=value)</span>
            </label>
            <textarea
              rows={6}
              value={mtRaw}
              onChange={e => setMtRaw(e.target.value)}
              placeholder={`tag50=ACME CORPORATION\nGOLD STREET 1\nNEW YORK USA\ntag59=JOHN DOE\nLONDON UK`}
              className="w-full bg-slate-900/60 border border-slate-600 rounded-lg px-3 py-2.5 text-xs font-mono text-white
                placeholder-slate-600 focus:outline-none focus:border-orange-500 transition-colors resize-none"
            />
          </div>
        )}
      </div>

      <div className="flex gap-3 pt-2">
        <button
          onClick={handleSave}
          disabled={!form.name.trim()}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold
            bg-orange-500 hover:bg-orange-600 disabled:opacity-40 text-white transition-all cursor-pointer"
        >
          <Save size={13} /> Save Profile
        </button>
        <button
          onClick={onCancel}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold
            bg-slate-700 hover:bg-slate-600 text-slate-300 transition-all cursor-pointer"
        >
          <X size={13} /> Cancel
        </button>
      </div>
    </div>
  );
};

// ── Main Component ────────────────────────────────────────────────────────────
export const ProfilesManager: React.FC<ProfilesManagerProps> = ({ onLoadProfile }) => {
  const [profiles, setProfiles]       = useState<MessageProfile[]>(loadProfiles);
  const [showForm, setShowForm]       = useState(false);
  const [editTarget, setEditTarget]   = useState<MessageProfile | null>(null);
  const [search, setSearch]           = useState('');
  const [filterType, setFilterType]   = useState('');
  const [toast, setToast]             = useState<string | null>(null);
  const fileRef                        = useRef<HTMLInputElement>(null);

  const flash = (msg: string) => { setToast(msg); setTimeout(() => setToast(null), 2500); };

  const refresh = (updated: MessageProfile[]) => setProfiles(updated);

  const handleSave = (p: MessageProfile) => {
    refresh(saveProfile(p));
    setShowForm(false);
    setEditTarget(null);
    flash(`Profile "${p.name}" saved`);
  };

  const handleDelete = (id: string) => {
    refresh(deleteProfile(id));
    flash('Profile deleted');
  };

  const handleDuplicate = (p: MessageProfile) => {
    const dup: MessageProfile = {
      ...p,
      id: generateProfileId(),
      name: `${p.name} (copy)`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    refresh(saveProfile(dup));
    flash(`Duplicated "${p.name}"`);
  };

  const handleEdit = (p: MessageProfile) => {
    setEditTarget(p);
    setShowForm(true);
  };

  const handleExport = () => {
    exportProfilesToJSON(profiles);
    flash('Profiles exported as JSON');
  };

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => {
      try {
        const updated = importProfilesFromJSON(ev.target?.result as string);
        refresh(updated);
        flash(`${updated.length} profiles imported`);
      } catch {
        flash('Error: invalid JSON file');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  // Filter
  const filtered = profiles.filter(p => {
    const q = search.toLowerCase();
    if (q && !p.name.toLowerCase().includes(q) && !(p.senderBIC ?? '').toLowerCase().includes(q) && !(p.receiverBIC ?? '').toLowerCase().includes(q)) return false;
    if (filterType && p.messageType !== filterType) return false;
    return true;
  });

  return (
    <div className="space-y-4">
      {/* ── Header bar ── */}
      <div className="flex items-center justify-between">
        <h2 className="text-base font-bold text-white flex items-center gap-2">
          <BookMarked size={16} className="text-orange-400" />
          Saved Profiles
          {profiles.length > 0 && (
            <span className="text-[10px] bg-orange-500/20 text-orange-400 border border-orange-500/30 px-2 py-0.5 rounded-full font-semibold">
              {profiles.length}
            </span>
          )}
        </h2>
        <div className="flex items-center gap-2">
          {/* Import */}
          <input ref={fileRef} type="file" accept=".json" className="hidden" onChange={handleImport} />
          <button
            onClick={() => fileRef.current?.click()}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold
              bg-slate-700/60 hover:bg-slate-700 text-slate-300 border border-slate-600 transition-all cursor-pointer"
          >
            <Upload size={12} /> Import
          </button>
          {/* Export */}
          {profiles.length > 0 && (
            <button
              onClick={handleExport}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold
                bg-slate-700/60 hover:bg-slate-700 text-slate-300 border border-slate-600 transition-all cursor-pointer"
            >
              <FileJson size={12} /> Export
            </button>
          )}
          {/* New */}
          <button
            onClick={() => { setEditTarget(null); setShowForm(true); }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold
              bg-orange-500 hover:bg-orange-600 text-white transition-all cursor-pointer"
          >
            <Plus size={12} /> New Profile
          </button>
        </div>
      </div>

      {/* ── Toast ── */}
      {toast && (
        <div className="flex items-center gap-2 px-4 py-2.5 bg-emerald-900/50 border border-emerald-700/50 rounded-xl text-xs text-emerald-300">
          <Check size={13} /> {toast}
        </div>
      )}

      {/* ── Form ── */}
      {showForm && (
        <ProfileForm
          initial={editTarget}
          onSave={handleSave}
          onCancel={() => { setShowForm(false); setEditTarget(null); }}
        />
      )}

      {/* ── Search & Filter ── */}
      {profiles.length > 0 && (
        <div className="flex gap-3">
          <div className="relative flex-1">
            <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 pointer-events-none" />
            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search profiles…"
              className="w-full bg-slate-900/60 border border-slate-700 rounded-lg pl-8 pr-3 py-2 text-xs text-white
                placeholder-slate-600 focus:outline-none focus:border-orange-500 transition-colors"
            />
            {search && (
              <button onClick={() => setSearch('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white cursor-pointer">
                <X size={11} />
              </button>
            )}
          </div>
          <select
            value={filterType}
            onChange={e => setFilterType(e.target.value)}
            className="bg-slate-900/60 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white
              focus:outline-none focus:border-orange-500 transition-colors cursor-pointer"
          >
            <option value="">All Types</option>
            {MSG_TYPE_OPTIONS.map(t => <option key={t} value={t}>{t}</option>)}
          </select>
          {(search || filterType) && (
            <button
              onClick={() => { setSearch(''); setFilterType(''); }}
              className="flex items-center gap-1 px-3 py-2 rounded-lg text-xs text-slate-400 hover:text-white
                bg-slate-700/50 border border-slate-700 transition-all cursor-pointer"
            >
              <RefreshCw size={11} /> Reset
            </button>
          )}
        </div>
      )}

      {/* ── Profile Grid ── */}
      {filtered.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {filtered.map(p => (
            <ProfileCard
              key={p.id}
              profile={p}
              onLoad={() => onLoadProfile(p)}
              onEdit={() => handleEdit(p)}
              onDelete={() => handleDelete(p.id)}
              onDuplicate={() => handleDuplicate(p)}
            />
          ))}
        </div>
      ) : profiles.length === 0 && !showForm ? (
        /* ── Empty state ── */
        <div className="text-center py-14 border border-dashed border-slate-700 rounded-2xl">
          <FolderOpen size={32} className="mx-auto text-slate-700 mb-3" />
          <p className="text-sm font-semibold text-slate-500">No profiles yet</p>
          <p className="text-xs text-slate-600 mt-1 mb-5 max-w-xs mx-auto">
            Save your frequently-used sender / receiver details, account numbers and routing data as a reusable profile.
          </p>
          <button
            onClick={() => { setEditTarget(null); setShowForm(true); }}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold
              bg-orange-500/20 hover:bg-orange-500/30 text-orange-400 border border-orange-500/30 transition-all cursor-pointer"
          >
            <Plus size={13} /> Create Your First Profile
          </button>
        </div>
      ) : (
        <div className="text-center py-8 text-xs text-slate-600">
          No profiles match your search.
        </div>
      )}
    </div>
  );
};
