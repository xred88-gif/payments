import React, { useState } from 'react';
import {
  Copy, Check, Download, Edit2, Trash2,
  FileText, Shield, CreditCard, MessageSquare,
  Info, Hash, Network, ChevronDown, ChevronUp, Layers
} from 'lucide-react';
import { SWIFTMessage } from '../../types';
import { exportMessageToPDF, exportBundleToPDF } from '../../utils/pdfExport';
import { deriveCamt054FromPacs008 } from '../../utils/deriveMessages';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';

interface MessageViewerProps {
  message: SWIFTMessage;
  onEdit?: () => void;
  onDelete?: () => void;
}

const MT_ICONS: Record<string, React.ReactNode> = {
  MT700: <CreditCard size={16} />,
  MT705: <CreditCard size={16} />,
  MT760: <Shield size={16} />,
  MT199: <MessageSquare size={16} />,
  MT799: <MessageSquare size={16} />,
};

const MT_COLORS: Record<string, string> = {
  MT700: 'blue',
  MT705: 'violet',
  MT760: 'emerald',
  MT199: 'amber',
  MT799: 'orange',
};

// ─── SWIFT Field Registry ─────────────────────────────────────────────────────
// Maps tag number → { name, description }
const FIELD_REGISTRY: Record<string, { name: string; desc: string }> = {
  '20':  { name: 'Transaction Reference Number', desc: 'Unique reference assigned by the sender. Max 16 chars.' },
  '21':  { name: 'Related Reference',            desc: 'Reference to a related message or transaction.' },
  '23':  { name: 'Reference to Pre-Advice',      desc: 'Reference to a previously sent pre-advice message.' },
  '27':  { name: 'Sequence of Total',            desc: 'Indicates the sequence number and total number of messages in a set (e.g. 1/1).' },
  '31C': { name: 'Date of Issue',                desc: 'Date the credit/guarantee was issued. Format: YYMMDD.' },
  '31D': { name: 'Date and Place of Expiry',     desc: 'Expiry date (YYMMDD) and place of the credit.' },
  '32B': { name: 'Currency Code, Amount',        desc: 'ISO 4217 currency code followed by amount (comma decimal). e.g. USD1500000,00.' },
  '39A': { name: 'Percentage Credit Amount Tolerance', desc: 'Plus/minus tolerance as percentage. Format: NN/NN.' },
  '39B': { name: 'Maximum Credit Amount',        desc: 'Indicates the maximum credit amount clause.' },
  '40A': { name: 'Form of Documentary Credit',   desc: 'Specifies the type of documentary credit (e.g. IRREVOCABLE).' },
  '40C': { name: 'Applicable Rules',             desc: 'Rules governing the guarantee (e.g. URDG, ISP98).' },
  '41A': { name: 'Available With... By... (BIC)', desc: 'BIC of the bank with which the credit is available, plus availability terms.' },
  '41D': { name: 'Available With... By... (Name)', desc: 'Name/address of bank with which the credit is available.' },
  '42A': { name: 'Drawee (BIC)',                 desc: 'BIC of the bank on which drafts are to be drawn.' },
  '42C': { name: 'Drafts at...',                 desc: 'Tenor of drafts to be drawn under the credit.' },
  '42D': { name: 'Drawee (Name/Address)',        desc: 'Name and address of the drawee bank.' },
  '43P': { name: 'Partial Shipments',            desc: 'Indicates whether partial shipments are permitted.' },
  '43T': { name: 'Transshipment',                desc: 'Indicates whether transshipment is permitted.' },
  '44A': { name: 'Place of Taking in Charge',    desc: 'Port/place of receipt or taking in charge.' },
  '44B': { name: 'Place of Final Destination',   desc: 'Final destination or place of delivery.' },
  '44C': { name: 'Latest Date of Shipment',      desc: 'Latest allowable shipment date. Format: YYMMDD.' },
  '44D': { name: 'Shipment Period',              desc: 'Period allowed for shipment.' },
  '44E': { name: 'Port of Loading',              desc: 'Port of loading or airport of departure.' },
  '44F': { name: 'Port of Discharge',            desc: 'Port of discharge or airport of destination.' },
  '45A': { name: 'Description of Goods/Services', desc: 'Detailed description of goods, services, or performance underlying the credit.' },
  '46A': { name: 'Documents Required',           desc: 'List of documents required for presentation under the credit.' },
  '47A': { name: 'Additional Conditions',        desc: 'Special conditions or requirements not covered by other fields.' },
  '48':  { name: 'Period for Presentation',      desc: 'Number of days after shipment date within which documents must be presented.' },
  '49':  { name: 'Confirmation Instructions',    desc: 'Indicates confirming bank\'s role: CONFIRM, MAY ADD, or WITHOUT.' },
  '50':  { name: 'Applicant',                    desc: 'Full name and address of the applicant (buyer/instructing party).' },
  '53A': { name: 'Reimbursing Bank (BIC)',       desc: 'BIC of the bank authorised to reimburse the paying/negotiating bank.' },
  '53D': { name: 'Reimbursing Bank (Name)',      desc: 'Name and address of the reimbursing bank.' },
  '57A': { name: 'Advise Through Bank (BIC)',    desc: 'BIC of the advising bank through which the credit is to be advised.' },
  '57D': { name: 'Advise Through Bank (Name)',   desc: 'Name and address of the advising through bank.' },
  '59':  { name: 'Beneficiary',                  desc: 'Full name and address of the beneficiary (seller/exporter).' },
  '71B': { name: 'Charges',                      desc: 'Specifies which party is to bear documentary credit charges.' },
  '72':  { name: 'Sender to Receiver Info',      desc: 'Additional information for the receiver. Max 6 lines of 35 chars.' },
  '77C': { name: 'Details of Guarantee',         desc: 'Full text of the guarantee or standby letter of credit.' },
  '78':  { name: 'Instructions to Bank',         desc: 'Instructions to the paying, accepting, or negotiating bank.' },
  '79':  { name: 'Narrative',                    desc: 'Free-format narrative text. Max 35 lines × 35 characters per line.' },
  '22D': { name: 'Form of Guarantee',            desc: 'Type of guarantee: DGAR, STBY, TGAR, PGAR, CGAR, etc.' },
};

// ─── Line parser / classifier ─────────────────────────────────────────────────

type LineType = 'block_header' | 'block_end' | 'field_tag' | 'field_continuation' | 'blank';

interface ParsedLine {
  raw: string;
  type: LineType;
  tag?: string;
  fieldName?: string;
  fieldDesc?: string;
  value?: string;
}

function parseLines(raw: string): ParsedLine[] {
  const result: ParsedLine[] = [];
  let lastTag: string | null = null;

  for (const line of raw.split('\n')) {
    const trimmed = line.trim();

    if (trimmed === '') {
      result.push({ raw: line, type: 'blank' });
      continue;
    }

    // Block headers: {1:...}, {2:...}, {3:...}, {4:, {5:...}
    if (/^\{[1-5]:/.test(trimmed) || trimmed === '{4:') {
      result.push({ raw: line, type: 'block_header' });
      lastTag = null;
      continue;
    }

    // Block end marker
    if (trimmed === '-}') {
      result.push({ raw: line, type: 'block_end' });
      lastTag = null;
      continue;
    }

    // Field tag: :20:, :40A:, :77C:, etc.
    const tagMatch = trimmed.match(/^:(\d{2}[A-Z]?):(.*)$/s);
    if (tagMatch) {
      const tag = tagMatch[1];
      const value = tagMatch[2];
      const info = FIELD_REGISTRY[tag];
      lastTag = tag;
      result.push({
        raw: line,
        type: 'field_tag',
        tag,
        fieldName: info?.name,
        fieldDesc: info?.desc,
        value,
      });
      continue;
    }

    // Everything else after a tag = continuation
    result.push({ raw: line, type: lastTag ? 'field_continuation' : 'block_header', tag: lastTag ?? undefined });
  }

  return result;
}

// ─── Syntax-highlighted raw message ──────────────────────────────────────────

const SyntaxLine: React.FC<{ line: ParsedLine; annotated: boolean }> = ({ line, annotated }) => {
  const [expanded, setExpanded] = useState(false);

  if (line.type === 'blank') return <div className="h-1" />;

  if (line.type === 'block_header') {
    return (
      <div className="flex items-start gap-2 group py-0.5">
        <span className="text-blue-400 font-semibold font-mono text-xs leading-5 select-all">{line.raw}</span>
        {annotated && (
          <span className="text-[10px] text-blue-600 opacity-0 group-hover:opacity-100 transition-opacity mt-0.5 whitespace-nowrap">
            {line.raw.startsWith('{1:') ? '← Basic Header Block' :
             line.raw.startsWith('{2:') ? '← Application Header' :
             line.raw.startsWith('{3:') ? '← User Header Block' :
             line.raw === '{4:' ? '← Text Block (start)' :
             line.raw.startsWith('{5:') ? '← Trailer Block' : ''}
          </span>
        )}
      </div>
    );
  }

  if (line.type === 'block_end') {
    return (
      <div className="flex items-center gap-2 group py-0.5">
        <span className="text-teal-500 font-mono text-xs leading-5">-{'}'}</span>
        {annotated && (
          <span className="text-[10px] text-teal-700 opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
            ← End of Text Block
          </span>
        )}
      </div>
    );
  }

  if (line.type === 'field_tag') {
    const tagPart = `:${line.tag}:`;
    const valuePart = line.value ?? '';
    const hasAnnotation = annotated && (line.fieldName || line.fieldDesc);

    return (
      <div className="group">
        <div className="flex items-start gap-2 py-0.5">
          <div className="flex-1 font-mono text-xs leading-5 select-all">
            <span className="text-amber-400 font-semibold">{tagPart}</span>
            <span className="text-emerald-300">{valuePart}</span>
          </div>
          {hasAnnotation && (
            <button
              onClick={() => setExpanded(e => !e)}
              className="opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1 text-[9px] text-slate-500 hover:text-slate-300 flex-shrink-0 mt-0.5 cursor-pointer"
            >
              {expanded ? <ChevronUp size={10}/> : <ChevronDown size={10}/>}
              <Info size={9}/>
            </button>
          )}
        </div>
        {expanded && hasAnnotation && (
          <div className="ml-4 mb-1 bg-slate-800/80 border border-slate-700 rounded px-3 py-2 text-[10px]">
            <p className="text-blue-300 font-semibold mb-0.5">Field :{line.tag}: — {line.fieldName}</p>
            <p className="text-slate-400 leading-relaxed">{line.fieldDesc}</p>
          </div>
        )}
      </div>
    );
  }

  if (line.type === 'field_continuation') {
    return (
      <div className="py-0.5">
        <span className="text-emerald-300 font-mono text-xs leading-5 ml-0 select-all">{line.raw}</span>
      </div>
    );
  }

  return <div className="font-mono text-xs text-slate-400 py-0.5">{line.raw}</div>;
};

// ─── Main viewer ──────────────────────────────────────────────────────────────

export const MessageViewer: React.FC<MessageViewerProps> = ({ message, onEdit, onDelete }) => {
  const [copied, setCopied]         = useState(false);
  const [exporting, setExporting]   = useState(false);
  const [exporting054, setExp054]   = useState(false);
  const [activeTab, setActiveTab]   = useState<'raw' | 'annotated' | 'meta' | 'ids'>('raw');

  const isPacs008 = message.messageType === 'pacs.008';

  const copyRaw = async () => {
    await navigator.clipboard.writeText(message.rawMessage);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  const exportPDF = () => {
    setExporting(true);
    try { exportMessageToPDF(message); } catch(e) { console.error(e); }
    setExporting(false);
  };

  const exportBundle = () => {
    if (!isPacs008) return;
    setExp054(true);
    try {
      const camt054 = deriveCamt054FromPacs008(message);
      exportBundleToPDF(message, camt054);
    } catch(e) { console.error(e); }
    setExp054(false);
  };

  const color = MT_COLORS[message.messageType] ?? 'blue';
  const parsedLines = parseLines(message.rawMessage);

  const tabs = [
    { id: 'raw'       as const, label: 'Raw FIN Message' },
    { id: 'annotated' as const, label: 'Annotated View' },
    { id: 'meta'      as const, label: 'Block Metadata' },
    { id: 'ids'       as const, label: 'Identifiers' },
  ];

  const fieldLines = parsedLines.filter(l => l.type === 'field_tag');

  return (
    <div className="flex flex-col gap-4 min-h-0">
      {/* Header ─────────────────────────────────────────────────────────────── */}
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div className="flex items-center gap-3">
          <div className={`w-10 h-10 rounded-xl flex items-center justify-center
            ${color === 'blue'    ? 'bg-blue-900/60 text-blue-400' :
              color === 'violet'  ? 'bg-violet-900/60 text-violet-400' :
              color === 'emerald' ? 'bg-emerald-900/60 text-emerald-400' :
              color === 'amber'   ? 'bg-amber-900/60 text-amber-400' :
              'bg-orange-900/60 text-orange-400'}`}>
            {MT_ICONS[message.messageType]}
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-base font-bold text-white font-mono">{message.messageType}</h2>
              <Badge variant={message.status === 'final' ? 'success' : 'warning'}>
                {message.status.toUpperCase()}
              </Badge>
              <span className="text-xs font-mono text-slate-500 bg-slate-800 px-2 py-0.5 rounded">
                {fieldLines.length} fields
              </span>
              <span className="text-xs font-mono text-slate-500 bg-slate-800 px-2 py-0.5 rounded">
                {message.rawMessage.length} chars
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5 font-mono">
              {message.block1?.logicalTerminalAddress ?? message.senderBIC} → {message.block2?.receiverAddress ?? message.receiverBIC}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap justify-end">
          <Button variant="ghost" size="sm" icon={copied ? <Check size={13}/> : <Copy size={13}/>} onClick={copyRaw}>
            {copied ? 'Copied!' : 'Copy Raw'}
          </Button>
          <Button variant="primary" size="sm" icon={<Download size={13}/>} onClick={exportPDF} loading={exporting}>
            Export PDF
          </Button>
          {isPacs008 && (
            <Button
              variant="secondary"
              size="sm"
              icon={<Layers size={13}/>}
              onClick={exportBundle}
              loading={exporting054}
              title="Export pacs.008 + derived camt.054 as a single PDF bundle"
            >
              Export Bundle (+ camt.054)
            </Button>
          )}
          {onEdit   && <Button variant="secondary" size="sm" icon={<Edit2  size={13}/>} onClick={onEdit}>Edit</Button>}
          {onDelete && <Button variant="danger"    size="sm" icon={<Trash2 size={13}/>} onClick={onDelete}>Delete</Button>}
        </div>
      </div>

      {/* Envelope quick-view ────────────────────────────────────────────────── */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
        {[
          { label: message.standard === 'ISO20022' ? 'Sender BIC' : 'Block 1 LTA',  value: message.block1?.logicalTerminalAddress ?? message.senderBIC, icon: <Hash size={10}/> },
          { label: message.standard === 'ISO20022' ? 'Receiver BIC' : 'Block 2 Recv', value: message.block2?.receiverAddress ?? message.receiverBIC, icon: <Network size={10}/> },
          { label: 'Session / Seq', value: message.block1 ? `${message.block1.sessionNumber} / ${message.block1.sequenceNumber}` : message.identifiers.sessionId, icon: <Hash size={10}/> },
          { label: 'Priority',     value: message.block2?.messagePriority === 'U' ? 'Urgent' : message.block2?.messagePriority === 'S' ? 'System' : 'Normal', icon: <Info size={10}/> },
        ].map(item => (
          <div key={item.label} className="bg-slate-800/50 border border-slate-700 rounded-lg px-3 py-2">
            <div className="flex items-center gap-1 mb-1">
              <span className="text-slate-500">{item.icon}</span>
              <p className="text-[10px] text-slate-500 uppercase tracking-wide">{item.label}</p>
            </div>
            <p className="text-xs font-mono font-semibold text-white truncate">{item.value}</p>
          </div>
        ))}
      </div>

      {/* Description ─────────────────────────────────────────────────────────── */}
      {message.description && (
        <div className="bg-slate-800/40 border border-slate-700 rounded-lg px-4 py-2.5">
          <p className="text-xs text-slate-400">
            <span className="text-slate-600 mr-2">Internal Note:</span>
            {message.description}
          </p>
        </div>
      )}

      {/* Tabs ─────────────────────────────────────────────────────────────────── */}
      <div className="flex gap-1 bg-slate-800/50 p-1 rounded-lg w-fit">
        {tabs.map(t => (
          <button
            key={t.id}
            onClick={() => setActiveTab(t.id)}
            className={`px-3 py-1.5 rounded-md text-xs font-medium transition-all cursor-pointer ${
              activeTab === t.id
                ? 'bg-slate-700 text-white shadow-sm'
                : 'text-slate-500 hover:text-slate-300'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* ── Tab: Raw ──────────────────────────────────────────────────────────── */}
      {activeTab === 'raw' && (
        <div className="bg-[#0d1117] border border-slate-700/60 rounded-xl overflow-hidden shadow-xl">
          {/* Title bar */}
          <div className="flex items-center justify-between px-4 py-2 bg-[#161b22] border-b border-slate-700/60">
            <div className="flex items-center gap-2">
              <FileText size={11} className="text-slate-500"/>
              <span className="text-xs font-mono text-slate-400">
                SWIFT FIN &nbsp;·&nbsp; {message.messageType} &nbsp;·&nbsp; Block Format
              </span>
            </div>
            <div className="flex gap-1.5">
              {['#FF5F57','#FEBC2E','#28C840'].map((c,i) => (
                <div key={i} style={{background:c}} className="w-2.5 h-2.5 rounded-full"/>
              ))}
            </div>
          </div>
          <pre className="p-5 text-xs font-mono leading-[1.7] overflow-auto max-h-[65vh] whitespace-pre select-all">
            {parsedLines.map((line, i) => {
              if (line.type === 'blank') return <span key={i} className="block h-1"/>;
              if (line.type === 'block_header')
                return <span key={i} className="block text-blue-400 font-semibold">{line.raw}{'\n'}</span>;
              if (line.type === 'block_end')
                return <span key={i} className="block text-teal-500">{line.raw}{'\n'}</span>;
              if (line.type === 'field_tag') {
                const tagPart  = `:${line.tag}:`;
                const valPart  = line.value ?? '';
                return (
                  <span key={i} className="block">
                    <span className="text-amber-400 font-semibold">{tagPart}</span>
                    <span className="text-emerald-300">{valPart}</span>
                    {'\n'}
                  </span>
                );
              }
              return <span key={i} className="block text-emerald-300">{line.raw}{'\n'}</span>;
            })}
          </pre>
        </div>
      )}

      {/* ── Tab: Annotated ────────────────────────────────────────────────────── */}
      {activeTab === 'annotated' && (
        <div className="bg-[#0d1117] border border-slate-700/60 rounded-xl overflow-hidden shadow-xl">
          <div className="flex items-center justify-between px-4 py-2 bg-[#161b22] border-b border-slate-700/60">
            <div className="flex items-center gap-2">
              <Info size={11} className="text-blue-400"/>
              <span className="text-xs font-mono text-slate-400">
                Annotated View &nbsp;·&nbsp; Hover fields for descriptions
              </span>
            </div>
            <span className="text-[10px] text-slate-600 font-mono">
              click ↕ on a field tag to expand annotation
            </span>
          </div>
          <div className="p-5 overflow-auto max-h-[65vh] space-y-0">
            {parsedLines.map((line, i) => (
              <SyntaxLine key={i} line={line} annotated={true} />
            ))}
          </div>
        </div>
      )}

      {/* ── Tab: Metadata ─────────────────────────────────────────────────────── */}
      {activeTab === 'meta' && (
        <div className="space-y-3">
          {message.standard === 'SWIFT_MT' && message.block1 && (
            <MetaSection title="Block {1} — Basic Header Block" accent="blue">
              <MetaRow label="Application ID"   value={message.block1.applicationId} />
              <MetaRow label="Service ID"        value={message.block1.serviceId} />
              <MetaRow label="LT Address (LTA)"  value={message.block1.logicalTerminalAddress} mono
                note="BIC8 + Logical Terminal (A) + Branch (XXX) = 12 chars" />
              <MetaRow label="Session Number"    value={message.block1.sessionNumber} mono />
              <MetaRow label="Sequence Number"   value={message.block1.sequenceNumber} mono />
              <MetaRow label="Full Block 1"      value={`{1:${message.block1.applicationId}${message.block1.serviceId}${message.block1.logicalTerminalAddress}${message.block1.sessionNumber}${message.block1.sequenceNumber}}`} mono />
            </MetaSection>
          )}
          {message.standard === 'SWIFT_MT' && message.block2 && (
            <MetaSection title="Block {2} — Application Header Block" accent="violet">
              <MetaRow label="I/O Indicator"    value={message.block2.ioIndicator === 'I' ? 'I — Input (Outgoing message sent to SWIFT)' : 'O — Output (Incoming message received)'} />
              <MetaRow label="Message Type"     value={message.block2.messageType} mono />
              <MetaRow label="Receiver Address" value={message.block2.receiverAddress ?? '—'} mono
                note="12-char padded BIC: BIC8 + LT + Branch or BIC11 + LT" />
              <MetaRow label="Priority"         value={
                message.block2.messagePriority === 'U' ? 'U — Urgent' :
                message.block2.messagePriority === 'S' ? 'S — System' : 'N — Normal'} />
            </MetaSection>
          )}
          {message.standard === 'SWIFT_MT' && message.block3 && (
            <MetaSection title="Block {3} — User Header Block" accent="emerald">
              <MetaRow label="Tag {103} Service ID"  value={message.block3.serviceIdentifier ?? '—'}
                note="Identifies the service: CAT = category messages" />
              <MetaRow label="Tag {108} MUR"          value={message.block3.messageUserReference ?? '—'} mono
                note="Message User Reference — up to 16 chars" />
              <MetaRow label="Tag {121} UETR"         value={message.block3.uetr ?? '—'} mono
                note="Unique End-to-End Transaction Reference — RFC 4122 UUID v4 per SWIFT gpi" />
            </MetaSection>
          )}
          {message.standard === 'SWIFT_MT' && message.block5 && (
            <MetaSection title="Block {5} — Trailer Block" accent="slate">
              <MetaRow label="Tag {CHK} Checksum" value={message.block5.checksum ?? '(computed at build time)'} mono
                note="12-character hexadecimal computed checksum of the message" />
            </MetaSection>
          )}
          {message.standard === 'ISO20022' && (
            <MetaSection title="ISO 20022 Envelope" accent="emerald">
              <MetaRow label="Standard"       value="ISO 20022 XML" />
              <MetaRow label="Message Type"   value={String(message.messageType)} mono />
              <MetaRow label="Sender BIC"     value={message.senderBIC} mono />
              <MetaRow label="Receiver BIC"   value={message.receiverBIC} mono />
              <MetaRow label="UETR"           value={message.identifiers.uetr} mono note="RFC 4122 UUID v4" />
            </MetaSection>
          )}
          <MetaSection title="Timestamps & Status" accent="amber">
            <MetaRow label="Created At"  value={new Date(message.createdAt).toUTCString()} />
            <MetaRow label="Updated At"  value={new Date(message.updatedAt).toUTCString()} />
            <MetaRow label="Standard"    value={message.standard === 'ISO20022' ? 'ISO 20022 XML' : 'SWIFT MT FIN'} />
            <MetaRow label="Status"      value={message.status === 'final' ? '✓ FINAL — Transmission ready' : '⏳ DRAFT — Not yet finalised'} />
          </MetaSection>
        </div>
      )}

      {/* ── Tab: Identifiers ──────────────────────────────────────────────────── */}
      {activeTab === 'ids' && (
        <div className="space-y-2">
          {[
            {
              label: 'UETR — Unique End-to-End Transaction Reference',
              tag: 'Block {3} Tag {121}',
              spec: 'RFC 4122 UUID v4 · SWIFT gpi mandatory',
              value: message.identifiers.uetr,
              color: 'blue',
            },
            {
              label: 'Transaction Reference Number',
              tag: 'Field :20:',
              spec: 'Max 16 chars · No special chars · No leading slash',
              value: message.identifiers.transactionRef,
              color: 'emerald',
            },
            {
              label: 'Session Identifier',
              tag: 'Block {1} Session + Sequence',
              spec: 'Session: 4 digits · Sequence: 6 digits',
              value: message.identifiers.sessionId,
              color: 'violet',
            },
            {
              label: 'Message ID',
              tag: 'Internal Routing',
              spec: 'Hex timestamp + random suffix for internal tracking',
              value: message.identifiers.messageId,
              color: 'amber',
            },
            {
              label: 'Routing ID',
              tag: 'Internal Audit Trail',
              spec: 'RID-YYYYMMDD-XXXXXX format for reconciliation',
              value: message.identifiers.routingId,
              color: 'slate',
            },
          ].map(id => (
            <div key={id.label}
              className="bg-slate-800/50 border border-slate-700 rounded-xl p-4 hover:border-slate-600 transition-colors">
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1 flex-wrap">
                    <p className="text-xs font-semibold text-white">{id.label}</p>
                    <span className="text-[10px] font-mono bg-slate-700 text-slate-400 px-1.5 py-0.5 rounded">
                      {id.tag}
                    </span>
                  </div>
                  <p className="text-sm font-mono text-emerald-400 break-all leading-relaxed">{id.value}</p>
                  <p className="text-[10px] text-slate-600 mt-1.5">{id.spec}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

// ─── Sub-components ───────────────────────────────────────────────────────────

const ACCENT_CLASSES: Record<string, string> = {
  blue:   'bg-blue-600',
  violet: 'bg-violet-600',
  emerald:'bg-emerald-600',
  amber:  'bg-amber-500',
  slate:  'bg-slate-500',
};

const MetaSection: React.FC<{
  title: string;
  accent?: string;
  children: React.ReactNode;
}> = ({ title, accent = 'blue', children }) => (
  <div className="bg-slate-800/50 border border-slate-700 rounded-xl overflow-hidden">
    <div className="flex items-center gap-2 px-4 py-2.5 bg-slate-800 border-b border-slate-700">
      <div className={`w-2 h-2 rounded-full ${ACCENT_CLASSES[accent] ?? 'bg-slate-500'}`}/>
      <h4 className="text-xs font-semibold text-slate-200 font-mono">{title}</h4>
    </div>
    <div className="divide-y divide-slate-700/40">
      {children}
    </div>
  </div>
);

const MetaRow: React.FC<{
  label: string;
  value: string;
  mono?: boolean;
  note?: string;
}> = ({ label, value, mono, note }) => (
  <div className="px-4 py-2.5 hover:bg-slate-800/40 transition-colors">
    <div className="flex items-start justify-between gap-4">
      <span className="text-xs text-slate-500 flex-shrink-0 pt-0.5 min-w-[140px]">{label}</span>
      <span className={`text-xs text-slate-200 text-right break-all ${mono ? 'font-mono text-emerald-400' : ''}`}>
        {value}
      </span>
    </div>
    {note && <p className="text-[10px] text-slate-600 mt-1 leading-relaxed">{note}</p>}
  </div>
);
