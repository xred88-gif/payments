import { useState, FormEvent } from 'react';
import {
  Eye, EyeOff, Lock, User, AlertCircle,
  Shield, Globe, ArrowRight, CheckCircle, Wifi
} from 'lucide-react';
import { login, AuthResult } from '../../utils/auth';
import {
  SwiftNavLogo,
  SwiftWordmark,
  SwiftLoginLogo,
  SWIFT_ORANGE,
  SWIFT_NAVY,
  SWIFT_BLUE,
} from './SwiftLogo';

interface Props {
  onLogin: (user: import('../../utils/auth').User) => void;
}

export function LoginPage({ onLogin }: Props) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPw,   setShowPw]   = useState(false);
  const [loading,  setLoading]  = useState(false);
  const [error,    setError]    = useState('');

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!username.trim() || !password) {
      setError('Please enter your username and password.');
      return;
    }
    setLoading(true);
    setError('');
    await new Promise(r => setTimeout(r, 700));
    const result: AuthResult = login(username, password);
    setLoading(false);
    if (result.ok && result.user) {
      onLogin(result.user);
    } else {
      setError(result.error ?? 'Authentication failed. Please check your credentials.');
    }
  };

  return (
    <div
      className="min-h-screen flex flex-col"
      style={{ fontFamily: "'Inter','Helvetica Neue',Arial,sans-serif", background: SWIFT_NAVY }}
    >
      {/* ── Top Nav Bar ─────────────────────────────────────────────────────── */}
      <nav
        className="w-full border-b flex items-center justify-between px-6 md:px-10"
        style={{
          background: SWIFT_BLUE,
          borderColor: 'rgba(255,255,255,0.08)',
          height: 56,
        }}
      >
        {/* Real SWIFT logo in the nav */}
        <SwiftNavLogo />

        <div className="flex items-center gap-5 text-[11px]" style={{ color: 'rgba(255,255,255,0.45)' }}>
          <div className="hidden sm:flex items-center gap-1.5">
            <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            <span>All Systems Operational</span>
          </div>
          <div className="hidden md:flex items-center gap-1.5">
            <Wifi size={11} />
            <span>Secure Connection · TLS 1.3</span>
          </div>
          <div className="flex items-center gap-1">
            <Globe size={11} />
            <span>swift.com</span>
          </div>
        </div>
      </nav>

      {/* ── Hero Split Layout ─────────────────────────────────────────────── */}
      <div className="flex-1 flex items-stretch">

        {/* ── Left Branding Panel ───────────────────────────────────────── */}
        <div
          className="hidden lg:flex flex-col justify-between w-[480px] flex-shrink-0 px-14 py-16"
          style={{
            background: `linear-gradient(160deg, ${SWIFT_BLUE} 0%, ${SWIFT_NAVY} 100%)`,
            borderRight: '1px solid rgba(255,255,255,0.06)',
          }}
        >
          <div>
            {/* Official SWIFT 2023 logo — large */}
            <div className="mb-10">
              <SwiftLoginLogo />
            </div>

            <p className="text-white/55 text-sm leading-relaxed max-w-xs mb-10">
              Connecting over <span className="text-white font-semibold">11,500</span> financial
              institutions across <span className="text-white font-semibold">200+</span> countries
              and territories with secure, standardised financial messaging.
            </p>

            {/* Feature checklist */}
            <div className="space-y-3.5">
              {[
                { label: 'SWIFT MT Message Generation',   sub: 'MT199 · MT799 · MT705 · MT760 · MT700' },
                { label: 'ISO 20022 Messaging Suite',     sub: 'pacs.008 · pacs.009 · pacs.004 · pacs.002 · camt.053 · camt.054 · camt.056 · camt.029 · pain.001 · pain.002' },
                { label: 'SWIFT FIN Block Structure',     sub: 'Blocks 1–5 · UETR · gpi Compliant' },
                { label: 'Secure PDF Export',             sub: 'Bank-grade document output' },
                { label: 'Message History & Archive',     sub: 'Search · Filter · Audit trail' },
              ].map(f => (
                <div key={f.label} className="flex items-start gap-3">
                  <div
                    className="w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5"
                    style={{ background: 'rgba(247,148,29,0.18)', border: `1px solid ${SWIFT_ORANGE}50` }}
                  >
                    <CheckCircle size={11} style={{ color: SWIFT_ORANGE }} />
                  </div>
                  <div>
                    <p className="text-xs font-semibold text-white leading-snug">{f.label}</p>
                    <p className="text-[10px] font-mono mt-0.5" style={{ color: 'rgba(255,255,255,0.35)' }}>{f.sub}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Footer */}
          <div
            className="mt-10 pt-6 border-t text-[10px] leading-relaxed"
            style={{ borderColor: 'rgba(255,255,255,0.08)', color: 'rgba(255,255,255,0.3)' }}
          >
            <p>© 2025 SWIFT SCRL</p>
            <p>Avenue Adèle 1, 1310 La Hulpe, Belgium</p>
            <p className="mt-1" style={{ color: SWIFT_ORANGE }}>swift.com</p>
          </div>
        </div>

        {/* ── Right Login Panel ──────────────────────────────────────────── */}
        <div className="flex-1 flex flex-col items-center justify-center p-6 md:p-12">

          {/* Mobile logo (shown on small screens only) */}
          <div className="lg:hidden flex flex-col items-center gap-4 mb-10">
            {/* Real SWIFT wordmark — centred on mobile */}
            <SwiftWordmark height={44} />
            <p
              style={{
                fontSize: 10,
                letterSpacing: '0.18em',
                color: 'rgba(255,255,255,0.38)',
                textTransform: 'uppercase',
                textAlign: 'center',
              }}
            >
              Financial Messaging Platform
            </p>
          </div>

          <div className="w-full max-w-[360px]">

            {/* Form heading */}
            <div className="mb-8">
              <h2
                className="text-white mb-1.5"
                style={{ fontWeight: 800, fontSize: 26, letterSpacing: '-0.025em' }}
              >
                Sign in
              </h2>
              <p className="text-sm" style={{ color: 'rgba(255,255,255,0.42)' }}>
                Access the SWIFT Financial Messaging Platform using your authorised credentials.
              </p>
            </div>

            {/* Error Banner */}
            {error && (
              <div
                className="flex items-start gap-3 rounded-xl px-4 py-3 mb-5 border"
                style={{ background: 'rgba(220,38,38,0.1)', borderColor: 'rgba(220,38,38,0.35)' }}
              >
                <AlertCircle size={15} className="text-red-400 mt-0.5 flex-shrink-0" />
                <p className="text-xs text-red-300 font-medium leading-relaxed">{error}</p>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">

              {/* Username */}
              <div>
                <label
                  className="block text-xs font-semibold uppercase tracking-widest mb-2"
                  style={{ color: 'rgba(255,255,255,0.45)' }}
                >
                  Username
                </label>
                <div className="relative">
                  <User
                    size={14}
                    className="absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none"
                    style={{ color: 'rgba(255,255,255,0.22)' }}
                  />
                  <input
                    type="text"
                    value={username}
                    onChange={e => setUsername(e.target.value)}
                    placeholder="Enter your username"
                    autoComplete="username"
                    className="w-full pl-10 pr-4 py-3 text-sm text-white placeholder-white/20 rounded-xl border outline-none transition-all"
                    style={{
                      background: 'rgba(255,255,255,0.06)',
                      borderColor: 'rgba(255,255,255,0.11)',
                    }}
                    onFocus={e => {
                      e.currentTarget.style.borderColor = SWIFT_ORANGE;
                      e.currentTarget.style.background = 'rgba(247,148,29,0.07)';
                      e.currentTarget.style.boxShadow = `0 0 0 3px rgba(247,148,29,0.12)`;
                    }}
                    onBlur={e => {
                      e.currentTarget.style.borderColor = 'rgba(255,255,255,0.11)';
                      e.currentTarget.style.background = 'rgba(255,255,255,0.06)';
                      e.currentTarget.style.boxShadow = 'none';
                    }}
                  />
                </div>
              </div>

              {/* Password */}
              <div>
                <label
                  className="block text-xs font-semibold uppercase tracking-widest mb-2"
                  style={{ color: 'rgba(255,255,255,0.45)' }}
                >
                  Password
                </label>
                <div className="relative">
                  <Lock
                    size={14}
                    className="absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none"
                    style={{ color: 'rgba(255,255,255,0.22)' }}
                  />
                  <input
                    type={showPw ? 'text' : 'password'}
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    placeholder="Enter your password"
                    autoComplete="current-password"
                    className="w-full pl-10 pr-11 py-3 text-sm text-white placeholder-white/20 rounded-xl border outline-none transition-all"
                    style={{
                      background: 'rgba(255,255,255,0.06)',
                      borderColor: 'rgba(255,255,255,0.11)',
                    }}
                    onFocus={e => {
                      e.currentTarget.style.borderColor = SWIFT_ORANGE;
                      e.currentTarget.style.background = 'rgba(247,148,29,0.07)';
                      e.currentTarget.style.boxShadow = `0 0 0 3px rgba(247,148,29,0.12)`;
                    }}
                    onBlur={e => {
                      e.currentTarget.style.borderColor = 'rgba(255,255,255,0.11)';
                      e.currentTarget.style.background = 'rgba(255,255,255,0.06)';
                      e.currentTarget.style.boxShadow = 'none';
                    }}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPw(s => !s)}
                    className="absolute right-3.5 top-1/2 -translate-y-1/2 transition-colors cursor-pointer"
                    style={{ color: 'rgba(255,255,255,0.3)' }}
                    tabIndex={-1}
                  >
                    {showPw ? <EyeOff size={14} /> : <Eye size={14} />}
                  </button>
                </div>
              </div>

              {/* Submit */}
              <button
                type="submit"
                disabled={loading}
                className="w-full flex items-center justify-center gap-2.5 py-3.5 rounded-xl text-sm font-bold text-white transition-all mt-3 cursor-pointer disabled:opacity-60 disabled:cursor-not-allowed"
                style={{
                  background: loading
                    ? `rgba(247,148,29,0.55)`
                    : `linear-gradient(135deg, ${SWIFT_ORANGE} 0%, #E8820A 100%)`,
                  boxShadow: loading ? 'none' : '0 4px 20px rgba(247,148,29,0.35)',
                }}
                onMouseEnter={e => {
                  if (!loading) (e.currentTarget as HTMLButtonElement).style.boxShadow = '0 6px 28px rgba(247,148,29,0.5)';
                }}
                onMouseLeave={e => {
                  (e.currentTarget as HTMLButtonElement).style.boxShadow = loading ? 'none' : '0 4px 20px rgba(247,148,29,0.35)';
                }}
              >
                {loading ? (
                  <>
                    <svg className="animate-spin w-4 h-4" viewBox="0 0 24 24" fill="none">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"/>
                    </svg>
                    Authenticating…
                  </>
                ) : (
                  <>
                    <Shield size={14} />
                    Sign In to SWIFT
                    <ArrowRight size={13} />
                  </>
                )}
              </button>
            </form>

            {/* Security badges */}
            <div className="flex items-center justify-center gap-5 mt-8 flex-wrap">
              {[
                { icon: <Shield size={10} />,   label: 'TLS 1.3 Encrypted' },
                { icon: <Lock size={10} />,     label: 'ISO 27001' },
                { icon: <Globe size={10} />,    label: 'SWIFT FIN Certified' },
              ].map(b => (
                <div
                  key={b.label}
                  className="flex items-center gap-1.5 text-[10px]"
                  style={{ color: 'rgba(255,255,255,0.22)' }}
                >
                  {b.icon}
                  <span>{b.label}</span>
                </div>
              ))}
            </div>

            {/* Fine print */}
            <p
              className="text-center text-[10px] mt-6 leading-relaxed"
              style={{ color: 'rgba(255,255,255,0.2)' }}
            >
              Authorised users only. All access attempts are logged and monitored
              in accordance with SWIFT security policy.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
