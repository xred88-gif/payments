import { useState, useRef, useEffect, FormEvent } from 'react';
import {
  LogOut, Lock, CheckCircle2, AlertCircle, X,
  ChevronUp, Shield, Globe, Building2, Mail, User
} from 'lucide-react';
import { User as AuthUser, logout, updatePassword, avatarColor, initials } from '../../utils/auth';
import { SwiftWordmark } from './SwiftLogo';

interface Props {
  user: AuthUser;
  onLogout: () => void;
}

const SWIFT_BLUE   = '#003366';
const SWIFT_ORANGE = '#F7941D';

const ROLE_STYLE: Record<string, { bg: string; color: string; label: string }> = {
  admin:    { bg: 'rgba(247,148,29,0.15)', color: SWIFT_ORANGE,    label: 'Administrator' },
  operator: { bg: 'rgba(0,102,204,0.2)',   color: '#60A5FA',        label: 'Operator'      },
  viewer:   { bg: 'rgba(255,255,255,0.08)', color: 'rgba(255,255,255,0.5)', label: 'Viewer' },
};

export function UserAvatar({ user, size = 'md' }: { user: AuthUser; size?: 'sm' | 'md' | 'lg' }) {
  const { bg, text } = avatarColor(user.avatar);
  const sz = size === 'sm' ? 'w-7 h-7 text-[10px]' : size === 'lg' ? 'w-11 h-11 text-sm' : 'w-9 h-9 text-xs';
  return (
    <div className={`${sz} ${bg} ${text} rounded-xl flex items-center justify-center font-black flex-shrink-0 select-none uppercase tracking-tight`}>
      {initials(user.fullName)}
    </div>
  );
}

function ChangePasswordModal({ user, onClose }: { user: AuthUser; onClose: () => void }) {
  const [current, setCurrent] = useState('');
  const [next,    setNext]    = useState('');
  const [confirm, setConfirm] = useState('');
  const [loading, setLoading] = useState(false);
  const [error,   setError]   = useState('');
  const [done,    setDone]    = useState(false);

  const inputStyle = {
    background: 'rgba(255,255,255,0.06)',
    borderColor: 'rgba(255,255,255,0.12)',
    color: 'white',
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (next !== confirm) { setError('Passwords do not match.'); return; }
    setLoading(true); setError('');
    await new Promise(r => setTimeout(r, 300));
    const res = updatePassword(user.id, current, next);
    setLoading(false);
    if (res.ok) { setDone(true); setTimeout(onClose, 1500); }
    else setError(res.error ?? 'Failed.');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: 'rgba(0,10,26,0.85)', backdropFilter: 'blur(8px)' }}>
      <div
        className="w-full max-w-sm rounded-2xl overflow-hidden shadow-2xl border"
        style={{ background: '#0A1628', borderColor: 'rgba(255,255,255,0.1)' }}
      >
        {/* Header */}
        <div
          className="flex items-center justify-between px-5 py-4 border-b"
          style={{ borderColor: 'rgba(255,255,255,0.08)', background: SWIFT_BLUE }}
        >
          <div className="flex items-center gap-2.5">
            {/* Real SWIFT logo */}
            <SwiftWordmark height={18} />
            <div className="w-px h-5 mx-1" style={{ background: 'rgba(255,255,255,0.15)' }} />
            <div>
              <p className="text-xs font-black text-white tracking-tight">Change Password</p>
              <p className="text-[9px] text-white/40 uppercase tracking-widest">Security Settings</p>
            </div>
          </div>
          <button onClick={onClose} className="text-white/30 hover:text-white/70 cursor-pointer transition-colors">
            <X size={14} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-3">
          {done && (
            <div className="flex items-center gap-2 text-emerald-400 text-sm font-semibold py-2">
              <CheckCircle2 size={15} />
              Password updated successfully!
            </div>
          )}
          {error && (
            <div
              className="flex items-start gap-2.5 rounded-xl px-3 py-2.5 border"
              style={{ background: 'rgba(220,38,38,0.1)', borderColor: 'rgba(220,38,38,0.3)' }}
            >
              <AlertCircle size={13} className="text-red-400 mt-0.5 flex-shrink-0" />
              <p className="text-xs text-red-300">{error}</p>
            </div>
          )}
          {[
            { label: 'Current Password', val: current, set: setCurrent, auto: 'current-password' },
            { label: 'New Password',     val: next,    set: setNext,    auto: 'new-password'     },
            { label: 'Confirm New',      val: confirm, set: setConfirm, auto: 'new-password'     },
          ].map(f => (
            <div key={f.label}>
              <label className="block text-[10px] font-semibold uppercase tracking-widest mb-1.5" style={{ color: 'rgba(255,255,255,0.4)' }}>{f.label}</label>
              <input
                type="password"
                value={f.val}
                onChange={e => { f.set(e.target.value); setError(''); }}
                autoComplete={f.auto}
                className="w-full px-3.5 py-2.5 text-sm rounded-xl border outline-none transition-all placeholder-white/15"
                style={inputStyle}
                placeholder="••••••••"
                onFocus={e => { e.currentTarget.style.borderColor = SWIFT_ORANGE; e.currentTarget.style.background = 'rgba(247,148,29,0.06)'; }}
                onBlur={e => { e.currentTarget.style.borderColor = 'rgba(255,255,255,0.12)'; e.currentTarget.style.background = 'rgba(255,255,255,0.06)'; }}
              />
            </div>
          ))}

          <button
            type="submit"
            disabled={loading || done}
            className="w-full py-2.5 rounded-xl text-sm font-bold text-white transition-all cursor-pointer disabled:opacity-60 disabled:cursor-not-allowed mt-1"
            style={{ background: SWIFT_ORANGE }}
          >
            {loading ? (
              <span className="flex items-center justify-center gap-2">
                <svg className="animate-spin w-3.5 h-3.5" viewBox="0 0 24 24" fill="none">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"/>
                </svg>
                Updating…
              </span>
            ) : 'Update Password'}
          </button>
        </form>
      </div>
    </div>
  );
}

export function UserMenu({ user, onLogout }: Props) {
  const [open,   setOpen]   = useState(false);
  const [pwOpen, setPwOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const role = ROLE_STYLE[user.role] ?? ROLE_STYLE.viewer;

  const handleLogout = () => {
    logout();
    onLogout();
  };

  return (
    <>
      {pwOpen && <ChangePasswordModal user={user} onClose={() => setPwOpen(false)} />}

      <div ref={ref} className="relative">
        {/* Trigger button */}
        <button
          onClick={() => setOpen(o => !o)}
          className="w-full flex items-center gap-2.5 p-2.5 rounded-xl border transition-all cursor-pointer group"
          style={{
            background: open ? 'rgba(247,148,29,0.08)' : 'rgba(255,255,255,0.04)',
            borderColor: open ? `${SWIFT_ORANGE}50` : 'rgba(255,255,255,0.08)',
          }}
        >
          {/* Avatar */}
          <UserAvatar user={user} size="sm" />
          <div className="flex-1 min-w-0 text-left">
            <p className="text-xs font-bold text-white truncate leading-tight">{user.fullName}</p>
            <p className="text-[10px] truncate leading-tight" style={{ color: SWIFT_ORANGE }}>{role.label}</p>
          </div>
          <ChevronUp
            size={12}
            className="flex-shrink-0 transition-transform"
            style={{ color: 'rgba(255,255,255,0.3)', transform: open ? 'rotate(0deg)' : 'rotate(180deg)' }}
          />
        </button>

        {/* Dropdown */}
        {open && (
          <div
            className="absolute bottom-full left-0 right-0 mb-2 rounded-2xl border shadow-2xl overflow-hidden"
            style={{ background: '#0B1A2E', borderColor: 'rgba(255,255,255,0.1)', zIndex: 100 }}
          >
            {/* User header */}
            <div
              className="px-4 py-4 border-b"
              style={{ borderColor: 'rgba(255,255,255,0.08)', background: SWIFT_BLUE }}
            >
              <div className="flex items-center gap-3 mb-3">
                <UserAvatar user={user} size="lg" />
                <div className="min-w-0">
                  <p className="text-sm font-black text-white leading-tight truncate">{user.fullName}</p>
                  <div
                    className="inline-flex items-center gap-1 mt-1 px-1.5 py-0.5 rounded text-[9px] font-black uppercase tracking-widest"
                    style={{ background: role.bg, color: role.color }}
                  >
                    <Shield size={8} />
                    {role.label}
                  </div>
                </div>
              </div>

              {/* Info rows */}
              <div className="space-y-1.5">
                {[
                  { icon: <User size={9} />,      val: user.username },
                  { icon: <Mail size={9} />,      val: user.email },
                  { icon: <Building2 size={9} />, val: user.institution || 'No institution' },
                  { icon: <Globe size={9} />,     val: 'swift.com' },
                ].map((r, i) => (
                  <div key={i} className="flex items-center gap-2 text-[10px]" style={{ color: 'rgba(255,255,255,0.45)' }}>
                    <span style={{ color: SWIFT_ORANGE }}>{r.icon}</span>
                    <span className="truncate">{r.val}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Last login */}
            {user.lastLogin && (
              <div
                className="px-4 py-2 text-[10px] border-b"
                style={{ borderColor: 'rgba(255,255,255,0.06)', color: 'rgba(255,255,255,0.3)' }}
              >
                Last login: {new Date(user.lastLogin).toLocaleString()}
              </div>
            )}

            {/* Actions */}
            <div className="p-2 space-y-1">
              <button
                onClick={() => { setOpen(false); setPwOpen(true); }}
                className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-left text-xs font-semibold transition-all cursor-pointer"
                style={{ color: 'rgba(255,255,255,0.65)' }}
                onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.background = 'rgba(247,148,29,0.1)'; (e.currentTarget as HTMLButtonElement).style.color = SWIFT_ORANGE; }}
                onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.background = 'transparent'; (e.currentTarget as HTMLButtonElement).style.color = 'rgba(255,255,255,0.65)'; }}
              >
                <Lock size={13} />
                Change Password
              </button>

              <button
                onClick={handleLogout}
                className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-left text-xs font-semibold transition-all cursor-pointer text-red-400"
                onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.background = 'rgba(220,38,38,0.12)'; }}
                onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.background = 'transparent'; }}
              >
                <LogOut size={13} />
                Sign Out of SWIFT
              </button>
            </div>

            {/* Footer */}
            <div
              className="px-4 py-2.5 border-t flex items-center justify-center gap-2"
              style={{ borderColor: 'rgba(255,255,255,0.06)' }}
            >
              <SwiftWordmark height={14} />
              <span className="text-[9px]" style={{ color: 'rgba(255,255,255,0.2)' }}>
                · © 2025 SWIFT SCRL · swift.com
              </span>
            </div>
          </div>
        )}
      </div>
    </>
  );
}
