import { useState, FormEvent } from 'react';
import {
  Eye, EyeOff, Lock, User, Mail, Building2,
  AlertCircle, ChevronLeft, CheckCircle2, Shield, Globe, ArrowRight
} from 'lucide-react';
import { register, User as AuthUser } from '../../utils/auth';

interface Props {
  onRegistered: (user: AuthUser) => void;
  onGoLogin: () => void;
}

type Role = 'admin' | 'operator' | 'viewer';

const SWIFT_NAVY   = '#001A3A';
const SWIFT_BLUE   = '#003366';
const SWIFT_ORANGE = '#F7941D';

const ROLES: { value: Role; label: string; desc: string; badge: string }[] = [
  { value: 'operator', label: 'Operator',  desc: 'Create & manage messages',  badge: 'OP' },
  { value: 'viewer',   label: 'Viewer',    desc: 'Read-only access',           badge: 'VW' },
  { value: 'admin',    label: 'Admin',     desc: 'Full system access',         badge: 'AD' },
];

export function RegisterPage({ onRegistered, onGoLogin }: Props) {
  const [form, setForm] = useState({
    username:    '',
    password:    '',
    confirm:     '',
    fullName:    '',
    email:       '',
    institution: '',
    role:        'operator' as Role,
  });
  const [showPw,  setShowPw]  = useState(false);
  const [showCfm, setShowCfm] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error,   setError]   = useState('');
  const [success, setSuccess] = useState(false);

  const set = (k: keyof typeof form, v: string) => {
    setForm(f => ({ ...f, [k]: v }));
    setError('');
  };

  const pwStrength = (pw: string) => {
    let score = 0;
    if (pw.length >= 6)  score++;
    if (pw.length >= 10) score++;
    if (/[A-Z]/.test(pw)) score++;
    if (/[0-9]/.test(pw)) score++;
    if (/[^A-Za-z0-9]/.test(pw)) score++;
    const map = [
      { label: '',          color: '#334155' },
      { label: 'Weak',      color: '#EF4444' },
      { label: 'Fair',      color: '#F59E0B' },
      { label: 'Good',      color: '#EAB308' },
      { label: 'Strong',    color: '#22C55E' },
      { label: 'Excellent', color: SWIFT_ORANGE },
    ];
    return { score, ...map[score] };
  };

  const strength = pwStrength(form.password);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (form.password !== form.confirm) { setError('Passwords do not match.'); return; }
    setLoading(true);
    setError('');
    await new Promise(r => setTimeout(r, 500));
    const result = register(form.username, form.password, form.fullName, form.email, form.institution, form.role);
    setLoading(false);
    if (result.ok && result.user) {
      setSuccess(true);
      setTimeout(() => onRegistered(result.user!), 1500);
    } else {
      setError(result.error ?? 'Registration failed.');
    }
  };

  const inputBase = {
    background: 'rgba(255,255,255,0.06)',
    borderColor: 'rgba(255,255,255,0.12)',
  };

  if (success) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: SWIFT_NAVY }}>
        <div className="text-center">
          <div
            className="w-20 h-20 rounded-2xl flex items-center justify-center mx-auto mb-5 animate-bounce shadow-2xl"
            style={{ background: SWIFT_ORANGE }}
          >
            <CheckCircle2 size={36} className="text-white" />
          </div>
          <h2 className="text-2xl font-black text-white mb-2">Account Created!</h2>
          <p className="text-sm" style={{ color: 'rgba(255,255,255,0.45)' }}>
            Welcome to SWIFT — signing you in…
          </p>
        </div>
      </div>
    );
  }

  return (
    <div
      className="min-h-screen flex flex-col"
      style={{ fontFamily: "'Inter', 'Helvetica Neue', Arial, sans-serif", background: SWIFT_NAVY }}
    >
      {/* ── Top Nav ──────────────────────────────────────────────────────── */}
      <nav
        className="w-full flex items-center justify-between px-6 md:px-10"
        style={{ background: SWIFT_BLUE, borderBottom: '1px solid rgba(255,255,255,0.08)', height: 56 }}
      >
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: SWIFT_ORANGE }}>
            <svg width="14" height="18" viewBox="0 0 14 18" fill="none">
              <path d="M12 2.5C12 2.5 9.5 1 7 1C4.239 1 2 2.962 2 5.5C2 8.038 4.5 9.125 7 9.75C9.5 10.375 12 11.462 12 14.5C12 17.038 9.761 17.5 7 17.5C4.5 17.5 2 16.5 1 15" stroke="white" strokeWidth="2" strokeLinecap="round" fill="none" />
            </svg>
          </div>
          <div className="flex items-baseline gap-0.5">
            <span className="font-black text-base tracking-tight text-white">SWIFT</span>
            <span className="text-sm font-bold" style={{ color: SWIFT_ORANGE }}>.com</span>
          </div>
        </div>
        <button
          type="button"
          onClick={onGoLogin}
          className="flex items-center gap-1.5 text-xs font-semibold transition-colors cursor-pointer"
          style={{ color: 'rgba(255,255,255,0.5)' }}
        >
          <ChevronLeft size={13} />
          Back to Sign In
        </button>
      </nav>

      {/* ── Main ─────────────────────────────────────────────────────────── */}
      <div className="flex-1 flex items-center justify-center p-6 py-10">
        <div className="w-full max-w-lg">

          {/* Heading */}
          <div className="mb-7">
            <div
              className="w-12 h-12 rounded-2xl flex items-center justify-center mb-4 shadow-xl"
              style={{ background: SWIFT_ORANGE }}
            >
              <svg width="20" height="26" viewBox="0 0 14 18" fill="none">
                <path d="M12 2.5C12 2.5 9.5 1 7 1C4.239 1 2 2.962 2 5.5C2 8.038 4.5 9.125 7 9.75C9.5 10.375 12 11.462 12 14.5C12 17.038 9.761 17.5 7 17.5C4.5 17.5 2 16.5 1 15" stroke="white" strokeWidth="1.8" strokeLinecap="round" fill="none" />
              </svg>
            </div>
            <h1 className="text-2xl font-black text-white mb-1.5" style={{ letterSpacing: '-0.02em' }}>
              Create SWIFT Account
            </h1>
            <p className="text-sm" style={{ color: 'rgba(255,255,255,0.4)' }}>
              Register to access the SWIFT Secure Financial Messaging Platform.
            </p>
          </div>

          {/* Error */}
          {error && (
            <div
              className="flex items-start gap-3 rounded-xl px-4 py-3 mb-5 border"
              style={{ background: 'rgba(220,38,38,0.1)', borderColor: 'rgba(220,38,38,0.3)' }}
            >
              <AlertCircle size={15} className="text-red-400 mt-0.5 flex-shrink-0" />
              <p className="text-xs text-red-300 font-medium">{error}</p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">

            {/* Full Name */}
            <div>
              <label className="block text-xs font-semibold uppercase tracking-widest mb-2" style={{ color: 'rgba(255,255,255,0.45)' }}>Full Name</label>
              <div className="relative">
                <User size={14} className="absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" style={{ color: 'rgba(255,255,255,0.2)' }} />
                <input
                  type="text"
                  value={form.fullName}
                  onChange={e => set('fullName', e.target.value)}
                  placeholder="John Smith"
                  className="w-full pl-10 pr-4 py-3 text-sm text-white placeholder-white/20 rounded-xl border outline-none transition-all"
                  style={inputBase}
                  onFocus={e => { e.currentTarget.style.borderColor = SWIFT_ORANGE; e.currentTarget.style.background = 'rgba(247,148,29,0.06)'; }}
                  onBlur={e => { e.currentTarget.style.borderColor = 'rgba(255,255,255,0.12)'; e.currentTarget.style.background = 'rgba(255,255,255,0.06)'; }}
                />
              </div>
            </div>

            {/* Username & Email */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold uppercase tracking-widest mb-2" style={{ color: 'rgba(255,255,255,0.45)' }}>Username</label>
                <input
                  type="text"
                  value={form.username}
                  onChange={e => set('username', e.target.value)}
                  placeholder="jsmith"
                  autoComplete="username"
                  className="w-full px-3.5 py-3 text-sm text-white placeholder-white/20 rounded-xl border outline-none transition-all"
                  style={inputBase}
                  onFocus={e => { e.currentTarget.style.borderColor = SWIFT_ORANGE; e.currentTarget.style.background = 'rgba(247,148,29,0.06)'; }}
                  onBlur={e => { e.currentTarget.style.borderColor = 'rgba(255,255,255,0.12)'; e.currentTarget.style.background = 'rgba(255,255,255,0.06)'; }}
                />
              </div>
              <div>
                <label className="block text-xs font-semibold uppercase tracking-widest mb-2" style={{ color: 'rgba(255,255,255,0.45)' }}>Email</label>
                <div className="relative">
                  <Mail size={14} className="absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" style={{ color: 'rgba(255,255,255,0.2)' }} />
                  <input
                    type="email"
                    value={form.email}
                    onChange={e => set('email', e.target.value)}
                    placeholder="j@bank.com"
                    autoComplete="email"
                    className="w-full pl-10 pr-3 py-3 text-sm text-white placeholder-white/20 rounded-xl border outline-none transition-all"
                    style={inputBase}
                    onFocus={e => { e.currentTarget.style.borderColor = SWIFT_ORANGE; e.currentTarget.style.background = 'rgba(247,148,29,0.06)'; }}
                    onBlur={e => { e.currentTarget.style.borderColor = 'rgba(255,255,255,0.12)'; e.currentTarget.style.background = 'rgba(255,255,255,0.06)'; }}
                  />
                </div>
              </div>
            </div>

            {/* Institution */}
            <div>
              <label className="block text-xs font-semibold uppercase tracking-widest mb-2" style={{ color: 'rgba(255,255,255,0.45)' }}>Institution / Bank</label>
              <div className="relative">
                <Building2 size={14} className="absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" style={{ color: 'rgba(255,255,255,0.2)' }} />
                <input
                  type="text"
                  value={form.institution}
                  onChange={e => set('institution', e.target.value)}
                  placeholder="Global Trade Bank"
                  className="w-full pl-10 pr-4 py-3 text-sm text-white placeholder-white/20 rounded-xl border outline-none transition-all"
                  style={inputBase}
                  onFocus={e => { e.currentTarget.style.borderColor = SWIFT_ORANGE; e.currentTarget.style.background = 'rgba(247,148,29,0.06)'; }}
                  onBlur={e => { e.currentTarget.style.borderColor = 'rgba(255,255,255,0.12)'; e.currentTarget.style.background = 'rgba(255,255,255,0.06)'; }}
                />
              </div>
            </div>

            {/* Role selector */}
            <div>
              <label className="block text-xs font-semibold uppercase tracking-widest mb-2" style={{ color: 'rgba(255,255,255,0.45)' }}>Access Role</label>
              <div className="grid grid-cols-3 gap-2">
                {ROLES.map(r => (
                  <button
                    key={r.value}
                    type="button"
                    onClick={() => set('role', r.value)}
                    className="flex flex-col items-start p-3 rounded-xl border text-left transition-all cursor-pointer"
                    style={{
                      background: form.role === r.value ? 'rgba(247,148,29,0.12)' : 'rgba(255,255,255,0.04)',
                      borderColor: form.role === r.value ? `${SWIFT_ORANGE}80` : 'rgba(255,255,255,0.1)',
                    }}
                  >
                    <span
                      className="text-[9px] font-black tracking-widest px-1.5 py-0.5 rounded mb-1.5"
                      style={{
                        background: form.role === r.value ? 'rgba(247,148,29,0.25)' : 'rgba(255,255,255,0.08)',
                        color: form.role === r.value ? SWIFT_ORANGE : 'rgba(255,255,255,0.4)',
                      }}
                    >
                      {r.badge}
                    </span>
                    <p className="text-xs font-bold text-white">{r.label}</p>
                    <p className="text-[10px] mt-0.5 leading-tight" style={{ color: 'rgba(255,255,255,0.35)' }}>{r.desc}</p>
                  </button>
                ))}
              </div>
            </div>

            {/* Password row */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold uppercase tracking-widest mb-2" style={{ color: 'rgba(255,255,255,0.45)' }}>Password</label>
                <div className="relative">
                  <Lock size={14} className="absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" style={{ color: 'rgba(255,255,255,0.2)' }} />
                  <input
                    type={showPw ? 'text' : 'password'}
                    value={form.password}
                    onChange={e => set('password', e.target.value)}
                    placeholder="Min 6 chars"
                    autoComplete="new-password"
                    className="w-full pl-10 pr-10 py-3 text-sm text-white placeholder-white/20 rounded-xl border outline-none transition-all"
                    style={inputBase}
                    onFocus={e => { e.currentTarget.style.borderColor = SWIFT_ORANGE; e.currentTarget.style.background = 'rgba(247,148,29,0.06)'; }}
                    onBlur={e => { e.currentTarget.style.borderColor = 'rgba(255,255,255,0.12)'; e.currentTarget.style.background = 'rgba(255,255,255,0.06)'; }}
                  />
                  <button type="button" onClick={() => setShowPw(s => !s)} className="absolute right-3 top-1/2 -translate-y-1/2 cursor-pointer" style={{ color: 'rgba(255,255,255,0.3)' }}>
                    {showPw ? <EyeOff size={13} /> : <Eye size={13} />}
                  </button>
                </div>
                {form.password && (
                  <div className="mt-2 space-y-1">
                    <div className="flex gap-1">
                      {[1,2,3,4,5].map(i => (
                        <div
                          key={i}
                          className="h-1 flex-1 rounded-full transition-all"
                          style={{ background: i <= strength.score ? strength.color : 'rgba(255,255,255,0.1)' }}
                        />
                      ))}
                    </div>
                    {strength.label && (
                      <p className="text-[10px]" style={{ color: strength.color }}>{strength.label}</p>
                    )}
                  </div>
                )}
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-widest mb-2" style={{ color: 'rgba(255,255,255,0.45)' }}>Confirm</label>
                <div className="relative">
                  <Lock size={14} className="absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" style={{ color: 'rgba(255,255,255,0.2)' }} />
                  <input
                    type={showCfm ? 'text' : 'password'}
                    value={form.confirm}
                    onChange={e => set('confirm', e.target.value)}
                    placeholder="Repeat password"
                    autoComplete="new-password"
                    className="w-full pl-10 pr-10 py-3 text-sm text-white placeholder-white/20 rounded-xl border outline-none transition-all"
                    style={{
                      ...inputBase,
                      borderColor: form.confirm
                        ? form.confirm === form.password ? '#22C55E80' : '#EF444480'
                        : 'rgba(255,255,255,0.12)',
                    }}
                    onFocus={e => { e.currentTarget.style.borderColor = SWIFT_ORANGE; e.currentTarget.style.background = 'rgba(247,148,29,0.06)'; }}
                    onBlur={e => {
                      if (form.confirm && form.confirm === form.password) e.currentTarget.style.borderColor = '#22C55E80';
                      else if (form.confirm) e.currentTarget.style.borderColor = '#EF444480';
                      else e.currentTarget.style.borderColor = 'rgba(255,255,255,0.12)';
                      e.currentTarget.style.background = 'rgba(255,255,255,0.06)';
                    }}
                  />
                  <button type="button" onClick={() => setShowCfm(s => !s)} className="absolute right-3 top-1/2 -translate-y-1/2 cursor-pointer" style={{ color: 'rgba(255,255,255,0.3)' }}>
                    {showCfm ? <EyeOff size={13} /> : <Eye size={13} />}
                  </button>
                  {form.confirm && form.confirm === form.password && (
                    <CheckCircle2 size={13} className="absolute right-9 top-1/2 -translate-y-1/2 text-emerald-400 pointer-events-none" />
                  )}
                </div>
              </div>
            </div>

            {/* Submit */}
            <button
              type="submit"
              disabled={loading}
              className="w-full flex items-center justify-center gap-2.5 py-3 rounded-xl text-sm font-bold text-white transition-all cursor-pointer disabled:opacity-60 disabled:cursor-not-allowed mt-2"
              style={{ background: loading ? 'rgba(247,148,29,0.5)' : SWIFT_ORANGE }}
            >
              {loading ? (
                <>
                  <svg className="animate-spin w-4 h-4" viewBox="0 0 24 24" fill="none">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"/>
                  </svg>
                  Creating Account…
                </>
              ) : (
                <>
                  <Shield size={14} />
                  Create SWIFT Account
                  <ArrowRight size={13} />
                </>
              )}
            </button>
          </form>

          {/* Sign in link */}
          <p className="text-center text-xs mt-6" style={{ color: 'rgba(255,255,255,0.3)' }}>
            Already registered?{' '}
            <button
              type="button"
              onClick={onGoLogin}
              className="font-semibold cursor-pointer transition-colors"
              style={{ color: SWIFT_ORANGE }}
            >
              Sign In
            </button>
          </p>

          {/* Trust badges */}
          <div className="flex items-center justify-center gap-5 mt-8 flex-wrap">
            {[
              { icon: <Shield size={10} />, label: 'TLS 1.3 Encrypted' },
              { icon: <Lock size={10} />,   label: 'ISO 27001' },
              { icon: <Globe size={10} />,  label: 'swift.com' },
            ].map(b => (
              <div key={b.label} className="flex items-center gap-1.5 text-[10px]" style={{ color: 'rgba(255,255,255,0.2)' }}>
                {b.icon}<span>{b.label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
