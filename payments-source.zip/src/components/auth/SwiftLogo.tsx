/**
 * SWIFT 2023 Official Logo
 * Source: https://upload.wikimedia.org/wikipedia/commons/4/40/SWIFT_2023_logo.svg
 *
 * The 2023 SWIFT logo is the wordmark "SWIFT" in a rounded bold sans-serif,
 * rendered entirely in SWIFT orange (#F7941D) on transparent background.
 *
 * We use the official Wikimedia CDN URL directly so the exact brand asset is
 * always shown.  All components below use this URL — no hand-drawn paths.
 */

const LOGO_URL =
  'https://upload.wikimedia.org/wikipedia/commons/4/40/SWIFT_2023_logo.svg';

const SWIFT_ORANGE = '#F7941D';
const SWIFT_NAVY   = '#001A3A';
const SWIFT_BLUE   = '#003366';

/* ─────────────────────────────────────────────────────────────────────────────
   SwiftWordmark
   The raw SVG wordmark at any size.  Use on light or dark backgrounds.
   The logo is already orange so it reads on both navy and white.
───────────────────────────────────────────────────────────────────────────── */
export function SwiftWordmark({
  height = 36,
  className = '',
}: {
  height?: number;
  className?: string;
}) {
  // Official aspect ratio of the 2023 wordmark is ≈ 3.78 : 1
  const width = Math.round(height * 3.78);
  return (
    <img
      src={LOGO_URL}
      alt="SWIFT"
      width={width}
      height={height}
      className={className}
      style={{ display: 'block', objectFit: 'contain' }}
      draggable={false}
    />
  );
}

/* ─────────────────────────────────────────────────────────────────────────────
   SwiftIconBadge
   Compact square badge: orange rounded rect with white "S" glyph.
   Used in tight spaces — sidebar top-left corner, loading screen, dropdowns.
   We derive the "S" from the official wordmark by cropping the first letter.
   Because cropping isn't possible with a simple <img>, we re-render the full
   wordmark clipped inside an orange square.
───────────────────────────────────────────────────────────────────────────── */
export function SwiftIconBadge({ size = 36 }: { size?: number }) {
  const radius = Math.round(size * 0.2);
  return (
    <div
      style={{
        width: size,
        height: size,
        borderRadius: radius,
        background: SWIFT_ORANGE,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        flexShrink: 0,
        overflow: 'hidden',
      }}
    >
      {/* Show the full wordmark scaled up so only "S" is visible */}
      <img
        src={LOGO_URL}
        alt="SWIFT"
        style={{
          width: size * 5.5,      // scale so first letter fills the badge
          height: 'auto',
          marginLeft: -(size * 0.1),  // nudge left to centre the S glyph
          filter: 'brightness(0) invert(1)', // turn orange → white
          display: 'block',
          flexShrink: 0,
        }}
        draggable={false}
      />
    </div>
  );
}

/* ─────────────────────────────────────────────────────────────────────────────
   SwiftNavLogo
   Horizontal lockup used in the top navigation bar of the login page.
   Icon badge  +  full wordmark  +  optional ".com" label
───────────────────────────────────────────────────────────────────────────── */
export function SwiftNavLogo({ dark = false }: { dark?: boolean }) {
  void dark; // logo is always orange — looks fine on both backgrounds
  return (
    <div className="flex items-center gap-3 select-none">
      <SwiftIconBadge size={30} />
      <SwiftWordmark height={22} />
      <span
        style={{
          fontFamily: "'Inter','Helvetica Neue',Arial,sans-serif",
          fontWeight: 700,
          fontSize: 13,
          color: SWIFT_ORANGE,
          lineHeight: 1,
          marginLeft: -4,
          opacity: 0.85,
        }}
      >
        .com
      </span>
    </div>
  );
}

/* ─────────────────────────────────────────────────────────────────────────────
   SwiftSidebarLogo
   Full branding block used in the sidebar header:
     [badge]  SWIFT wordmark
              Financial Messaging  (sub-label)
───────────────────────────────────────────────────────────────────────────── */
export function SwiftSidebarLogo() {
  return (
    <div className="flex items-center gap-3 select-none">
      <SwiftIconBadge size={34} />
      <div>
        <SwiftWordmark height={20} />
        <p
          style={{
            fontFamily: "'Inter','Helvetica Neue',Arial,sans-serif",
            fontSize: 9,
            fontWeight: 600,
            letterSpacing: '0.14em',
            color: 'rgba(255,255,255,0.35)',
            textTransform: 'uppercase',
            lineHeight: 1,
            marginTop: 4,
          }}
        >
          Financial Messaging
        </p>
      </div>
    </div>
  );
}

/* ─────────────────────────────────────────────────────────────────────────────
   SwiftLoginLogo
   Large centred branding used on the left panel of the login page.
   Shows the full wordmark at a large size + institution sub-line.
───────────────────────────────────────────────────────────────────────────── */
export function SwiftLoginLogo() {
  return (
    <div className="flex flex-col items-start select-none gap-3">
      {/* Large wordmark */}
      <SwiftWordmark height={56} />

      {/* Institution full name */}
      <p
        style={{
          fontFamily: "'Inter','Helvetica Neue',Arial,sans-serif",
          fontSize: 11,
          fontWeight: 600,
          letterSpacing: '0.16em',
          color: 'rgba(255,255,255,0.4)',
          textTransform: 'uppercase',
          lineHeight: 1.5,
        }}
      >
        Society for Worldwide Interbank
        <br />
        Financial Telecommunication
      </p>
    </div>
  );
}

/* ─────────────────────────────────────────────────────────────────────────────
   SwiftLogo  (legacy alias — kept so existing imports don't break)
───────────────────────────────────────────────────────────────────────────── */
export function SwiftLogo({
  height = 36,
  className = '',
}: {
  variant?: string;
  height?: number;
  className?: string;
}) {
  return <SwiftWordmark height={height} className={className} />;
}

// ── colour exports used by other files ──────────────────────────────────────
export { SWIFT_ORANGE, SWIFT_NAVY, SWIFT_BLUE };
